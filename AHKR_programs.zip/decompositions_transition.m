function [DlogZt,FHK_NE,MP_NE,GR_NE,...
    FHKentry,FHKexit,FHKwithin,FHKreall,...
    s_N_t,s_X_tl,Kt,deltak,alphak,capitalt]...
    =decompositions_transition(xx,xmatin)
% Productivity growth decompositions given
% [xhatt,wt,qt,mut,etat,avgxpath], [kappa f gamma gw delta phi lambda]

global alpha g epsilon t N

%% Load parameters
kappa = xmatin(:,1);    % kappa = entry cost (vector)
f = xmatin(:,2);        % f = continuation cost (vector)
gamma = xmatin(1,3);	% gamma = tail parameter (constant)
gw = xmatin(:,4);       % gw = productivity growth of incubments (before spillovers)
delta = xmatin(:,5);    % delta = exogenous death rate
phi = xmatin(:,6);      % phi = barriers to technology adoption (vector)
lambda = xmatin(:,7);   % lambda = distance-to-frontier (vector)
% the number of rows of xmatin is equal to the number of periods.
% some parameters are the same throughout and some change through time.


%% Load transition variables
TT = length(xx(:,1));   % terminal period.
xhatt = xx(:,1);        % efficiency threshold
wt = xx(:,2);           % wages
qt = xx(:,3);           % bond price
mut = xx(:,4);          % mass of potential entrants
etat = xx(:,5);         % mass of firms
avgxt = xx(:,6);        % average efficiency

%% Aggregate variables
% Vector of xhat growth factors ( gt(tt) = avgx(tt)/avgx(tt-1) )
gt = [g;avgxt(2:TT)./avgxt(1:TT-1)]; 

% Vector of continuing firm growth factors
gct = gw.^(1-epsilon).*max(1,gt.^epsilon);
gct1 = gw(1)^(1-epsilon)*g^epsilon;

delta1 = delta(1);

% Output
Yt = wt/alpha;
            
% Mass of entrants
eta1 = mut.*(phi.*xhatt./g.^([1:TT]')).^(-gamma);

% Aggregate capital stock
Kt = etat.*lambda.*(kappa+f).*Yt + (mut-eta1).*lambda.*kappa.*Yt;

% Compute aggregate depreciation rate of capital (forward looking)
deltak = min( 1 , 1 - Kt(2:TT)./Kt(1:TT-1) ...
    + ( mut(1:TT-1).*kappa(1:TT-1) + etat(1:TT-1).*f(1:TT-1) ) ...
    ./( etat(1:TT-1).*( kappa(1:TT-1) + f(1:TT-1) ) ...
    + ( mut(1:TT-1)-eta1(1:TT-1)).*kappa(1:TT-1) ) );
deltak(t) = deltak(1); % perfect foresight (with unanticipated reform)
deltak = [deltak;deltak(TT-1)];

% Compute capital share
qt(t) = qt(1); % perfect foresight model

alphakt = ( 1./qt - (1-deltak)).*Kt./Yt;
% To be consistent with the data, take averages
alphak = (alphakt(1:TT-1)+alphakt(2:TT))/2;
alphak = [alphakt(1); alphak]; % backward looking

% capital stock of firms at period tt (base year prices)
capitalt = Yt.*lambda.*( kappa(1) + f(1) );

%% Iniitalize vectors
FHKentry = zeros(TT,1);
FHKexit = zeros(TT,1);
FHKwithin = zeros(TT,1);
FHKreall = zeros(TT,1);
GRentry = zeros(TT,1);
GRexit = zeros(TT,1);
MPcont = zeros(TT,1);

%% Compute FHK aggregate log productivity

% Create xgrid ~ [xhat,scalefactor*xhat] 
scalefactor = 100000;
xN = 100000;
xgridt = zeros(xN,TT,N);
for tt=1:TT
    for i=1:N
        if tt-i+1>=1
            xhatti = max(xhatt(tt-i+1:tt).*cumprod([gct(tt-i+2:tt);1],'reverse'));
        else
            xhatti = max(xhatt(1:tt).*cumprod([gct(2:tt);1],'reverse'));
        end
        xgridt(:,tt,i) = linspace(0,(scalefactor*xhatti-xhatti)^.5,xN);
        xgridt(:,tt,i) = xgridt(:,tt,i).^2;
        xgridt(:,tt,i) = xhatti + xgridt(:,tt,i);
    end
end

DlogZt = zeros(TT,1);
DlogZt(1) = log(g)*(1-alphak(1));
logZt =  zeros(TT,1);
logZtl  = zeros(TT,1);

% Market share of entrants (t)
s_N_t = eta1./etat;

% Share of continuing firms, ages 1 to N (t-1)
s_C_tl = (1-delta).*(gt./gct).^(1/(1-alpha)-gamma);

% Share of all exiting firms, ages 1 to N (t-1)
s_X_tl = 1 - s_C_tl;

for tt=2:TT

    % Aggregate productivity (tt)
    for i=1:N
        if tt-i+1>=1
            muti = mut(tt-i+1);
            phiti = phi(tt-i+1);
            gci = prod(gct(tt-i+2:tt));
            survti = prod(1-delta(tt-i+2:tt));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(gct(1:tt))*(gct1)^(-tt+i-1);
            survti = prod(1-delta(1:tt))*(1-delta1)^(-tt+i-1);
        end
        % measured productivity
        ztxt = xgridt(:,tt,i)*capitalt(tt)^(-alphak(tt));
        logZt(tt) = logZt(tt) + survti*muti*phiti^(-gamma) ...
            *g^(gamma*(1-i))*gci^gamma ...
            *trapz(xgridt(:,tt,i),xgridt(:,tt,i).^(1/(1-alpha)-gamma-1) ...
            .*log( ztxt ) );
    end
    logZt(tt) = gamma*Yt(tt)^(1/(alpha-1))*g^(gamma*tt)*logZt(tt);
    
    % Aggregate productivity (tt-1)
    for i=1:N
        if tt-i>=1
            muti = mut(tt-i);
            phiti = phi(tt-i);
            gci = prod(gct(tt-i+1:tt-1));
            survti = prod(1-delta(tt-i+1:tt-1));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(gct(1:tt-1))*(gct1)^(-tt+i);
            survti = prod(1-delta(1:tt-1))*(1-delta1)^(-tt+i);
        end
        % measured productivity
        ztxtl = xgridt(:,tt-1,i)*capitalt(tt-1)^(-alphak(tt));
        logZtl(tt) = logZtl(tt) + survti*muti*phiti^(-gamma) ...
            *g^(gamma*(1-i))*gci^gamma ...
            *trapz(xgridt(:,tt-1,i),xgridt(:,tt-1,i).^(1/(1-alpha)-gamma-1)...
            .*log( ztxtl ) );
    end
    logZtl(tt) = gamma*Yt(tt-1)^(1/(alpha-1))*g^(gamma*(tt-1))*logZtl(tt);

    DlogZt(tt) = logZt(tt) - logZtl(tt);
    barlogZt = (logZt(tt) + logZtl(tt))/2;
    
    %% Entry term
    % FHK
    ztxt = xgridt(:,tt,1)*capitalt(tt)^(-alphak(tt)); % measured productivity of entrants (tt)
    FHKentry(tt) =  mut(tt)*phi(tt)^(-gamma) ...
            *trapz(xgridt(:,tt,1),xgridt(:,tt,1).^(1/(1-alpha)-gamma-1) ...
            .*( log( ztxt ) - logZtl(tt) ) );
    FHKentry(tt) = gamma*(wt(tt)/alpha)^(1/(alpha-1))*g^(gamma*tt)*FHKentry(tt)/DlogZt(tt);
   
    % GR
    GRentry(tt) = mut(tt)*phi(tt)^(-gamma) ...
            *trapz(xgridt(:,tt,1),xgridt(:,tt,1).^(1/(1-alpha)-gamma-1) ...
            .*( log( ztxt ) - barlogZt ) );
    GRentry(tt) = gamma*(wt(tt)/alpha)^(1/(alpha-1))*g^(gamma*tt)*GRentry(tt)/DlogZt(tt);
    
    %% Exit term
    for i=1:N-1
        if tt-i>=1
            muti = mut(tt-i);
            phiti = phi(tt-i);
            gci = prod(gct(tt-i+1:tt-1));
            xhatti = max(xhatt(tt-i:tt-1).*cumprod([gct(tt-i+1:tt-1);1],'reverse'));
            survti = prod(1-delta(tt-i+1:tt));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(gct(1:tt-1))*(gct1)^(-tt+i);
            xhatti = max(xhatt(1:tt-1).*cumprod([gct(2:tt-1);1],'reverse'));
            survti = prod(1-delta(1:tt))*(1-delta1)^(-tt+i);
        end
        xgridx = linspace(0,( max(xhatti,xhatt(tt)/gct(tt)) - xhatti )^.5,xN);
        xgridx = xgridx.^2;
        xgridx = xhatti + xgridx;
        % measured productivity for endogenously exiting firms (t-l)
        ztxx = xgridx*capitalt(tt-1)^(-alphak(tt));
        FHKexit(tt) = FHKexit(tt) + survti*muti*phiti^(-gamma) ...
            *g^(gamma*(1-i))*gci^gamma ...
            *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1) ...
            .*( log( ztxx ) - logZtl(tt) ) );
        GRexit(tt) = GRexit(tt) + survti*muti*phiti^(-gamma) ...
            *g^(gamma*(1-i))*gci^gamma ...
            *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1) ...
            .*( log( ztxx ) - barlogZt ) );
    end
    % FHK
    FHKexit(tt) = gamma*(wt(tt-1)/alpha)^(1/(alpha-1))*g^(gamma*(tt-1)) ...
        *FHKexit(tt)/DlogZt(tt);
    
    % GR
    GRexit(tt) = gamma*(wt(tt-1)/alpha)^(1/(alpha-1))*g^(gamma*(tt-1)) ...
        *GRexit(tt)/DlogZt(tt);
   
    
    %% Within and Reallocation terms
    for i=2:N
        if tt-i+1>=1
            muti = mut(tt-i+1);
            phiti = phi(tt-i+1);
            gci = prod(gct(tt-i+2:tt));
            survti = prod(1-delta(tt-i+2:tt));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(gct(1:tt))*(gct1)^(-tt+i-1);
            survti = prod(1-delta(1:tt))*(1-delta1)^(-tt+i-1);
        end
        % measured productivity for continuing firms (t-l)
        ztxcl = xgridt(:,tt,i)/gct(tt)*capitalt(tt-1)^(-alphak(tt));
        % measured productivity for continuing firms (t)
        ztxt = xgridt(:,tt,i)*capitalt(tt)^(-alphak(tt));
        FHKwithin(tt) = FHKwithin(tt) + survti*muti*phiti^(-gamma) ...
            *g^(gamma*(1-i))*gci^gamma ...
            *trapz(xgridt(:,tt,i),xgridt(:,tt,i).^(1/(1-alpha)-gamma-1) ...
            .*( log( ztxt ) - log( ztxcl ) ) );
        FHKreall(tt) = FHKreall(tt) + survti*muti*phiti^(-gamma) ...
            *g^(gamma*(1-i))*gci^gamma ...
            *trapz(xgridt(:,tt,i),xgridt(:,tt,i).^(1/(1-alpha)-gamma-1) ...
            .*( log( ztxt ) - logZtl(tt) ) );
    end
    FHKwithin(tt) = gamma*(wt(tt-1)/alpha*gct(tt))^(1/(alpha-1))*g^(gamma*tt)*FHKwithin(tt)/DlogZt(tt);
    FHKreall(tt) = gamma...
        *( (wt(tt)/alpha)^(1/(alpha-1)) - (wt(tt-1)/alpha*gct(tt))^(1/(alpha-1)) )...
        *g^(gamma*tt)*FHKreall(tt)/DlogZt(tt);
    

    % MP continuing term
    % logZCt for period t-1
    % Create xgrid ~ [xhat/gc,scalefactor*xhat/gc]
    xgridc = linspace(0,(scalefactor*xhatt(tt)/gct(tt)-xhatt(tt)/gct(tt))^.5,xN);
    xgridc = xgridc.^2;
    xgridc = xhatt(tt)/gct(tt) + xgridc;
    ztxc = xgridc*capitalt(tt-1)^(-alphak(tt)); % measured productivity for continuing (tt-1)
    logZCtl = (1-delta(tt))/s_C_tl(tt) ...
        *(gamma*(1-alpha)-1)/(1-alpha) ...
        *xhatt(tt-1)^(gamma-1/(1-alpha)) ...
        *trapz(xgridc,xgridc.^(1/(1-alpha)-gamma-1)...
        .*log( ztxc ) );
    
    MPcont(tt) = (logZt(tt) - logZCtl)/DlogZt(tt);
    
end
FHKentry(1) = FHKentry(2);
FHKexit(1) = FHKexit(2);
FHKwithin(1) = FHKwithin(2);
FHKreall(1) = FHKreall(2);
GRentry(1) = GRentry(2);
GRexit(1) = GRexit(2);
MPcont(1) = MPcont(2);
    
FHK_NE = FHKentry - FHKexit;
MP_NE = 1 - MPcont;
GR_NE = GRentry - GRexit;



end
