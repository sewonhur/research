function [FHK_NE,MP_NE,GR_NE,s_N_t,s_X_tl]=decompositions_BGP(xx,t)
% Compute FHK and MP productivity decompositions given
% scalar values: [kappa, f, gamma, gw, delta, phi, lambda], t

global alpha g epsilon beta

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gw = xx(4);
delta = xx(5);
phi = xx(6);
lambda = xx(7);

gc = gw^(1-epsilon)*g^epsilon; % gbar: gw^(1-eps)


%% Macro variables
[waget, mu, xhat, eta,  ~] = macro_BGP(xx,t);

% Output
Yt = waget/alpha;
eta1 = mu*(phi*xhat/g^t)^(-gamma);
Kt = eta*Yt*lambda*(kappa+f) + (mu-eta1)*Yt*lambda*kappa;

% Lagged variables
xhatl = xhat/g;
Ytl = Yt/g;

% Compute aggregate depreciation rate of capital
deltak = min( 1 , ...
    1 - g + ( mu*kappa + eta*f )/( mu*kappa + eta*f + (eta-eta1)*kappa ) );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;


%% Compute FHK aggregate log productivity

% logZt for period t
% Create xgrid ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capitalx = Yt*lambda*(kappa+f);
ztx = xgrid*capitalx^(-alphak); % measured productivity

logZt = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha)) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*log( ztx ) );

% logZt for period t-1
% Create xgrid ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitalxl = lambda*Ytl*(kappa+f);
ztxl = xgridl*capitalxl^(-alphak); % measured productivity

logZtl = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridl,xgridl.^(1/(1-alpha)-gamma-1)...
    .*log( ztxl ) );

DlogZt = logZt - logZtl;

% FHK entry term
% Market share of entrants (t)
s_N_t = eta1/eta;
FHKentry = s_N_t;

% Share of continuing firms, ages 1 to N (t-1)
s_C_tl = (1-delta)*(g/gc)^(1/(1-alpha)-gamma);

% Share of all exiting firms, ages 1 to N (t-1)
s_X_tl = 1 - s_C_tl;


% FHK exit term
% Create xgrid ~ [xhatl,xhat/gc]
xgridx = linspace(0,(xhat/gc-xhatl)^.5,xN);
xgridx = xgridx.^2;
xgridx = xhatl+xgridx;

ztxx = xgridx*capitalxl^(-alphak);  % measured productivity

FHKexit = (1-delta)*...
    (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
    .*( log(ztxx) - logZtl ) )/DlogZt;

FHK_NE = FHKentry - FHKexit;

% GR entry term
GRentry = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha))*s_N_t ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*( log(ztx) - (logZt + logZtl)/2 ) )/DlogZt;

% GR exit term
GRexit = (1-delta)*...
    (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
    .*( log(ztxx) - (logZt + logZtl)/2 ) )/DlogZt;

GR_NE = GRentry - GRexit;

% MP continuing term
% logZCt for period t-l
% Create xgrid ~ [xhat/gc,xmax/g]
xgridc = linspace(0,(scalefactor*xhat/gc-xhat/gc)^.5,xN);
xgridc = xgridc.^2;
xgridc = xhat/gc+xgridc;

capitalxc = Ytl*lambda*(kappa+f);
ztxc = xgridc*capitalxc^(-alphak);  % measured productivity

logZCtl = (1-delta)/s_C_tl ...
    *(gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridc,xgridc.^(1/(1-alpha)-gamma-1)...
    .*log( ztxc ) );

MPcont = (logZt - logZCtl)/DlogZt;

% MP net entry
MP_NE = 1 - MPcont;


end
