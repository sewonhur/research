Additional Materials for: "Firm Entry and Exit and Aggregate Growth" by Jose Asturias, Sewon Hur, Timothy Kehoe, and Kim Ruhl (2017)

This folder contains the codes used in the paper. The main code is written in MATLAB.

The main code calibrates the model and solves the transition. The following files are included and are required for the program:

main_AHKR.m : main program
calibration.m : used to calibrate model
transfun.m : used to solve for transition
macro_BGP.m : computes macroeconomic variables in the balanced growth path (BGP)
FHK_BGP.m : computes FHK decomposition in BGP for different windows
decompositions_BGP.m: computes productivity decompositions for BGP
decompositions_transition.m: computes productivity decompositions for transition



The main menu has the following options:
calibrateswitch = 1;        % Set = 1 to calibrate model
windowswitch = 1;           % Set = 1 to run FHK with different windows
transitionswitch = 1;       % Set = 1 to run transitions
reformswitch = 1;           % Set reform type
% 0: no reform
% 1: kappa reform
% 2: phi reform
% 3: f reform

