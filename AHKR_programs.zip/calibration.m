function fval=calibration(xguess)
% solve model with [f, gamma, gw, delta] to firm size statistics, FHK
% contribution of net entry, and fraction of jobs destroyed by exit

global t N alpha kfratio g epsilon beta

f = xguess(1);       	% Fixed continuation cost
gamma = xguess(2);   	% Pareto tail parameter
gw = xguess(3);     	% Continuing firm growth
delta = xguess(4);      % Exogenous death rate
kappa  = f*kfratio;  	% Entry cost (no policy distortions in frontier)
phi = 1;                % No adoption barriers in frontier

%% Generate firm size statistics
% Compute mass of firms
eta = (gamma*(1-alpha)-1)/gamma/f;

% Average firm size
firmsize = 1/eta;

% Variance of firm size
firmvar = (1/eta)^2*...
    (...
    (gamma*(1-alpha)-1)^2/(gamma*(1-alpha)-2)/(gamma*(1-alpha))-1 ...
    );

%% Compute FHK contribution of net entry
% First, compute the output and cutoff efficiency
gc = gw^(1-epsilon)*g^epsilon;

omega = 0;
xi = 0;
for i=1:N
    omega = omega + (1-delta)^(i-1)*(g/gc)^(gamma*(1-i));
    xi = xi + (beta*(1-delta))^(i-1)*(g/gc)^(gamma*(1-i));
end

mu = xi/omega/gamma/kappa;
waget = g^t*alpha*((1-alpha)/f)^(1-alpha) ...
    *(...
    1/( gamma*(1-alpha) - 1 )*f/kappa*xi ...
    )^(1/gamma);
xhat = (f/(1-alpha))^(1-alpha)*waget/alpha;
Yt = waget/alpha;
eta1 = mu*(phi*xhat/g^t)^(-gamma);
Kt = eta*Yt*(kappa+f) + (mu-eta1)*Yt*kappa;


% Lagged variables
xhatl = xhat/g;
Ytl = Yt/g;

% Compute aggregate depreciation rate of capital
deltak = min( 1 , ...
    1 - g + ( mu*kappa + eta*f )/( eta*(kappa + f) + (mu-eta1)*kappa ) );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;

% Third, compute FHK aggregate log productivity

% logZt for period t
% Create efficiency grid (t) ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capitalx = Yt*(kappa+f);
ztx = xgrid*capitalx^(-alphak); % measured prodcutivity (t)

logZt = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha)) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*log( ztx ) );

% logZt for period t-1
% Create efficiency grid (t-1) ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitalxl = Ytl*(kappa+f);

ztxl = xgridl*capitalxl^(-alphak); % measured prodcutivity (t-1)

logZtl = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridl,xgridl.^(1/(1-alpha)-gamma-1)...
    .*log( ztxl ) );

DlogZt = logZt - logZtl;


% FHK entry term

% Market share of entrants (t)
s_N_t = eta1/eta;
FHKentry = s_N_t;

% FHK exit term
% Create efficiency grid for endogenous exiters ~ [xhatl,xhat/gc]
xgridx = linspace(0,(xhat/gc-xhatl)^.5,xN);
xgridx = xgridx.^2;
xgridx = xhatl+xgridx;

ztxx = xgridx*capitalxl^(-alphak); % measured productivity

FHKexit = (1-delta)*...
    (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
    .*( log(ztxx) - logZtl ) )/DlogZt;

FHKnetentry = FHKentry - FHKexit;

% Compute jobs lost due to exit (percent of total jobs)
joblossexit = delta + (1-delta)*(1-(g/gc)^(1/(1-alpha)-gamma));

% Compute error terms
fval = 0*xguess;
fval(1) = firmsize - 14.0; % 14.0
fval(2) = sqrt(firmvar) - 88.95; % 88.95
fval(3) = FHKnetentry - 0.25; % 0.25
fval(4) = joblossexit - 0.1933; % 0.1933



end