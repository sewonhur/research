function fval = transfun(tmat,icmat,tcmat,xmat)
% given a transition path [tmat,icmat,tcmat]
% and scalar values: [kappa f gamma gw delta phi]
% generate errors

global alpha t N beta g T epsilon

%% Read inputs
% ymat  = [xhatt(T+2,1),mut(T+2,1)];
ymatin  = [icmat;tmat;tcmat];
% x0    = [kappa, f, gamma, gw, delta, phi ]
kappa   = xmat(:,1);
f       = xmat(:,2);
gamma 	= xmat(1,3);
gw      = xmat(:,4);
delta   = xmat(:,5);
phi     = xmat(:,6);

xhatt = ymatin(:,1);
mut = ymatin(:,2);
avgxt = ymatin(:,3);

%% Frontier and domestic GDP
% Frontier GDP
YtF = 0*xhatt;
YtF(T+2) = ((1-alpha)/f(T+2))^(1-alpha)*xhatt(T+2);
for tt=T+1:-1:1
    YtF(tt) = YtF(tt+1)/g;
end

% Domestic GDP
Yt = (...
    ((1-alpha)./(f.*YtF)).^(1-alpha).*xhatt...
    ).^(1/alpha);

%% Extend series
for j=1:N 
    xhatt = [xhatt;xhatt(T+j+1)*g];
    avgxt = [avgxt;avgxt(T+j+1)*g];
    YtF = [YtF;YtF(T+j+1)*g];
    Yt = [Yt;Yt(T+j+1)*g];
    mut = [mut;mut(T+2)];
    kappa = [kappa;kappa(T+2)];
    f = [f;f(T+2)];
    phi = [phi;phi(T+2)];
    gw = [gw;gw(T+2)];
    delta = [delta;delta(T+2)];
end

lambdat = YtF./Yt;


%% Growth factors
gt = avgxt(2:T+N+2,1)./avgxt(1:T+N+1,1); 
gt = [g;gt]; % backward-looking growth: gt(tt+1) = xhat(tt+1)/xhat(tt)
gct = gw.^(1-epsilon).*max(1,gt.^epsilon); % backward-looking gct
gct1 = gw(1)^(1-epsilon)*g^epsilon;
delta1 = delta(1);

%% Mass of firms
etat = (gamma*(1-alpha)-1)./(gamma.*lambdat.*f);
for tt = 2:T+1
    eta =  0;
    for i=1:N
        if tt-i+1>=1
            muti = mut(tt-i+1);
            phiti = phi(tt-i+1);
            gci = prod(gct(tt-i+2:tt));
            xhatti = max(xhatt(tt-i+1:tt).*cumprod([gct(tt-i+2:tt);1],'reverse'));
            survti = prod(1-delta(tt-i+2:tt));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(gct(1:tt))*gct1^(-tt+i-1);
            xhatti = max(xhatt(1:tt).*cumprod([gct(2:tt);1],'reverse'));
            survti = prod(1-delta(1:tt))*(1-delta1)^(-tt+i-1);
        end
        eta = eta + xhatti^(-gamma)*phiti^(-gamma)*muti...
            *survti*g^(gamma*(1-i))*gci^gamma;
    end
    etat(tt) = g^(gamma*(t+tt-1))*eta;
end

%% Prices
Ct = Yt.*( 1 - lambdat.*( etat.*f + mut.*kappa ) );
qt = beta*Ct(1:T+N+1)./Ct(2:T+N+2);
qt(1) = beta/g;     % unexpected reform
qt = [beta/g;qt];	% backward-looking prices: qt(tt+1) = beta*ct(tt)/ct(tt+1)


%% Compute error terms (to be minimized)

fval = 1*tmat;

for tt = 2:T+1
    lmsum = 0;  % labor market clearing condition
    fesum = 0;  % free entry condition
    xsum = 0;   % average productivity
    for i=1:N
        if tt-i+1>=1
            muti = mut(tt-i+1);
            phiti = phi(tt-i+1);
            gci = prod(gct(tt-i+2:tt));
            xhatti = max(xhatt(tt-i+1:tt).*cumprod([gct(tt-i+2:tt);1],'reverse'));
            survti = prod(1-delta(tt-i+2:tt));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(gct(1:tt))*(gct1)^(-tt+i-1);
            xhatti = max(xhatt(1:tt).*cumprod([gct(2:tt);1],'reverse'));
            survti = prod(1-delta(1:tt))*(1-delta1)^(-tt+i-1);
        end
        % labor market clearing sums up existing cohorts
        lmsum = lmsum + xhatti^(1/(1-alpha)-gamma)*phiti^(-gamma)...
            *muti*survti*g^(gamma*(1-i))*gci^gamma;
        % average productivity of existing cohorts
        xsum = xsum + xhatti^(1-gamma)*phiti^(-gamma)...
            *muti*survti*g^(gamma*(1-i))*gci^gamma;    
        % free entry condition sums up over future periods
        fesum = fesum + prod(1-delta(tt+1:tt+i-1)) ...
                *prod( qt(tt+1:tt+i-1).*gct(tt+1:tt+i-1).^gamma ) ...
                *xhatt(tt+i-1)^(-gamma) ...
                *( ...
                Yt(tt+i-1)/YtF(tt)*...
                (Yt(tt+i-1)/xhatt(tt+i-1))^(1/(alpha-1)) ...
                *(1-alpha)*gamma*(1-alpha)/(gamma*(1-alpha)-1) ...
                - YtF(tt+i-1)/YtF(tt)*f(tt) ...
                );     
    end
    % Labor market clearing condition
    fval(tt-1,1) = (Yt(tt))^(1/(1-alpha)) - g^(gamma*(t+tt-1))*...
        gamma*(1-alpha)/(gamma*(1-alpha)-1)*lmsum;
    % Free entry condition
    fval(tt-1,2) = kappa(tt) ...
        - g^(gamma*(t+tt-1))*phi(tt)^(-gamma)*fesum;
    % Average productivity condition
    fval(tt-1,3) = avgxt(tt) ...
        - g^(gamma*(t+tt-1))*gamma/(gamma-1)*xsum/etat(tt);
end

end