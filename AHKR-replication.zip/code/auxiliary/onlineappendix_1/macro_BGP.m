function [waget, Yt, mut, xhat, eta, entryrate, joblossexit,deltak,alphak]=macro_BGP(xx,t)
% find macro variables for
% scalar values: [kappa f gamma gw delta phi], t

global alpha g N beta epsilon

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gw = xx(4);
delta = xx(5);
phi = xx(6);

gc = gw^(1-epsilon)*g^epsilon;

%% Compute BGP variables
omega = 0;
xi = 0;
for i=1:N
    omega = omega + (1-delta)^(i-1)*(g/gc)^(gamma*(1-i));
    xi = xi + (beta*(1-delta))^(i-1)*(g/gc)^(gamma*(1-i));
end

% mass of potential entrants
mut = xi/kappa/((gamma-1)*omega+xi);

% mass of firms
eta = (gamma*(1-alpha)-1)/(gamma-1)*(1-mut*kappa)/f;

% wages and output
waget = alpha*g^t/phi*((1-alpha)/(alpha*f))^(1-alpha)* ...
    ( mut*omega/eta )^(1/gamma);
Yt = waget*gamma/(gamma-1)*(1-mut*kappa);

% efficiency threshold
xhat = ((alpha*f)/(1-alpha))^(1-alpha)*waget/alpha;

% entry rate
eta1 = mut*(xhat*phi/g^t)^(-gamma);
entryrate = eta1/eta;

% Compute jobs lost due to exit (percent of total variable labor)
joblossexit = (delta + (1-delta)*(1-(g/gc)^(1/(1-alpha)-gamma))) ...
    *alpha*gamma/(gamma-1)*(1-mut*kappa)/(1-mut*kappa-eta*f);

if nargout>7 
    % Capital stock
    Kt = eta*waget*(kappa+f) + (mut-eta1)*waget*kappa;
    % Investment
    It = eta*waget*f + mut*waget*kappa;
    
    % Lagged variables
    Ktl = Kt/g;
    
    % Compute aggregate depreciation rate of capital
    %Kt = (1-delta)Ktl + It
    % 1-delta = (Kt-It)/Ktl
    % delta = 1 - (Kt-It)/Ktl
    deltak = min( 1 , ...
        1 - g + It/Ktl );
    
    % Compute capital share
    alphak = ( g/beta - 1 + deltak )*Kt/Yt;
    
end

end