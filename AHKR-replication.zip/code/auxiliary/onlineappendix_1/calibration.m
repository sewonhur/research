function fval=calibration(xguess)
% solve model with [f, gamma, gw, delta] to firm size statistics, FHK
% contribution of net entry, and fraction of jobs destroyed by exit

global t N alpha kfratio g epsilon beta

f = xguess(1);       	% Fixed continuation cost
gamma = xguess(2);   	% Pareto tail parameter
gw = xguess(3);     	% Continuing firm growth
delta = xguess(4);      % Exogenous death rate
kappa  = f*kfratio;  	% Entry cost (no policy distortions in frontier)
phi = 1;                % No adoption barriers in frontier

%% Generate firm size statistics
% Average firm size
firmsize = gamma*alpha*f/(gamma*(1-alpha)-1);

% Variance of firm size
firmvar = firmsize^2*...
    (...
    (gamma*(1-alpha)-1)^2/(gamma*(1-alpha)-2)/(gamma*(1-alpha)) - 1 ...
    );

% incumbent efficiency growth
gc = gw^(1-epsilon)*g^epsilon;

if gc<g

%% Compute BGP variables
omega = 0;
xi = 0;
for i=1:N
    omega = omega + (1-delta)^(i-1)*(g/gc)^(gamma*(1-i));
    xi = xi + (beta*(1-delta))^(i-1)*(g/gc)^(gamma*(1-i));
end

% mass of potential entrants
mut = xi/kappa/((gamma-1)*omega+xi);

% mass of firms
eta = (gamma*(1-alpha)-1)/(gamma-1)*(1-mut*kappa)/f;

% wages and output
waget = alpha*g^t/phi*((1-alpha)/(alpha*f))^(1-alpha)* ...
    ( mut*omega/eta )^(1/gamma);

Yt = waget*gamma/(gamma-1)*(1-mut*kappa);

% efficiency threshold
xhat = ((alpha*f)/(1-alpha))^(1-alpha)*waget/alpha;

% entrants
eta1 = mut*(xhat*phi/g^t)^(-gamma);

% Compute jobs lost due to exit (percent of total jobs)
joblossexit = (delta + (1-delta)*(1-(g/gc)^(1/(1-alpha)-gamma))) ...
    *alpha*gamma/(gamma-1)*(1-mut*kappa)/(1-mut*kappa-eta*f);

% Aggregate investment
It = eta*waget*f + mut*waget*kappa;

% Capital stock
Kt = eta*waget*(kappa+f) + (mut-eta1)*waget*kappa;

% Lagged variables
xhatl = xhat/g;
wagetl = waget/g;
Ktl = Kt/g;

% Compute aggregate depreciation rate of capital
%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl
deltak = min( 1 , ...
    1 - g + It/Ktl );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;

%% Compute FHK contribution of net entry

% Compute FHK aggregate log productivity

% logZt for period t
% Create efficiency grid (t) ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capitalx = waget*(kappa+f);
ztx = xgrid*capitalx^(-alphak); % measured productivity (t)

logZt = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha)) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*log( ztx ) );

% logZt for period t-1
% Create efficiency grid (t-1) ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitalxl = wagetl*(kappa+f);
ztxl = xgridl*capitalxl^(-alphak); % measured productivity (t-1)

logZtl = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridl,xgridl.^(1/(1-alpha)-gamma-1)...
    .*log( ztxl ) );

DlogZt = logZt - logZtl;


% FHK entry term

% Market share of entrants (t)
s_N_t = eta1/eta;
FHKentry = s_N_t;

% FHK exit term
% Create efficiency grid for endogenous exiters ~ [xhatl,xhat/gc]
xgridx = linspace(0,(xhat/gc-xhatl)^.5,xN);
xgridx = xgridx.^2;
xgridx = xhatl+xgridx;

ztxx = xgridx*capitalxl^(-alphak);  % measured productivity

FHKexit = (1-delta)*...
    (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
    .*( log(ztxx) - logZtl ) )/DlogZt;

FHKnetentry = FHKentry - FHKexit;

% Compute error terms
fval = 0*xguess;
fval(1) = firmsize - 14.0; % 14.0
fval(2) = sqrt(firmvar) - 88.95; % 88.95
fval(3) = FHKnetentry - 0.25; % 0.25
fval(4) = joblossexit - 0.1933; % 0.1933

else
    fval = 1000;
    
end

end