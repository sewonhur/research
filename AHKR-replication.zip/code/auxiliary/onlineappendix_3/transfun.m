function fval = transfun(tmat,icmat,tcmat,xmat)
% given a transition path [tmat,icmat,tcmat]
% and scalar values: [kappa f gamma gw delta phi]
% generate errors

global rho t N beta g T epsilon

%% Read inputs
% ymat  = [xhatt(T+2,1),mut(T+2,1)];
ymatin  = [icmat;tmat;tcmat];
% x0    = [kappa, f, gamma, gw, delta, phi ]
kappa   = xmat(:,1);
f       = xmat(:,2);
gamma 	= xmat(1,3);
gw      = xmat(:,4);
delta   = xmat(1,5);
phi     = xmat(:,6);

xhatt = ymatin(:,1);
mut = ymatin(:,2);

%% Extend series
for j=1:N 
    xhatt = [xhatt;xhatt(T+j+1)*g];
    mut = [mut;mut(T+2)];
    kappa = [kappa;kappa(T+2)];
    f = [f;f(T+2)];
    phi = [phi;phi(T+2)];
    gw = [gw;gw(T+2)];
end
avgxt = gamma/(gamma-1)*xhatt;

%% Growth factors
gt = avgxt(2:T+N+2,1)./avgxt(1:T+N+1,1); 
gt = [g;gt]; % backward-looking growth: gt(tt+1) = xhat(tt+1)/xhat(tt)
gct = gw.^(1-epsilon).*max(1,gt.^epsilon); % backward-looking gct
gct1 = gw(1)^(1-epsilon)*g^epsilon;

%% Mass of firms
etat = 0*mut;
for tt = 1:T+N+2
    eta =  0;
    for i=1:N
        if tt-i+1>=1
            muti = mut(tt-i+1);
            phiti = phi(tt-i+1);
            gci = prod(gct(tt-i+2:tt));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(gct(1:tt))*gct1^(-tt+i-1);
        end
        eta = eta + xhatt(tt)^(-gamma)*phiti^(-gamma)*muti...
            *(1-delta)^(i-1)*g^(gamma*(1-i))*gci^gamma;
    end
    etat(tt) = g^(gamma*(t+tt-1))*eta;
end

%% Prices
wt = xhatt*rho.*((gamma*(1-rho)-rho)/gamma/(1-rho)./etat).^((rho-1)/rho);
Yt = wt.*etat*gamma.*f/(gamma*(1-rho)-rho);
Ct = Yt;
qt = beta*Ct(1:T+N+1)./Ct(2:T+N+2);
qt(1) = beta/g;     % unexpected reform
qt = [beta/g;qt];	% backward-looking prices: qt(tt+1) = beta*ct(tt)/ct(tt+1)

%% Compute error terms (to be minimized)
            
fval = 1*tmat;

for tt = 2:T+1
    fesum = 0;  % free entry condition
    for i=1:N
        % free entry condition sums up over future periods
        discountedprofits = (1-delta)^(i-1) ...
                *prod( qt(tt+1:tt+i-1).*gct(tt+1:tt+i-1).^gamma ) ...
                *xhatt(tt+i-1)^(-gamma)*wt(tt+i-1) ...
                *( ...
                (1-rho)*Yt(tt+i-1)/wt(tt+i-1) ...
                *(wt(tt+i-1)/rho)^(-rho/(1-rho)) ...
                *gamma*(1-rho)/(gamma*(1-rho)-rho) ...
                *xhatt(tt+i-1)^(rho/(1-rho)) ...
                - f(tt+i-1) ...
                );
        fesum = fesum + discountedprofits;   
            
           
    end
    % Labor market clearing condition
    fval(tt-1,1) = wt(tt)/Yt(tt) ...
        *( 1 - etat(tt)*f(tt) - mut(tt)*kappa(tt) ) ...
        - rho;
    % Free entry condition
    fval(tt-1,2) = wt(tt)*kappa(tt) ...
        - g^(gamma*(t+tt-1))*phi(tt)^(-gamma)*fesum;
end

end