function [DlogZt,FHK_NE,...
    FHKentry,FHKexit,...
    s_N_t,s_X_tl,Kt_nom,deltak,alphak,capitalt]...
    =decompositions_transition(xx,xmatin)
% Productivity growth decompositions given
% [xhatt,wt,qt,mut,etat,avgxpath], [kappa f gamma gw delta phi]

global rho g epsilon t

%% Load parameters
kappa   = xmatin(:,1);  % kappa = entry cost (vector)
f       = xmatin(:,2);  % f = continuation cost (vector)
gamma   = xmatin(1,3);	% gamma = tail parameter (constant)
gw      = xmatin(:,4);  % gw = productivity growth of incubments (before spillovers)
delta	= xmatin(1,5);  % delta = exogenous death rate
phi     = xmatin(:,6);  % phi = barriers to technology adoption (vector)
% the number of rows of xmatin is equal to the number of periods.
% some parameters are the same throughout and some change through time.



%% Load transition variables
TT = length(xx(:,1));   % terminal period.
xhatt = xx(:,1);        % efficiency threshold
wt = xx(:,2);           % wages
qt = xx(:,3);           % bond price
mut = xx(:,4);          % mass of potential entrants
etat = xx(:,5);         % mass of firms

avgxt = gamma/(gamma-1)*xhatt;

%% Aggregate variables
% Vector of xhat growth factors ( gt(tt) = avgx(tt)/avgx(tt-1) )
gt = [g;avgxt(2:TT)./avgxt(1:TT-1)];

% Vector of continuing firm growth factors
gct = gw.^(1-epsilon).*max(1,gt.^epsilon);

% Output (Consumpption good)
Yt = wt.*etat*gamma.*f/(gamma*(1-rho)-rho);
            
% Mass of entrants
eta1 = mut.*(phi.*xhatt./g.^([1:TT]')).^(-gamma);

% Aggregate investment (real)
It = etat.*wt(1).*g.^([0:TT-1]').*f(1) + mut.*wt(1).*g.^([0:TT-1]').*kappa(1);

% Aggregate capital stock
% (real)
Kt = etat.*wt(1).*g.^([0:TT-1]').*(kappa(1)+f(1)) ...
    + (mut-eta1).*wt(1).*g.^([0:TT-1]').*kappa(1);
% (nominal)
Kt_nom = etat.*wt.*(kappa+f) + (mut-eta1).*wt.*kappa;

%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl

% Compute aggregate depreciation rate of capital (forward looking)
deltak = min( 1 , ...
    1 - ( Kt(2:TT) - It(2:TT) )./Kt(1:TT-1) );
deltak(t) = deltak(1); % unanticipated reform
deltak = [deltak;deltak(TT-1)];

% Compute capital share
qt(t) = qt(1); % unanticipated reform

alphakt = ( 1./qt - (1-deltak)).*Kt_nom./Yt;
% To be consistent with the data, take averages
alphak = (alphakt(1:TT-1)+alphakt(2:TT))/2;
alphak = [alphakt(1); alphak]; % backward looking

% capital stock of firms at period tt (quality adjusted, base year prices)
capitalt = wt(1).*g.^([0:TT-1]').*( kappa(1) + f(1) );

%% Iniitalize vectors
FHKentry = zeros(TT,1);
FHKexit = zeros(TT,1);

%% Compute FHK aggregate log productivity

% Create xgrid ~ [xhat,scalefactor*xhat] 
scalefactor = 100000;
xN = 100000;
xgridt = zeros(xN,TT);
for tt=1:TT
    xgridt(:,tt) = linspace(0,(scalefactor*xhatt(tt)-xhatt(tt))^.5,xN);
    xgridt(:,tt) = xgridt(:,tt).^2;
    xgridt(:,tt) = xhatt(tt) + xgridt(:,tt);
end

DlogZt = zeros(TT,1);
DlogZt(1) = log(g)*(1-alphak(1));
logZt =  zeros(TT,1);
logZtl  = zeros(TT,1);

% Market share of entrants (t)
s_N_t = eta1./etat;

% Share of all exiting firms, ages 1 to N (t-1)
s_X_tl = delta + (1-delta).*( 1 - (gt./gct).^(rho/(1-rho)-gamma) );

for tt=2:TT

    % Aggregate productivity (tt)
    logztxt = rho*log(xgridt(:,tt)) + (1-rho)*log(Yt(tt)) - alphak(tt)*log(capitalt(tt)); % measured productivity (t)
    logZt(tt) = (gamma*(1-rho)-rho)/(1-rho) ...
        *xhatt(tt)^(gamma-rho/(1-rho)) ...
        *trapz(xgridt(:,tt),xgridt(:,tt).^(rho/(1-rho)-gamma-1)...
        .*logztxt );
    
    % Aggregate productivity (tt-1)
    logztxtl = rho*log(xgridt(:,tt-1)) + (1-rho)*log(Yt(tt-1)) - alphak(tt)*log(capitalt(tt-1)); % measured productivity (t-1)
    logZtl(tt) = (gamma*(1-rho)-rho)/(1-rho) ...
        *xhatt(tt-1)^(gamma-rho/(1-rho)) ...
        *trapz(xgridt(:,tt-1),xgridt(:,tt-1).^(rho/(1-rho)-gamma-1)...
        .*logztxtl );

    DlogZt(tt) = logZt(tt) - logZtl(tt);
    
    %% Entry term
    % FHK
    FHKentry(tt) =  s_N_t(tt);
    
    %% Exit term
    xgridx = linspace( 0, ( xhatt(tt)/gct(tt) - xhatt(tt-1) )^.5, xN );
    xgridx = xgridx.^2;
    xgridx = xhatt(tt-1) + xgridx;
        
    % measured productivity for endogenously exiting firms (t-l)        
    logztxx = rho*log(xgridx) + (1-rho)*log(Yt(tt-1)) - alphak(tt)*log(capitalt(tt-1));
    FHKexit(tt) = (1-delta) ...
        *(gamma*(1-rho)-rho)/(1-rho) ...
        *xhatt(tt-1)^(gamma-rho/(1-rho)) ...
        *trapz(xgridx,xgridx.^(rho/(1-rho)-gamma-1)...
        .*( logztxx - logZtl(tt) ) )/DlogZt(tt);    
    
end
FHKentry(1) = FHKentry(2);
FHKexit(1) = FHKexit(2);
    
FHK_NE = FHKentry - FHKexit;


end
