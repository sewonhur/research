function [waget, Yt, mut, xhat, eta, entryrate, joblossexit,deltak,alphak,psi]=macro_BGP(xx,t)
% find macro variables for
% scalar values: [kappa f gamma gw delta phi], t

global rho g N beta epsilon

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gw = xx(4);
delta = xx(5);
phi = xx(6);

gc = gw^(1-epsilon)*g^epsilon;

%% Compute BGP variables
omega = 0;
xi = 0;
for i=1:N
    omega = omega + (1-delta)^(i-1)*(g/gc)^(gamma*(1-i));
    xi = xi + (beta*(1-delta))^(i-1)*(g/gc)^(gamma*(1-i));
end

psi = gamma/rho*omega/((gamma/rho-1)*omega+xi);

% mass of potential entrants
mut = xi/gamma/omega/kappa*rho*psi;

% mass of firms
eta = (gamma*(1-rho)/rho-1)/(gamma*f)*rho*psi;

% efficiency threshold
xhat = g^t/phi*( mut*omega/eta )^(1/gamma);

% wages and output
waget = rho*(psi*(1-rho)/f)^((1-rho)/rho)*xhat;
Yt = waget*psi;

% entry rate
eta1 = mut*(xhat*phi/g^t)^(-gamma);
entryrate = eta1/eta;

% Compute jobs lost due to exit (percent of total variable labor)
joblossexit = delta + (1-delta)*(1-(g/gc)^(rho/(1-rho)-gamma));

if nargout>7 
    % Capital stock
    Kt = eta*waget*(kappa+f) + (mut-eta1)*waget*kappa;
    % Investment
    It = eta*waget*f + mut*waget*kappa;
    
    % Lagged variables
    Ktl = Kt/g;
    
    % Compute aggregate depreciation rate of capital
    %Kt = (1-delta)Ktl + It
    % 1-delta = (Kt-It)/Ktl
    % delta = 1 - (Kt-It)/Ktl
    deltak = min( 1 , ...
        1 - g + It/Ktl );
    
    % Compute capital share
    alphak = ( g/beta - 1 + deltak )*Kt/Yt;
    
end

end