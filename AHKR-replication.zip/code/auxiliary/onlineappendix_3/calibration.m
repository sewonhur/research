function fval=calibration(xguess)
% solve model with [f, gamma, gw, delta] to firm size statistics, FHK
% contribution of net entry, and fraction of jobs destroyed by exit

global t N rho kfratio g epsilon beta

f = xguess(1);       	% Fixed continuation cost
gamma = xguess(2);   	% Pareto tail parameter
gw = xguess(3);     	% Continuing firm growth
delta = xguess(4);      % Exogenous death rate
kappa  = f*kfratio;  	% Entry cost (no policy distortions in frontier)
phi = 1;                % No adoption barriers in frontier

gc = gw^(1-epsilon)*g^epsilon;

if gc<g

%% Compute BGP variables
omega = 0;
xi = 0;
for i=1:N
    omega = omega + (1-delta)^(i-1)*(g/gc)^(gamma*(1-i));
    xi = xi + (beta*(1-delta))^(i-1)*(g/gc)^(gamma*(1-i));
end

psi = gamma/rho*omega/((gamma/rho-1)*omega+xi);

% mass of potential entrants
mut = xi/gamma/omega/kappa*rho*psi;

% mass of firms
eta = (gamma*(1-rho)/rho-1)/(gamma*f)*rho*psi;

% efficiency threshold
xhat = g^t/phi*( mut*omega/eta )^(1/gamma);

% wages and output
waget = rho*(psi*(1-rho)/f)^((1-rho)/rho)*xhat;
Yt = waget*psi;

% entrants
eta1 = mut*(xhat*phi/g^t)^(-gamma);

% Compute jobs lost due to exit (percent of variable labor)
joblossexit = delta + (1-delta)*(1-(g/gc)^(rho/(1-rho)-gamma));

% Aggregate investment
It = eta*waget*f + mut*waget*kappa;

% Capital stock
Kt = eta*waget*(kappa+f) + (mut-eta1)*waget*kappa;

% Lagged variables
xhatl = xhat/g;
wagetl = waget/g;
Ktl = Kt/g;
Ytl = Yt/g;

% Compute aggregate depreciation rate of capital
%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl
deltak = min( 1 , ...
    1 - g + It/Ktl );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;

%% Compute FHK contribution of net entry

% Compute FHK aggregate log productivity

% logZt for period t
% Create efficiency grid (t) ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capitalx = waget*(kappa+f);
logztx = rho*log(xgrid) + (1-rho)*log(Yt) - alphak*log(capitalx); % measured productivity (t)

logZt = (gamma*(1-rho)-rho)/(1-rho) ...
    *xhat^(gamma-rho/(1-rho)) ...
    *trapz(xgrid,xgrid.^(rho/(1-rho)-gamma-1)...
    .*logztx );

% logZt for period t-1
% Create efficiency grid (t-1) ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitalxl = wagetl*(kappa+f);
logztxl = rho*log(xgridl) + (1-rho)*log(Ytl) - alphak*log(capitalxl); % measured productivity (t-1)

logZtl = (gamma*(1-rho)-rho)/(1-rho) ...
    *xhatl^(gamma-rho/(1-rho)) ...
    *trapz(xgridl,xgridl.^(rho/(1-rho)-gamma-1)...
    .*logztxl );

DlogZt = logZt - logZtl;


% FHK entry term

% Market share of entrants (t)
s_N_t = eta1/eta;
FHKentry = s_N_t;

% FHK exit term
% Create efficiency grid for endogenous exiters ~ [xhatl,xhat/gc]
xgridx = linspace(0,(xhat/gc-xhatl)^.5,xN);
xgridx = xgridx.^2;
xgridx = xhatl+xgridx;

logztxx = rho*log(xgridx) + (1-rho)*log(Ytl) - alphak*log(capitalxl); % measured productivity (t-1)

FHKexit = (1-delta)*...
    (gamma*(1-rho)-rho)/(1-rho) ...
    *xhatl^(gamma-rho/(1-rho)) ...
    *trapz(xgridx,xgridx.^(rho/(1-rho)-gamma-1)...
    .*( logztxx - logZtl ) )/DlogZt;

FHKnetentry = FHKentry - FHKexit;

%% Generate firm size statistics
% Average firm size
firmsize = rho*psi/eta;

% Variance of firm size
firmvar = firmsize^2*...
    (...
    (gamma*(1-rho)-rho)^2/(gamma*(1-rho)-2*rho)/(gamma*(1-rho)) - 1 ...
    );



% Compute error terms
fval = 0*xguess;
fval(1) = firmsize - 14.0; % 14.0
fval(2) = sqrt(firmvar) - 88.95; % 88.95
fval(3) = FHKnetentry - 0.25; % 0.25
fval(4) = joblossexit - 0.1933; % 0.1933

else
    fval = 1000;
    
end

end