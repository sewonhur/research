function [FHK_NE,s_N_t,s_X_tl,mu_logZt,var_logZt]=decompositions_BGP(xx,t)
% Compute FHK and MP productivity decompositions given
% scalar values: [kappa, f, gamma, gbar, delta, phi, lambda], t

global alpha g beta p epsilonh epsilonl gbarh

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gbarl = xx(4);
delta = xx(5);
phi = xx(6);
lambda = xx(7);

% incumbent efficiency growth
gch = gbarh^(1-epsilonh)*g^epsilonh;
gcl = gbarl^(1-epsilonl)*g^epsilonl;


%% Macro variables
[waget, mu, xhat, eta,  ~] = macro_BGP(xx,t);

% Output
Yt = waget/alpha;

% mass of entrants
eta1 = mu*(phi*xhat/g^t)^(-gamma);

% Aggregate investment
It = eta*Yt*lambda*f + mu*Yt*lambda*kappa;

% Aggregate capital stock
Kt = eta*Yt*lambda*(kappa+f) + (mu-eta1)*Yt*lambda*kappa;

% Lagged variables
xhatl = xhat/g;
Ytl = Yt/g;
Ktl = Kt/g;

% Compute aggregate depreciation rate of capital
%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl
deltak = min( 1 , ...
        1-g+It/Ktl );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;


%% Compute FHK aggregate log productivity

% logZt for period t
% Create xgrid ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capitalx = Yt*lambda*(kappa+f);
ztx = xgrid*capitalx^(-alphak); % measured productivity

logZt = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha)) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*log( ztx ) );

mu_logZt = gamma ...
    *xhat^gamma ...
    *trapz(xgrid,xgrid.^(-gamma-1)...
    .*log( ztx ) );
var_logZt = gamma ...
    *xhat^gamma ...
    *trapz(xgrid,xgrid.^(-gamma-1)...
    .*(log( ztx )).^2 ) - mu_logZt^2;

% logZt for period t-1
% Create xgrid ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitalxl = lambda*Ytl*(kappa+f);
ztxl = xgridl*capitalxl^(-alphak); % measured productivity

logZtl = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridl,xgridl.^(1/(1-alpha)-gamma-1)...
    .*log( ztxl ) );

DlogZt = logZt - logZtl;

% FHK entry term
% Market share of entrants (t)
s_N_t = eta1/eta;
FHKentry = s_N_t;

% FHK exit term
% Share of all exiting firms, ages 1 to N (t-l)
s_X_tl = 1-(1-delta)*(p*(g/gch)^(1/(1-alpha)-gamma) + ...
    (1-p)*(g/gcl)^(1/(1-alpha)-gamma));

% Share of continuing firms, ages l to N (t-l)
% s_C_tl = 1-s_X_tl;

% FHK exit term
FHKexit = -(1-delta)*( ...
        p*( (g/gch)^(1/(1-alpha)-gamma)*log(g/gch) ) ...
        +(1-p)*( (g/gcl)^(1/(1-alpha)-gamma)*log(g/gcl) ) ...
        )/DlogZt;

FHK_NE = FHKentry - FHKexit;

end
