function [DlogZt,FHK_NE, ...
    FHKentry,FHKexit,FHKwithin,FHKcov,FHKreall,...
    s_N_t,s_X_tl,Kt_nom,deltak,alphak,capitalt]...
    =decompositions_transition(xx,xmatin)
% Productivity growth decompositions given
% [xhatt,wt,qt,mut,etat,avgxpath], [kappa f gamma gw delta phi lambda]

global alpha g t p epsilonh epsilonl gbarh

%% Load parameters
kappa   = xmatin(:,1);  % kappa = entry cost (vector)
f       = xmatin(:,2);  % f = continuation cost (vector)
gamma   = xmatin(1,3);	% gamma = tail parameter (constant)
gbarl    = xmatin(1,4);  % gw = productivity growth of incubments (before spillovers)
delta	= xmatin(1,5);  % delta = exogenous death rate
phi     = xmatin(:,6);  % phi = barriers to technology adoption (vector)
lambda  = xmatin(:,7);   % lambda = distance-to-frontier (vector)
% the number of rows of xmatin is equal to the number of periods.
% some parameters are the same throughout and some change through time.


%% Load transition variables
TT = length(xx(:,1));   % terminal period.
xhatt = xx(:,1);        % efficiency threshold
wt = xx(:,2);           % wages
qt = xx(:,3);           % bond price
mut = xx(:,4);          % mass of potential entrants
etat = xx(:,5);         % mass of firms
avgxt = xx(:,6);        % average efficiency

%% Aggregate variables
% Vector of xhat growth factors ( gt(tt) = avgx(tt)/avgx(tt-1) )
gt = [g;avgxt(2:TT)./avgxt(1:TT-1)];

% incumbent efficiency growth
gcht = gbarh^(1-epsilonh)*gt.^epsilonh;
gclt = gbarl^(1-epsilonl)*gt.^epsilonl;

% Output
Yt = wt/alpha;

% (wt/alpha).^(alpha/(1-alpha)) ...
%         - 1./Yt*gamma*(1-alpha)/(gamma*(1-alpha)-1).*xhatt.^(1/(1-alpha)).*etat

% etatest = zeros(TT,1);
% for tt=1:TT
%     for i=1:N
%         if tt-i+1>=1
%             muti = mut(tt-i+1);
%             phiti = phi(tt-i+1);
%             gci = prod(p*gcht(tt-i+2:tt).^gamma + (1-p)*gclt(tt-i+2:tt).^gamma);
%         else
%             muti = mut(1);
%             phiti = phi(1);
%             gci = prod(p*gcht(1:tt).^gamma + (1-p)*gclt(1:tt).^gamma)*(p*gch1^gamma + (1-p)*gcl1^gamma)^(-tt+i-1);
%         end
%         % measured productivity
%         etatest(tt) = etatest(tt) + (1-delta)^(i-1)*muti*phiti^(-gamma) ...
%             *g^(gamma*(tt-i+1))*gci*xhatt(tt)^(-gamma);
%     end
% end
%
% [etatest,etat]

% Mass of entrants
eta1 = mut.*(phi.*xhatt./g.^([1:TT]')).^(-gamma);

% Aggregate investment (real)
It = etat.*lambda.*f(1).*Yt + mut.*lambda.*kappa(1).*Yt;

% Aggregate capital stock
% (real)
Kt = etat.*lambda.*(kappa(1)+f(1)).*Yt + (mut-eta1).*lambda.*kappa(1).*Yt;
% (nominal)
Kt_nom = etat.*lambda.*(kappa+f).*Yt + (mut-eta1).*lambda.*kappa.*Yt;

%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl

% Compute aggregate depreciation rate of capital (forward looking)
deltak = min( 1 , ...
    1 - ( Kt(2:TT) - It(2:TT) )./Kt(1:TT-1) );
deltak(t) = deltak(1); % unanticipated reform
deltak = [deltak;deltak(TT-1)];

% Compute capital share
qt(t) = qt(1); % unanticipated reform

alphakt = ( 1./qt - (1-deltak)).*Kt_nom./Yt;
% To be consistent with the data, take averages
alphak = (alphakt(1:TT-1)+alphakt(2:TT))/2;
alphak = [alphakt(1); alphak]; % backward looking

% capital stock of firms at period tt (base year prices)
capitalt = Yt.*lambda.*( kappa(1) + f(1) );

%% Iniitalize vectors
FHKexit = zeros(TT,1);
FHKwithin = zeros(TT,1);
FHKreall = zeros(TT,1);
FHKcov = zeros(TT,1);

%% Compute FHK aggregate log productivity

% Create xgrid ~ [xhat,scalefactor*xhat]
scalefactor = 100000;
xN = 100000;
xgridt = zeros(xN,TT);
for tt=1:TT
    xgridt(:,tt) = linspace(0,(scalefactor*xhatt(tt)-xhatt(tt))^.5,xN);
    xgridt(:,tt) = xgridt(:,tt).^2;
    xgridt(:,tt) = xhatt(tt) + xgridt(:,tt);
end

DlogZt = zeros(TT,1);
DlogZt(1) = log(g)*(1-alphak(1));
logZt =  zeros(TT,1);
logZtl  = zeros(TT,1);

% Market share of entrants (t)
s_N_t = eta1./etat;
FHKentry = s_N_t;

% Share of all exiting firms, ages 1 to N (t-1)
s_X_tl = 1 - (1 - delta)* ...
    (p*(gt./gcht).^(1/(1-alpha)-gamma) + (1-p)*(gt./gclt).^(1/(1-alpha)-gamma) );

for tt=2:TT
    
    % Aggregate productivity (tt)
    % measured productivity
    ztxt = xgridt(:,tt)*capitalt(tt)^(-alphak(tt));
    logZt(tt) = (gamma*(1-alpha)-1)/(1-alpha) ...
        *xhatt(tt)^(gamma-1/(1-alpha)) ...
        *trapz(xgridt(:,tt),xgridt(:,tt).^(1/(1-alpha)-gamma-1) ...
        .*log( ztxt ) );
    
    % Aggregate productivity (tt-1)
    % measured productivity
    ztxtl = xgridt(:,tt-1)*capitalt(tt-1)^(-alphak(tt));
    logZtl(tt) = (gamma*(1-alpha)-1)/(1-alpha) ...
        *xhatt(tt-1)^(gamma-1/(1-alpha)) ...
        *trapz(xgridt(:,tt-1),xgridt(:,tt-1).^(1/(1-alpha)-gamma-1) ...
        .*log( ztxtl ) );
    
    DlogZt(tt) = logZt(tt) - logZtl(tt);
    
    %% Exit term    
    FHKexit(tt) = -(1-delta)*( ...
        p*( (gt(tt)/gcht(tt))^(1/(1-alpha)-gamma)*log(gt(tt)/gcht(tt)) ) ...
        +(1-p)*( (gt(tt)/gclt(tt))^(1/(1-alpha)-gamma)*log(gt(tt)/gclt(tt)) ) ...
        )/DlogZt(tt);
    
    %% Within and Reallocation terms
    FHKwithin(tt) = (1-delta)*( ...
        p*( log(gcht(tt)) - alphak(tt)*log(g) )*(gt(tt)/gcht(tt))^(1/(1-alpha)-gamma)  ...
        + (1-p)*( log(gclt(tt)) - alphak(tt)*log(g) )*(gt(tt)/gclt(tt))^(1/(1-alpha)-gamma) ...
        )/DlogZt(tt);
    
    FHKcov(tt) = (1-delta)*( ...
        p*( log(gcht(tt)) - alphak(tt)*log(g) )*(gt(tt)/gcht(tt))^(1/(1-alpha)-gamma)  ...
        *( (wt(tt)/(wt(tt-1)*gcht(tt)))^(1/(alpha-1)) - 1 ) ...
        + (1-p)*( log(gclt(tt)) - alphak(tt)*log(g) )*(gt(tt)/gclt(tt))^(1/(1-alpha)-gamma) ...
        *( (wt(tt)/(wt(tt-1)*gclt(tt)))^(1/(alpha-1)) - 1 ) ...
        )/DlogZt(tt);
    
    FHKreall(tt) = 1 - (FHKentry(tt) - FHKexit(tt) + FHKwithin(tt));
%     FHKreall_test(tt) = (1-delta)*( ...
%         p*( ((gt(tt)*wt(tt-1))/wt(tt))^(1/(1-alpha)) - (gt(tt)/gcht(tt))^(1/(1-alpha)) ) ...
%         *(gt(tt)/gcht(tt))^(-gamma) ...
%         +(1-p)*( ((gt(tt)*wt(tt-1))/wt(tt))^(1/(1-alpha)) - (gt(tt)/gclt(tt))^(1/(1-alpha)) ) ...
%         *(gt(tt)/gclt(tt))^(-gamma) ...
%         );

end
FHKentry(1) = FHKentry(2);
FHKexit(1) = FHKexit(2);
FHKwithin(1) = FHKwithin(2);
FHKreall(1) = FHKreall(2);

FHK_NE = FHKentry - FHKexit;



end
