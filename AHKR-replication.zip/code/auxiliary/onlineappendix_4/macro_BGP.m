function [waget, mut, xhat, eta, entryrate, joblossexit,deltak,alphak]=macro_BGP(xx,t)
% find macro variables for
% scalar values: [kappa f gamma gw delta phi lambda], t

global alpha g N beta p epsilonh epsilonl gbarh

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gbarl = xx(4);
delta = xx(5);
phi = xx(6);
lambda = xx(7); % distance from frontier Yt_F/Yt

% incumbent efficiency growth
gch = gbarh^(1-epsilonh)*g^epsilonh;
gcl = gbarl^(1-epsilonl)*g^epsilonl;

%% Compute BGP variables
omega = 0;
xi = 0;
for i=1:N
    temp = (1-delta)^(i-1)*g^(gamma*(1-i))* ...
        ( p*gch^gamma + (1-p)*gcl^gamma )^(i-1);
    xi = xi + beta^(i-1)*temp;
    omega = omega + temp;
end

% mass of potential entrants
mut = xi/omega/gamma/(lambda*kappa);

% mass of firms
eta = (gamma*(1-alpha)-1)/gamma/(f*lambda);

% efficiency threshold
xhat = g^t/phi*(omega/eta*mut)^(1/gamma);

% etatest=0;
% for i=1:N
%     etatest = etatest + g^(gamma*t)*mut*(1-delta)^(i-1)*phi^(-gamma) ...
%         *g^(gamma*(1-i))*(p*gc^gamma+(1-p))^(i-1)*xhat^(-gamma);
% end
% etatest

% wages and output
waget = alpha*((1-alpha)/(lambda*f))^(1-alpha)*xhat;
Yt = waget/alpha;

% entry rate
eta1 = mut*(xhat*phi/g^t)^(-gamma);
entryrate = eta1/eta;

% Compute jobs lost due to exit (percent of total jobs)
joblossexit = delta + (1-delta)*(p*(1-(g/gch)^(1/(1-alpha)-gamma) )...
    +(1-p)*(1-(g/gcl)^(1/(1-alpha)-gamma)) );

if nargout>6       
    % Capital stock
    Kt = eta*Yt*lambda*(kappa+f) + (mut-eta1)*Yt*lambda*kappa;
    % Investment
    It = eta*Yt*lambda*f + mut*Yt*lambda*kappa;
    
    % Lagged variables
    Ktl = Kt/g;
    
    % Compute aggregate depreciation rate of capital
    %Kt = (1-delta)Ktl + It
    % 1-delta = (Kt-It)/Ktl
    % delta = 1 - (Kt-It)/Ktl
    deltak = min( 1 , ...
        1 - g + It/Ktl );
    
    % Compute capital share
    alphak = ( g/beta - 1 + deltak )*Kt/Yt;

end

end