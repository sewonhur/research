function [entry_term,exit_term,within_term,cov_term,between_term,reall_term,DlogZt, ...
    s_X_tl]=FHK_BGP(xx,t)
% Compute FHK productivity decompositions given
% scalar values: [kappa f gamma gw delta,phi], t, l (lag)
% Use only for frontier economy if FCs scaled up by frontier output

global alpha g beta p epsilonh epsilonl gbarh

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gbarl = xx(4);
delta = xx(5);
phi = xx(6);
lambda = xx(7);

% incumbent efficiency growth
gch = gbarh^(1-epsilonh)*g^epsilonh;
gcl = gbarl^(1-epsilonl)*g^epsilonl;

% Macro variables
[waget, mu, xhat,  eta,  ~] = macro_BGP(xx,t);

% Output
Yt = waget/alpha;

% entrants
eta1 = mu*(phi*xhat/g^t)^(-gamma);

% Aggregate investment
It = eta*Yt*lambda*f + mu*Yt*lambda*kappa;

% Capital stock
Kt = eta*Yt*lambda*(kappa+f) + (mu-eta1)*Yt*lambda*kappa;

% Lagged variables
xhatl = xhat/g;
Ytl = Yt/g;
Ktl = Kt/g;

% Compute aggregate depreciation rate of capital
%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl
deltak = min( 1 , ...
    1 - g + It/Ktl );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;


%% Compute FHK contribution of net entry

% Compute FHK aggregate log productivity

% logZt for period t
% Create efficiency grid (t) ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capital = Yt*lambda*(kappa+f);
ztx = xgrid*capital^(-alphak); % measured productivity (t)

logZt = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha)) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*log( ztx ) );

% logZt for period t-l
% Create efficiency grid (t-l) ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitall = Ytl*lambda*(kappa+f);
ztxl = xgridl*capitall^(-alphak); % measured productivity (t-l)

logZtl = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridl,xgridl.^(1/(1-alpha)-gamma-1)...
    .*log( ztxl ) );

DlogZt = logZt - logZtl;


%% Compute FHK entry term

% Market share of entrants (t)
eta1 = mu*(phi*xhat/g^t)^(-gamma);

s_N_t = eta1/eta;

% FHK entry term
entry_term = s_N_t;

% Compute FHK exit term
% Share of all exiting firms, ages 1 to N (t-l)
s_X_tl = 1-(1-delta)*(p*(g/gch)^(1/(1-alpha)-gamma) + ...
    (1-p)*(g/gcl)^(1/(1-alpha)-gamma));

% Share of continuing firms, ages l to N (t-l)
% s_C_tl = 1-s_X_tl;

%% FHK exit term
% % Create efficiency grid for endogenous exiters with high growth ~ [xhatl,xhat/gch]
% xgridx = linspace(0,(xhat/gch-xhatl)^.5,xN);
% xgridx = xgridx.^2;
% xgridx = xhatl+xgridx;
% 
% ztxxl = xgridx*capitall^(-alphak); % measured productivity
% 
% exit_term = p*(1-delta)*...
%     (gamma*(1-alpha)-1)/(1-alpha) ...
%     *xhatl^(gamma-1/(1-alpha)) ...
%     *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
%     .*( log(ztxxl) - logZtl ) )/DlogZt;
% 
% % Create efficiency grid for endogenous exiters with low growth ~ [xhatl,xhat/gcl]
% xgridx = linspace(0,(xhat/gcl-xhatl)^.5,xN);
% xgridx = xgridx.^2;
% xgridx = xhatl+xgridx;
% 
% ztxxl = xgridx*capitall^(-alphak); % measured productivity
% 
% exit_term = exit_term+ (1-p)*(1-delta)*...
%     (gamma*(1-alpha)-1)/(1-alpha) ...
%     *xhatl^(gamma-1/(1-alpha)) ...
%     *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
%     .*( log(ztxxl) - logZtl ) )/DlogZt;

exit_term = -(1-delta)*( ...
        p*( (g/gch)^(1/(1-alpha)-gamma)*log(g/gch) ) ...
        +(1-p)*( (g/gcl)^(1/(1-alpha)-gamma)*log(g/gcl) ) ...
        )/DlogZt;

%% Within and reallocation terms
% Within term
within_term = (1-delta)*( ...
    p*( log(gch) - alphak*log(g) )*(g/gch)^(1/(1-alpha)-gamma) ...
    + (1-p)*( log(gcl) - alphak*log(g) )*(g/gcl)^(1/(1-alpha)-gamma) ...
    )/DlogZt;

cov_term = (1-delta)*( ...
    p*( log(gch) - alphak*log(g) )*(g/gch)^(1/(1-alpha)-gamma) ...
    *( (g/gch)^(1/(alpha-1)) - 1 ) ...
    + (1-p)*( log(gcl) - alphak*log(g) )*(g/gcl)^(1/(1-alpha)-gamma) ...
    *( (g/gcl)^(1/(alpha-1)) - 1 ) ...
    )/DlogZt;

between_term = (1-delta)*( ...
    p*( log(g) - log(gch) )*(g/gch)^(1/(1-alpha)-gamma) ...
    *( (g/gch)^(1/(alpha-1)) - 1 ) ...
    + (1-p)*( log(g) - log(gcl) )*(g/gcl)^(1/(1-alpha)-gamma) ...
    *( (g/gcl)^(1/(alpha-1)) - 1 ) ...
    )/DlogZt;

reall_term = (1-delta)*( ...
    p*( 1 - (g/gch)^(1/(1-alpha)) )*(g/gch)^(-gamma) ...
    + (1-p)*( 1 - (g/gcl)^(1/(1-alpha)) )*(g/gcl)^(-gamma)  ...
    );

end
