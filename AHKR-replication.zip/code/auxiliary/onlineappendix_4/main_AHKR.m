%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code for calibrating model and solving for transition     %
% Title: Firm Entry and Exit and Aggregate Growth           %
% Last updated: February 22, 2020                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear;

global alpha N T beta g period t kfratio p epsilonh epsilonl gbarh

%% Parameters %%
alpha = 0.67;               % Production function curvature (0.67)
N = 30;                     % Number of firm cohorts computed
period = 5;                 % Years in a period
t = 5;                      % Reform in t+1
beta = (0.98077)^period;    % Discount factor
g = (1.02)^period;          % Growth factor
kfratio = 0.82/period;      % technological entry cost / technological fixed cost
projecttype = 3;
% 1: for baseline, set epsilonh=epsilonl=0.64, gbarh=1, and p=0.00
% 2: for iid case, set epsilonh=1.00, epsilonl=0.00, gbarh=1, and p=0.64
% 3: for iid case (alternative), set epsilon=1.00 and p=0.64
if projecttype==1       % baseline
    p = 0;                  % Incumbent high growth probability
    epsilonh = 0.64;      	% Spillover (high-growth firm)
    epsilonl = 0.64;      	% Spillover (low-growth firm)
    gbarh = g;
elseif projecttype==2   % iid case
    p = 0.64;             	% Incumbent high growth probability
    epsilonh = 1;           % Spillover (high-growth firm)
    epsilonl = 0;           % Spillover (low-growth firm)
    gbarh = 1;
elseif projecttype==3   % iid case
    p = 0.953;          	% Incumbent high growth probability
    epsilonh = 0.64;        % Spillover (high-growth firm)
    epsilonl = 0.64;        % Spillover (low-growth firm)
    gbarh = g;
end

%% Set routines to run %%
calibrateswitch = 1;        % Set = 1 to calibrate model
transitionswitch = 1;       % Set = 1 to run transitions
reformswitch = 1;           % Set reform type
% 0: no reform
% 1: kappa reform
% 2: phi reform

%% Calibration routine %%
% Initialize guess
f = 2.324131434149078;      % Technological fixed continuation cost
gamma = 6.097910049485414;	% Pareto tail parameter
gbarl = 0.720537602160011;   % rate of low efficiency growth
delta = 0.180988309481024;	% Exogenous death rate

xguess = [f; gamma; gbarl; delta];

% Run calibration
if calibrateswitch
    fprintf(' \n ************** \n')
    fprintf('\n Calibration ... \n')
    fpass = @(x) calibration(x);
    [x,fval,exitflag] = fsolve(fpass,xguess);
    fprintf(' ... Calibration completed \n')
    format long
    x
    format short 
else
    x = xguess;
end

% Set up vector of parameters
gamma0 = x(2);
kappa0 = kfratio*x(1);	% set kappa = kappa_f_ratio*f
f0 = x(1);
phi0 = 1;               % set phi = 1 (frontier)
lambda0 = 1;            % set Lambda0 = 1 (frontier)
params0 = [kappa0; x; phi0; lambda0];    % include kappa, phi, and lambda
[wage, mu, xhat, eta, entryrate, joblossexit, deltak, alphak] ...
    = macro_BGP(params0,t);
params0 = [params0; alphak];    % include alphak

yy = zeros(1000,4);
for tt=1:1000
[yy(tt,1),yy(tt,2),yy(tt,3),yy(tt,4)]  = macro_BGP(params0,tt);
yy(tt,1) = yy(tt,1)/g^(tt);
yy(tt,3) = yy(tt,3)/g^(tt);
end

% Calibration Parameters
fprintf(' \n ************** \n')
fprintf('\n -- Calibration Parameters -- \n')
fprintf(' Entry cost (kappa): %f\n', kappa0);
fprintf(' Continuing cost (f annualized): %f\n', f0/period);
fprintf(' Pareto tail (gamma): %f\n', gamma0);
if projecttype==1
    fprintf(' Firm growth (gcl annualized): %f\n',(params0(4)^(1-epsilonl)*g^epsilonl)^(1/period));
else
    fprintf(' Low firm growth (gcl annualized): %f\n',(params0(4)^(1-epsilonl)*g^epsilonl)^(1/period));
    fprintf(' High firm growth (gch annualized): %f\n',(gbarh^(1-epsilonh)*g^epsilonh)^(1/period));
end
fprintf(' Exogenous death rate (annualized): %f\n', 1-(1-params0(5))^(1/period));
fprintf(' High growth prob (p): %f\n', p);


%% Report BGP results

% Decompositions in BGP
[netentryFHK, entrantshare, exitersharel] ...
    = decompositions_BGP(params0,t);

% Calibration Targets
fprintf('\n -- Calibration Targets -- \n')
fprintf(' Entry cost / continuation cost (annualized): %f\n', kappa0/(params0(2)/period));   % 0.82

gamma = params0(3);
avgfirm_size = 1/eta;
fprintf(' average firm size (employment): %f\n', avgfirm_size);  % 14
if gamma*(1-alpha) > 2
    firmvar = (1/eta)^2*...
        ( (gamma*(1-alpha)-1)^2 ...
        / (gamma*(1-alpha)-2) ...
        / (gamma*(1-alpha) ) - 1 );
    fprintf(' standard deviation firm size (employment): %f\n',sqrt(firmvar)); % 89
else
    
    fprintf(' standard deviation firm size (employment): NaN');
end
fprintf(' FHK effect of net entry on productivity growth (percent): %f\n', netentryFHK*100);   % 25
fprintf(' Jobs destroyed via exit (percent of total jobs): %f\n', joblossexit*100); % 19.33


% Other Statistics
fprintf('\n -- FHK decompositions -- \n')
fprintf(' effect of net entry on productivity growth (percent): %f\n', netentryFHK*100);

[entryFHK, exitFHK, withinFHK, covFHK, betweenFHK, reallocationFHK, DlogZ] ...
    = FHK_BGP(params0,t);
fprintf(' effect of entry on productivity growth (percent): %f\n', entryFHK*100);
fprintf(' effect of exit on productivity growth (percent): %f\n', -exitFHK*100);
fprintf(' effect of within-firm growth on productivity growth (percent): %f\n', withinFHK*100);
fprintf(' effect of covariance on productivity growth (percent) %f\n', covFHK*100);
fprintf(' effect of between-effect on productivity growth (percent) %f\n', betweenFHK*100);

fprintf('\n -- Decomposing the FHK entry term -- \n')
fprintf(' FHK aggregate productivity change (percent): %f\n', DlogZ*100)
fprintf(' FHK entry term: %f\n', entryFHK*DlogZ*100)
fprintf(' entrant market share: %f\n', entrantshare);
fprintf(' relative entrant productivity: %f\n', entryFHK*DlogZ/entrantshare*100);

fprintf('\n -- Decomposing the FHK exit term -- \n')
fprintf(' FHK aggregate productivity change (percent): %f\n', DlogZ*100)
fprintf(' FHK exit term: %f\n', -exitFHK*DlogZ*100)
fprintf(' exiter market share: %f\n', exitersharel);
fprintf(' relative exiter productivity: %f\n', exitFHK*DlogZ/exitersharel*100);

%% Solve for transition

% Transition parameters
params1 = params0;
if reformswitch == 1 % reform kappa
    params1(1) = (1/0.85)^(alpha*gamma0)*params0(1); % increase kappa
elseif reformswitch == 2 % reform phi
    params1(6) = (1/0.85)^alpha*params0(6); % increase phi
end

% Number of transition periods (set large enough)
T = N+10;

if transitionswitch
    
    % Set matrix of parameters
    xmat = repmat(params0',[T+2,1]);
    xmat(1,:) = params1;    
    
    % Lambda is used as a parameter in BGP analysis, but is endogenous in transition
    % Compute time 0 Lambda using eq (30) in paper
    lambda1 = (params1(2)/params0(2)).^((gamma0*(1-alpha)-1)/gamma0/alpha) ...
        .*(params1(6)/params0(6)).^(1/alpha) ...
        .*(params1(1)/params0(1)).^(1/gamma0/alpha);
    params1(7) = lambda1;
    xmat(:,7) = 1;
    xmat(1,7) = params1(7);
    
    % Initialize vectors for xhat(t) and mu(t)
    xhatt = zeros(T+2,1);
    mut = zeros(T+2,1);
    
    % Initial conditions
    [~, mut(1), xhatt(1)] = macro_BGP(xmat(1,:),t);
    
    % Terminal conditions and set guesses for transition
    for tt=2:T+2
        [~, mut(tt), xhatt(tt)] = macro_BGP(xmat(tt,:),t+tt-1);
    end
    avgxt = gamma0/(gamma0-1)*xhatt; % Average efficiency
    ymat = [xhatt,mut];
    
    icmat = ymat(1,:); % intial conditions
    tcmat = ymat(T+2,:); % terminal conditions
    tmat = ymat(2:T+1,:); % guess for transition
    
    % Solve for transtion
    fprintf(' \n ************** \n')
    fprintf('\n Solving for transition ...\n')
    fpass = @(x)transfun(x,icmat,tcmat,xmat);
    [x,fval,exitflag] = fsolve(fpass,tmat);
    ymat(2:T+1,:) = x;
    xhatpath = ymat(:,1);
    mupath = ymat(:,2);
    fprintf(' ... Transition solved \n')
    
    % Extend series to include periods 1,2,..,t-1
    lintrend = g.^(linspace(1-t,-1,t-1)');
    xhatpath = [xhatpath(1)*lintrend; xhatpath];    % linear trend for xhat
    avgxpath = gamma0/(gamma0-1)*xhatpath;
    for tt=t-1:-1:1
        mupath = [mupath(1); mupath];               % constant trend for mu
        xmat = [xmat(1,:); xmat];                   % also extend parameters
    end
    kappapath = xmat(:,1);
    fpath = xmat(:,2);
    deltapath = xmat(:,5);
    phipath = xmat(:,6);
    
    % Construct macro variables
    Npath = length(mupath);
    delta1 = params1(5);
    % average efficiency growth
    gt = [g; avgxpath(2:Npath)./avgxpath(1:Npath-1,1)];
    
    etapath = mupath*0;     % Initialize mass of firms
    entrypath = mupath*0;   % Initialize entry rate
    
    % Initialize mass of firms and entry rate
    [ ~, ~, ~, etapath(1), entrypath(1) ] = macro_BGP(xmat(1,:),1);
    
    % Frontier GDP (no distortions)
    YtFpath = 0*xhatpath;
    YtFpath(Npath) = ((1-alpha)/fpath(Npath))^(1-alpha)*xhatpath(Npath);
    for tt=Npath-1:-1:1
        YtFpath(tt) = YtFpath(tt+1)/g;
    end
    
    % Domestic GDP
    Ypath = (...
        ((1-alpha)./(fpath.*YtFpath)).^(1-alpha).*xhatpath...
        ).^(1/alpha);
    wagepath = alpha*Ypath;
    DlogYtpath = log(Ypath(2:Npath)./Ypath(1:Npath-1));
    DlogYtpath = [DlogYtpath(1);DlogYtpath];
    
    % Update vector of lambdas
    lambdapath = YtFpath./Ypath;
    xmat(:,7) = lambdapath;
    
    % Mass of firms
    etapath = (gamma0*(1-alpha)-1)./(gamma0*lambdapath.*fpath);
    entrypath = mupath.*(xhatpath.*phipath).^(-gamma0).*g.^(gamma0*[1:1:Npath]')./etapath;
      
    % Exit rates
    exitpath = etapath(1:Npath-1) - etapath(2:Npath) + etapath(2:Npath).*entrypath(2:Npath);    
    exitpath = exitpath./etapath(1:Npath-1);
    exitpath = [exitpath(1); exitpath];
    
    % Consumption and capital income
    Cpath = Ypath.*( 1 - lambdapath.*( etapath.*fpath  + mupath.*kappapath ) );
    Apath = Ypath.*( 1 - alpha  ...
        - lambdapath.*( etapath.*fpath  + mupath.*kappapath ) );
    
    % Bond price ( q(tt) = beta*C(tt)/C(tt+1) )
    qpath = [beta*Cpath(1:Npath-1)./Cpath(2:Npath); beta/g];
    qpath(t) = beta/g; % unanticipated reform in period t+1
    
    % Matrix of transition macro variables
    ymatnew = [xhatpath,wagepath,qpath,mupath,etapath,avgxpath];
    
    % FHK decompositions
    [ DlogZtFHK, netentryFHKpath, ...
        FHKentrypath, FHKexitpath, FHKwithinpath, FHKcovpath, FHKreallpath, ...
        entrantsharepath, exitersharepath, Kpath, deltakpath, ...
        alphakpath, firmcapitalpath ] ...
         = decompositions_transition(ymatnew,xmat);
    
    % Report transition FHK results
    fprintf('\nFHK Productivity Growth Decomposition (5 year windows)')
    if reformswitch == 2
        reformpath = phipath;
        fprintf('\n Model      | Tech  | GDPWAP      | FHK agg prod | Growth accounted ' )
        fprintf('\n periods    | barr  | ann. growth | ann. growth  | for by net entry ' )
    elseif reformswitch == 3
        reformpath = fpath/period;
        fprintf('\n Model      | Cont. | GDPWAP      | FHK agg prod | Growth accounted ' )
        fprintf('\n periods    | cost  | ann. growth | ann. growth  | for by net entry ' )
    else
        reformpath = kappapath;
        fprintf('\n Model      | Entry | GDPWAP      | FHK agg prod | Growth accounted ' )
        fprintf('\n periods    | cost  | ann. growth | ann. growth  | for by net entry ' )
    end
    fprintf('\n            |       | (percent)   | (percent)    | (percent)' )
    fprintf('\n -------------------------------------------------------' )
    fprintf('\n 1-%1i (BGP)  |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f',t,...
        sum(reformpath(1:t,1))/t,...
        ((Ypath(t)/Ypath(1))^(1/(t-1)))^(1/period)*100-100,...
        ((exp(sum(DlogZtFHK(2:t))))^(1/(t-1)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(1:t))^(1/t)*100-100 )
    fprintf('\n %1i (reform) |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f',t+1,...
        reformpath(t+1,1),...
        (Ypath(t+1)/Ypath(t))^(1/period)*100-100,...
        ((exp(DlogZtFHK(t+1))))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+1))*100-100 )
    fprintf('\n 7          | % 2.2f  |  %3.1f      |   %3.1f     | %3.1f',...
        reformpath(7),...
        (Ypath(t+2)/Ypath(t+1))^(1/period)*100-100,...
        ((exp(DlogZtFHK(t+2))))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+2))*100-100 )
    fprintf('\n 8          |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f',...
        reformpath(8),...
        (Ypath(t+3)/Ypath(t+2))^(1/period)*100-100,...
        ((exp(DlogZtFHK(t+3))))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+3))*100-100 )
    fprintf('\n 9+         |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f\n', ...
        sum(reformpath(t+4:Npath,1))/(Npath-t-3),...
        ((Ypath(Npath)/Ypath(t+3))^(1/(Npath-t-3)))^(1/period)*100-100,...
        ((exp(sum(DlogZtFHK(t+4:Npath))))^(1/(Npath-t-3)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+4:Npath))^(1/(Npath-t-3))*100-100 )
    
    fprintf('\n FHK Productivity Growth Decompositions')
    fprintf('\n model      | FHK prod. | FHK    | FHK    | FHK     | FHK     ' )
    fprintf('\n periods    | change    | entry  | exit   | within  | reallocation  ' )
    fprintf('\n -----------------------------------------------------------------' )
    fprintf('\n 5 (BGP)    | %3.2f      | %3.2f	 | %3.2f   | %3.2f    | %3.2f ',...
        DlogZtFHK(t)*100,FHKentrypath(t)*100,-FHKexitpath(t)*100, ...
        FHKwithinpath(t)*100,FHKreallpath(t)*100)
    fprintf('\n 6 (reform) | %3.2f     | %3.2f	 | %3.1f   | %3.2f    | %3.2f\n',...
        DlogZtFHK(t+1)*100,FHKentrypath(t+1)*100,-FHKexitpath(t+1)*100, ...
        FHKwithinpath(t+1)*100,FHKreallpath(t+1)*100)
    
    fprintf('\n FHK Entry Decomposed')
    fprintf('\n model      | FHK    | entry  | entrant      | relative entrant ' )
    fprintf('\n periods    | entry  | rate   | market share | productivity  ' )
    fprintf('\n --------------------------------------------------------------------------' )
    fprintf('\n 5 (BGP)    | %3.2f   | %3.2f  | %3.2f         | %3.2f',...
        DlogZtFHK(t)*FHKentrypath(t)*100,entrypath(t)*100, ...
        entrantsharepath(t),DlogZtFHK(t)*FHKentrypath(t)/entrantsharepath(t)*100)
    fprintf('\n 6 (reform) | %3.2f	 | %3.2f  | %3.2f         | %3.2f\n',...
        DlogZtFHK(t+1)*FHKentrypath(t+1)*100,entrypath(t+1)*100, ...
        entrantsharepath(t+1),DlogZtFHK(t+1)*FHKentrypath(t+1)/entrantsharepath(t+1)*100)
    
    fprintf('\n FHK Exit Decomposed')
    fprintf('\n model      | FHK    | exiter       | relative exiter ' )
    fprintf('\n periods    | exit   | market share | productivity  ' )
    fprintf('\n -----------------------------------------------------------' )
    fprintf('\n 5 (BGP)    | %3.2f   | %3.2f       | %3.2f',...
        -DlogZtFHK(t)*FHKexitpath(t)*100,exitersharepath(t),...
        DlogZtFHK(t)*FHKexitpath(t)/exitersharepath(t)*100)
    fprintf('\n 6 (reform) | %3.2f	 | %3.2f       | %3.2f\n',...
        -DlogZtFHK(t+1)*FHKexitpath(t+1)*100,exitersharepath(t+1),...
        DlogZtFHK(t+1)*FHKexitpath(t+1)/exitersharepath(t+1)*100)
    
    filename = 'modeloutput.xlsx';
    header = {'kappa' 'phi' 'f' 'mu' 'eta' 'wage' 'output' 'xhat' ...
        'entry' 'exit' 'C' 'q' 'K' 'deltak' 'alphak' 'DlogZtFHK' ...
        'DlogYt' 'FHK_NE' 'FHK_entry' 'FHK_exit' 'FHK_within' ...
        'FHK_reall' 'ent_share' 'exit_share' 'rel_ent_prod' ...
        'rel_exit_prod'};
    
    reformtype = sprintf('noreform');
    if reformswitch == 1
        reformtype = sprintf('kappareform');
    elseif reformswitch == 2
        reformtype = sprintf('phireform');
    elseif reformswitch == 3
        reformtype = sprintf('freform');
    end
    xlswrite(filename, header, reformtype);
    xlswrite(filename, kappapath, reformtype, 'A2');
    xlswrite(filename, phipath, reformtype, 'B2');
    xlswrite(filename, fpath, reformtype, 'C2');
    xlswrite(filename, mupath, reformtype, 'D2');
    xlswrite(filename, etapath, reformtype, 'E2');
    xlswrite(filename, wagepath, reformtype, 'F2');
    xlswrite(filename, Ypath, reformtype, 'G2');
    xlswrite(filename, xhatpath, reformtype, 'H2');
    xlswrite(filename, entrypath, reformtype, 'I2');
    xlswrite(filename, exitpath, reformtype, 'J2');
    xlswrite(filename, Cpath, reformtype, 'K2');
    xlswrite(filename, qpath, reformtype, 'L2');
    xlswrite(filename, Kpath, reformtype, 'M2');
    xlswrite(filename, deltakpath, reformtype, 'N2');
    xlswrite(filename, alphakpath, reformtype, 'O2');
    xlswrite(filename, DlogZtFHK, reformtype, 'P2');
    xlswrite(filename, DlogYtpath, reformtype, 'Q2');
    xlswrite(filename, netentryFHKpath, reformtype, 'R2');
    xlswrite(filename, FHKentrypath, reformtype, 'S2');
    xlswrite(filename, FHKexitpath, reformtype, 'T2');
    xlswrite(filename, FHKwithinpath, reformtype, 'U2');
    xlswrite(filename, FHKreallpath, reformtype, 'V2');
    xlswrite(filename, entrantsharepath, reformtype, 'W2');
    xlswrite(filename, exitersharepath, reformtype, 'X2');
    xlswrite(filename, DlogZtFHK.*FHKentrypath./entrantsharepath, reformtype, 'Y2');
    xlswrite(filename, DlogZtFHK.*FHKexitpath./exitersharepath, reformtype, 'Z2');
    
    xlswrite(filename, {'kappa' 'f' 'gamma' 'gw' 'delta' 'phi' 'lambda' 'alpha' 'epsilon' 'p'}, 'parameters')
    xlswrite(filename, params0', 'parameters', 'A2')
    xlswrite(filename, alpha, 'parameters', 'H2')
    xlswrite(filename, epsilonl, 'parameters', 'I2')
    xlswrite(filename, p, 'parameters', 'J2')
    
end






