function fval = transfun(tmat,icmat,tcmat,xmat)
% given a transition path [tmat,icmat,tcmat]
% and scalar values: [kappa f gamma p delta phi]
% generate errors

global alpha t N beta g T p epsilonh epsilonl gbarh

%% Read inputs
% ymat  = [xhatt(T+2,1),mut(T+2,1)];
ymatin  = [icmat;tmat;tcmat];
% x0    = [kappa, f, gamma, gbar, delta, phi ]
kappa   = xmat(:,1);
f       = xmat(:,2);
gamma 	= xmat(1,3);
gbarl    = xmat(1,4);
delta   = xmat(1,5);
phi     = xmat(:,6);

xhatt = ymatin(:,1);
mut = ymatin(:,2);

%% Frontier and domestic GDP
% Frontier GDP
YtF = 0*xhatt;
YtF(T+2) = ((1-alpha)/f(T+2))^(1-alpha)*xhatt(T+2);
for tt=T+1:-1:1
    YtF(tt) = YtF(tt+1)/g;
end

% Domestic GDP
Yt = (...
    ((1-alpha)./(f.*YtF)).^(1-alpha).*xhatt...
    ).^(1/alpha);

%% Extend series
for j=1:N 
    xhatt = [xhatt;xhatt(T+j+1)*g];
    YtF = [YtF;YtF(T+j+1)*g];
    Yt = [Yt;Yt(T+j+1)*g];
    mut = [mut;mut(T+2)];
    kappa = [kappa;kappa(T+2)];
    f = [f;f(T+2)];
    phi = [phi;phi(T+2)];
end
avgxt = gamma/(gamma-1)*xhatt;
lambdat = YtF./Yt;


%% Growth factors
gt = avgxt(2:T+N+2,1)./avgxt(1:T+N+1,1); 
gt = [g;gt]; % backward-looking growth: gt(tt+1) = xhat(tt+1)/xhat(tt)

% incumbent efficiency growth
gcht = gbarh^(1-epsilonh)*gt.^epsilonh;
gclt = gbarl^(1-epsilonl)*gt.^epsilonl;
gch1 = gbarh^(1-epsilonh)*g^epsilonh;
gcl1 = gbarl^(1-epsilonl)*g^epsilonl;


%% Mass of firms
etat = (gamma*(1-alpha)-1)./(gamma.*lambdat.*f);

%% Prices
Ct = Yt.*( 1 - lambdat.*( etat.*f + mut.*kappa ) );
qt = beta*Ct(1:T+N+1)./Ct(2:T+N+2);
qt(1) = beta/g;     % unexpected reform
qt = [beta/g;qt];	% backward-looking prices: qt(tt+1) = beta*ct(tt)/ct(tt+1)


%% Compute error terms (to be minimized)

fval = 1*tmat;

for tt = 2:T+1
    lmsum = 0;  % labor market clearing condition
    fesum = 0;  % free entry condition
    for i=1:N
        if tt-i+1>=1
            muti = mut(tt-i+1);
            phiti = phi(tt-i+1);
            gci = prod(p*gcht(tt-i+2:tt).^gamma + (1-p)*gclt(tt-i+2:tt).^(gamma));
        else
            muti = mut(1);
            phiti = phi(1);
            gci = prod(p*gcht(1:tt).^gamma + (1-p)*gclt(1:tt).^gamma)*(p*gch1^gamma + (1-p)*gcl1^gamma)^(-tt+i-1);
        end
        % labor market clearing sums up existing cohorts
        lmsum = lmsum + phiti^(-gamma)...
            *muti*(1-delta)^(i-1)*g^(gamma*(1-i))*gci;    
        % free entry condition sums up over future periods
        fesum = fesum + (1-delta)^(i-1) ...
                *prod( qt(tt+1:tt+i-1) ) ...
                *Yt(tt+i-1)/Yt(tt)*xhatt(tt+i-1)^(-gamma) ...
                /etat(tt+i-1)*prod(p*gcht(tt+1:tt+i-1).^gamma + (1-p)*gclt(tt+1:tt+i-1).^gamma);     
    end
    % Labor market clearing condition
    fval(tt-1,1) = etat(tt) - g^(gamma*(t+tt-1))*...
        xhatt(tt)^(-gamma)*lmsum;
    % Free entry condition
    fval(tt-1,2) = kappa(tt) ...
        - g^(gamma*(t+tt-1))*phi(tt)^(-gamma)/gamma/lambdat(tt)*fesum;
end

end