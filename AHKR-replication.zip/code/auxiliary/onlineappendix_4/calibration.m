function fval=calibration(xguess)
% solve model with [f, gamma, gw, delta] to firm size statistics, FHK
% contribution of net entry, and fraction of jobs destroyed by exit

global t N alpha kfratio g beta p epsilonh epsilonl gbarh

f = xguess(1);       	% Fixed continuation cost
gamma = xguess(2);   	% Pareto tail parameter
gbarl = xguess(3);     	% Continuing firm growth term
delta = xguess(4);      % Exogenous death rate
kappa  = f*kfratio;  	% Entry cost (no policy distortions in frontier)
phi = 1;                % No adoption barriers in frontier

% incumbent efficiency growth
gch = gbarh^(1-epsilonh)*g^epsilonh;
gcl = gbarl^(1-epsilonl)*g^epsilonl;

if gcl<=gch && gcl>0 && delta>0

%% Compute BGP variables
omega = 0;
xi = 0;
for i=1:N
    temp = (1-delta)^(i-1)*g^(gamma*(1-i))* ...
        ( p*gch^gamma + (1-p)*gcl^gamma )^(i-1);
    xi = xi + beta^(i-1)*temp;
    omega = omega + temp;
end

% mass of potential entrants
mu = xi/omega/gamma/(kappa);

% mass of firms
eta = (gamma*(1-alpha)-1)/gamma/(f);

% efficiency threshold
xhat = g^t/phi*(omega*mu/eta)^(1/gamma);

% wages and output
waget = alpha*((1-alpha)/(f))^(1-alpha)*xhat;
Yt = waget/alpha;

% entrants
eta1 = mu*(phi*xhat/g^t)^(-gamma);

% Compute jobs lost due to exit (percent of total jobs)
joblossexit = delta + (1-delta)*(p*(1-(g/gch)^(1/(1-alpha)-gamma) )...
    +(1-p)*(1-(g/gcl)^(1/(1-alpha)-gamma)) );

% Aggregate investment
It = eta*Yt*f + mu*Yt*kappa;

% Capital stock
Kt = eta*Yt*(kappa+f) + (mu-eta1)*Yt*kappa;

% Lagged variables
xhatl = xhat/g;
Ytl = Yt/g;
Ktl = Kt/g;

% Compute aggregate depreciation rate of capital
%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl
deltak = min( 1 , ...
    1 - g + It/Ktl );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;

%% Compute FHK contribution of net entry

% Compute FHK aggregate log productivity

% logZt for period t
% Create efficiency grid (t) ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capitalx = Yt*(kappa+f);
ztx = xgrid*capitalx^(-alphak); % measured productivity (t)

logZt = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha)) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*log( ztx ) );

% logZt for period t-1
% Create efficiency grid (t-1) ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitalxl = Ytl*(kappa+f);
ztxl = xgridl*capitalxl^(-alphak); % measured productivity (t-1)

logZtl = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridl,xgridl.^(1/(1-alpha)-gamma-1)...
    .*log( ztxl ) );

DlogZt = logZt - logZtl;


%% FHK entry term
% Market share of entrants (t)
s_N_t = eta1/eta;
FHKentry = s_N_t;

%% FHK exit term
FHKexit = -(1-delta)*( ...
        p*( (g/gch)^(1/(1-alpha)-gamma)*log(g/gch) ) ...
        +(1-p)*( (g/gcl)^(1/(1-alpha)-gamma)*log(g/gcl) ) ...
        )/DlogZt;
% % Create efficiency grid for endogenous exiters with high growth ~ [xhatl,xhat/gch]
% xgridx = linspace(0,(xhat/gch-xhatl)^.5,xN);
% xgridx = xgridx.^2;
% xgridx = xhatl+xgridx;
% 
% ztxxl = xgridx*capitalxl^(-alphak); % measured productivity
% 
% FHKexit = p*(1-delta)*...
%     (gamma*(1-alpha)-1)/(1-alpha) ...
%     *xhatl^(gamma-1/(1-alpha)) ...
%     *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
%     .*( log(ztxxl) - logZtl ) )/DlogZt;
% 
% % Create efficiency grid for endogenous exiters with low growth ~ [xhatl,xhat/gcl]
% xgridx = linspace(0,(xhat/gcl-xhatl)^.5,xN);
% xgridx = xgridx.^2;
% xgridx = xhatl+xgridx;
% 
% ztxxl = xgridx*capitalxl^(-alphak); % measured productivity
% 
% FHKexit = FHKexit+ (1-p)*(1-delta)*...
%     (gamma*(1-alpha)-1)/(1-alpha) ...
%     *xhatl^(gamma-1/(1-alpha)) ...
%     *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
%     .*( log(ztxxl) - logZtl ) )/DlogZt;

FHKnetentry = FHKentry - FHKexit;

%% Generate firm size statistics
% Average firm size
firmsize = 1/eta;

% Variance of firm size
firmvar = firmsize^2*...
    (...
    (gamma*(1-alpha)-1)^2/(gamma*(1-alpha)-2)/(gamma*(1-alpha))-1 ...
    );

%% Compute error terms
fval = 0*xguess;
fval(1) = firmsize - 14.0; % 14.0
fval(2) = sqrt(firmvar) - 88.95; % 88.95
fval(3) = FHKnetentry - 0.25; % 0.25
fval(4) = joblossexit - 0.1933; % 0.1933

else
    fval = 1000;
    
end

end