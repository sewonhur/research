function [waget, mut, xhat, eta, entryrate, joblossexit,deltak,alphak]=macro_BGP(xx,t)
% find macro variables for
% scalar values: [kappa f gamma gw delta phi lambda], t

global alpha g N beta epsilon

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gbar = xx(4);
delta = xx(5);
phi = xx(6);
lambda = xx(7); % distance from frontier Yt_F/Yt

gc = gbar*g^epsilon;

%% Compute BGP variables
omega = 0;
xi = 0;
for i=1:N
    omega = omega + (1-delta)^(i-1)*(g/gc)^(gamma*(1-i));
    xi = xi + (beta*(1-delta))^(i-1)*(g/gc)^(gamma*(1-i));
end

% mass of potential entrants
mut = xi/omega/gamma/(lambda*kappa);

% mass of firms
eta = (gamma*(1-alpha)-1)/gamma/(f*lambda);

% efficiency threshold
xhat = g^t/phi*(omega/eta*mut)^(1/gamma);

% wages and output
waget = alpha*((1-alpha)/(lambda*f))^(1-alpha)*xhat;
Yt = waget/alpha;

% entry rate
eta1 = mut*(xhat*phi/g^t)^(-gamma);
entryrate = eta1/eta;

% Compute jobs lost due to exit (percent of total jobs)
joblossexit = delta + (1-delta)*(1-(g/gc)^(1/(1-alpha)-gamma));

if nargout>6       
    % Capital stock
    Kt = eta*Yt*lambda*(kappa+f) + (mut-eta1)*Yt*lambda*kappa;
    % Investment
    It = eta*Yt*lambda*f + mut*Yt*lambda*kappa;
    
    % Lagged variables
    Ktl = Kt/g;
    
    % Compute aggregate depreciation rate of capital
    %Kt = (1-delta)Ktl + It
    % 1-delta = (Kt-It)/Ktl
    % delta = 1 - (Kt-It)/Ktl
    deltak = min( 1 , ...
        1 - g + It/Ktl );
    
    % Compute capital share
    alphak = ( g/beta - 1 + deltak )*Kt/Yt;

end

end