function [entry_term,exit_term,within_term,reall_term,DlogZt, ...
    MP_NE,GR_NE,s_X_tl]=FHK_BGP(xx,t,l)
% Compute FHK productivity decompositions given
% scalar values: [kappa f gamma gw delta,phi], t, l (lag)
% Use only for frontier economy if FCs scaled up by frontier output

global alpha g epsilon beta

kappa = xx(1);
f = xx(2);
gamma = xx(3);
gbar = xx(4);
delta = xx(5);
phi = xx(6);
lambda = xx(7);

% incumbent efficiency growth
gc = gbar*g^epsilon; % gbar=gw^(1-epsilon)

% Macro variables
[waget, mu, xhat,  eta,  ~] = macro_BGP(xx,t);

% Output
Yt = waget/alpha;

% entrants
eta1 = mu*(phi*xhat/g^t)^(-gamma);

% Aggregate investment
It = eta*Yt*lambda*f + mu*Yt*lambda*kappa;

% Capital stock
Kt = eta*Yt*lambda*(kappa+f) + (mu-eta1)*Yt*lambda*kappa;

% Lagged variables
xhatl = xhat/g^l;
Ytl = Yt/g^l;
Ktl = Kt/g;

% Compute aggregate depreciation rate of capital
%Kt = (1-delta)Ktl + It
% 1-delta = (Kt-It)/Ktl
% delta = 1 - (Kt-It)/Ktl
deltak = min( 1 , ...
    1 - g + It/Ktl );

% Compute capital share
alphak = ( g/beta - 1 + deltak )*Kt/Yt;


%% Compute FHK contribution of net entry

% Compute FHK aggregate log productivity

% logZt for period t
% Create efficiency grid (t) ~ [xhat,xmax]
scalefactor = 100000;
xN = 100000;
xgrid = linspace(0,(scalefactor*xhat-xhat)^.5,xN);
xgrid = xgrid.^2;
xgrid = xhat + xgrid;

capital = Yt*lambda*(kappa+f);
ztx = xgrid*capital^(-alphak); % measured productivity (t)

logZt = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha)) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*log( ztx ) );

% logZt for period t-l
% Create efficiency grid (t-l) ~ [xhatl,xmax]
xgridl = linspace(0,(scalefactor*xhatl-xhatl)^.5,xN);
xgridl = xgridl.^2;
xgridl = xhatl+xgridl;

capitall = Ytl*lambda*(kappa+f);
ztxl = xgridl*capitall^(-alphak); % measured productivity (t-l)

logZtl = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridl,xgridl.^(1/(1-alpha)-gamma-1)...
    .*log( ztxl ) );

DlogZt = logZt - logZtl;


% Compute FHK entry term

% Market share of entrants (t)
etae = mu*(phi*xhat/g^t)^(-gamma);
for i=2:l
    etai = mu*(1-delta)^(i-1)*(phi*xhat/g^t)^(-gamma)...
        *(g/gc)^(gamma*(1-i));
    etae = etae + etai;
end

s_N_t = etae/eta;

% FHK entry term
entry_term = s_N_t;

% Compute FHK exit term
% Share of continuing firms, ages l to N (t-l)
s_C_tl = (1-delta)^l*(g^l/gc^l)^(1/(1-alpha)-gamma);

% Share of all exiting firms, ages 1 to N (t-l)
s_X_tl = 1 - s_C_tl;

% Create efficiency grid for endogenous exiters ~ [xhatl,xhat/gc]
xgridx = linspace(0,(xhat/gc^l-xhatl)^.5,xN);
xgridx = xgridx.^2;
xgridx = xhatl+xgridx;

% measured productivity for exiters (t-l)
ztxxl = xgridx*capitall^(-alphak);

exit_term = (1-delta)*...
    (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
    .*( log(ztxxl) - logZtl ) )/DlogZt;

%% Within and reallocation terms
% measured productivity for continuing firms (t-l)
ztxcl = xgrid/gc^l*capitall^(-alphak);

% Within term
within_term = (gamma*(1-alpha)-1)/(1-alpha) ...
    *(xhatl*gc^l)^(-1/(1-alpha)) ...
    *xhat^gamma*(1-s_N_t) ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*( log(ztx) - log(ztxcl) ) )/DlogZt;


% Reallocation term (BGP)
reall_term = (1-s_N_t) ...
    *( 1 - (xhat/xhatl/gc^l)^( 1/(1-alpha) ) );

%% Other decompositions

% GR entry term
GRentry = (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhat^(gamma-1/(1-alpha))*s_N_t ...
    *trapz(xgrid,xgrid.^(1/(1-alpha)-gamma-1)...
    .*( log(ztx) - (logZt + logZtl)/2 ) )/DlogZt;

% GR exit term
GRexit = (1-delta)*...
    (gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridx,xgridx.^(1/(1-alpha)-gamma-1)...
    .*( log(ztxxl) - (logZt + logZtl)/2 ) )/DlogZt;

GR_NE = GRentry - GRexit;

% MP continuing term
% logZCt for period t-l
% Create xgrid ~ [xhat/gc,xmax/g]
xgridc = linspace(0,(scalefactor*xhat/gc^l-xhat/gc^l)^.5,xN);
xgridc = xgridc.^2;
xgridc = xhat/gc^l+xgridc;

capitalxc = Ytl*lambda*(kappa+f);
ztxc = xgridc*capitalxc^(-alphak); % measured productivity for continuing firms (t-l)

logZCtl = (1-delta)^l/s_C_tl ...
    *(gamma*(1-alpha)-1)/(1-alpha) ...
    *xhatl^(gamma-1/(1-alpha)) ...
    *trapz(xgridc,xgridc.^(1/(1-alpha)-gamma-1)...
    .*log( ztxc ) );

MPcont = (logZt - logZCtl)/DlogZt;

% MP net entry
MP_NE = 1 - MPcont;


end
