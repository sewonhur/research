%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code for calibrating model and solving for transition     %
% Title: Firm Entry and Exit and Aggregate Growth           %
% Last updated: February 4, 2017                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
addpath('./auxiliary/onlineappendix_1')
clear;

global alpha N T beta g period t epsilon kfratio

%% Parameters %%
alpha = 0.67;               % Production function curvature (0.67)
N = 30;                     % Number of firm cohorts computed
period = 5;                 % Years in a period
t = 4;                      % Reform in t+1
beta = (0.98077)^period;    % Discount factor
g = (1.02)^period;          % Growth factor
epsilon = 0.64;             % Spillover term (0.64)
kfratio = 0.82/period;      % technological entry cost / technological fixed cost

%% Set routines to run %%
calibrateswitch = 0;        % Set = 1 to calibrate model
transitionswitch = 1;       % Set = 1 to run transitions
reformswitch = 1;           % Set reform type
% 0: no reform
% 1: kappa reform
% 2: phi reform
% 3: f reform

%% Calibration routine %%
% Initialize guess
f = 3.468852886789670;      % Technological fixed continuation cost
gamma = 6.097910049485417;	% Pareto tail parameter
gw = 1.092580074388909;  	% gbar^(1/(1-epsilon))
delta = 0.183917381737720;	% Exogenous death rate

xguess = [f; gamma; gw; delta];

% Run calibration
if calibrateswitch
    fprintf(' \n ************** \n')
    fprintf('\n Calibration ... \n')
    fpass = @(x) calibration(x);
    [x,fval,exitflag] = fsolve(fpass,xguess);
    fprintf(' ... Calibration completed \n')
else
    x = xguess;
end

% Set up vector of parameters
gamma0 = x(2);
kappa0 = kfratio*x(1);	% set kappa = kappa_f_ratio*f
f0 = x(1);
phi0 = 1;               % set phi = 1 (frontier)

params0 = [kappa0; x; phi0];    % include kappa, phi
[wage, Yt, mu, xhat, eta, entryrate, joblossexit, deltak, alphak] ...
    = macro_BGP(params0,t);
params0 = [params0; alphak];    % include alphak

% Calibration Parameters
fprintf(' \n ************** \n')
fprintf('\n -- Calibration Parameters -- \n')
fprintf(' Entry cost (kappa): %f\n', kappa0);
fprintf(' Continuing cost (f annualized): %f\n', f0/period);
fprintf(' Pareto tail (gamma): %f\n', gamma0);
fprintf(' Continuing firm growth (gc annualized): %f\n',(params0(4)^(1-epsilon)*g^epsilon)^(1/period));
fprintf(' Exogenous death rate (annualized): %f\n', 1-(1-params0(5))^(1/period));
% fprintf(' gbar annualized: %f\n', (params0(4)^(1-epsilon))^(1/period));


%% Report BGP results

% Decompositions in BGP
[netentryFHK, entryFHK, exitFHK, DlogZ, entrantshare, exitersharel] ...
    = decompositions_BGP(params0,t);

% Calibration Targets
fprintf('\n -- Calibration Targets -- \n')
fprintf(' Entry cost / continuation cost (annualized): %f\n', kappa0/(params0(2)/period));   % 0.82

gamma = params0(3);
avgfirm_size = gamma*alpha*f0/(gamma*(1-alpha)-1);
fprintf(' average firm size (employment): %f\n', avgfirm_size);  % 14
if gamma*(1-alpha) > 2
    firmvar = avgfirm_size^2*...
        ( (gamma*(1-alpha)-1)^2 ...
        / (gamma*(1-alpha)-2) ...
        / (gamma*(1-alpha) ) - 1 );
    fprintf(' standard deviation firm size (employment): %f\n',sqrt(firmvar)); % 89
else
    
    fprintf(' standard deviation firm size (employment): NaN');
end
fprintf(' FHK effect of net entry on productivity growth (percent): %f\n', netentryFHK*100);   % 25
fprintf(' Jobs destroyed via exit (percent of total jobs): %f\n', joblossexit*100); % 19.33

%% Solve for transition

% Transition parameters
params1 = params0;
if reformswitch == 1 % reform kappa
    params1(1) = (1/0.85)^gamma0*params0(1); % increase kappa
elseif reformswitch == 2 % reform phi
    params1(6) = (1/0.85)*params0(6); % increase phi
elseif reformswitch == 3 % reform f
    params1(2) = (1/0.85)^(gamma0/(gamma0*(1-alpha)-1))*params0(2); % increase f
end

% Number of transition periods (set large enough)
T = N+10;

if transitionswitch
    
    % Set matrix of parameters
    xmat = repmat(params0',[T+2,1]);
    xmat(1,:) = params1;
    
    % Initialize vectors for xhat(t) and mu(t)
    xhatt = zeros(T+2,1);
    mut = zeros(T+2,1);
    
    % Initial conditions
    [~, ~, mut(1), xhatt(1)] = macro_BGP(xmat(1,:),t);
    
    % Terminal conditions and set guesses for transition
    for tt=2:T+2
        [~, ~, mut(tt), xhatt(tt)] = macro_BGP(xmat(tt,:),t+tt-1);
    end
    avgxt = gamma0/(gamma0-1)*xhatt; % Average efficiency
    ymat = [xhatt,mut,avgxt];
    
    icmat = ymat(1,:); % intial conditions
    tcmat = ymat(T+2,:); % terminal conditions
    tmat = ymat(2:T+1,:); % guess for transition
    
    % Solve for transtion
    fprintf(' \n ************** \n')
    fprintf('\n Solving for transition ...\n')
    fpass = @(x)transfun(x,icmat,tcmat,xmat);
    [x,fval,exitflag] = fsolve(fpass,tmat);
    ymat(2:T+1,:) = x;
    xhatpath = ymat(:,1);
    mupath = ymat(:,2);
    avgxpath = ymat(:,3);
    fprintf(' ... Transition solved \n')
    
    % Extend series to include periods 1,2,..,t-1
    lintrend = g.^(linspace(1-t,-1,t-1)');
    xhatpath = [xhatpath(1)*lintrend; xhatpath];    % linear trend for xhat
    avgxpath = [avgxpath(1)*lintrend; avgxpath];	% linear trend for avg(x)
    for tt=t-1:-1:1
        mupath = [mupath(1); mupath];               % constant trend for mu
        xmat = [xmat(1,:); xmat];                   % also extend parameters
    end
    kappapath = xmat(:,1);
    fpath = xmat(:,2);
    gwpath = xmat(:,4);
    deltapath = xmat(:,5);
    phipath = xmat(:,6);
    
    % Construct macro variables
    Npath = length(mupath);
    gt = [g; avgxpath(2:Npath)./avgxpath(1:Npath-1,1)];
    gct = gwpath.^(1-epsilon).*max(1,gt.^epsilon); % gct in transition
    gw1 = params1(4);
    gct1 = gw1^(1-epsilon)*g^epsilon;   % gct in BGP
    delta1 = params1(5);
    
    etapath = mupath*0;     % Initialize mass of firms
    entrypath = mupath*0;   % Initialize entry rate
    
    % Initialize mass of firms and entry rate
    [ ~, ~, ~, ~, etapath(1), entrypath(1) ] = macro_BGP(xmat(1,:),1);
       
    % Construct mass of firms and entry rate
    for tt=2:Npath
        xhat = xhatpath(tt);
        entrymass = mupath(tt)*(xhat*phipath(tt))^(-gamma0)*g^(gamma0*tt);
        masstt = entrymass;
        for j=2:N
            if tt-j+1>=1
                gcj = prod(gct(tt-j+2:tt));
                xhattj = max(xhatpath(tt-j+1:tt).*cumprod([gct(tt-j+2:tt);1],'reverse'));
                survj = prod(1-deltapath(tt-j+2:tt));
            else
                gcj = prod(gct(1:tt))*(gct1)^(-tt+j-1);
                xhattj = max(xhatpath(1:tt).*cumprod([gct(2:tt);1],'reverse'));
                survj = prod(1-deltapath(1:tt))*(1-delta1)^(-tt+j-1);
            end
            etajt = (xhattj/g^tt)^(-gamma0)*survj ...
                *phipath(max(1,tt-j+1))^(-gamma0)...
                *mupath(max(1,tt-j+1))*g^(gamma0*(1-j))*gcj^gamma0;
            masstt = masstt + etajt;
        end
        etapath(tt) = masstt;
        entrypath(tt) = entrymass/masstt;
    end
    
    % Exit rates
    exitpath = etapath(1:Npath-1) - etapath(2:Npath) + etapath(2:Npath).*entrypath(2:Npath);    
    exitpath = exitpath./etapath(1:Npath-1);
    exitpath = [exitpath(1); exitpath];
    
    % Prices and Quantities
    wagepath = xhatpath*alpha.*((1-alpha)/alpha./fpath).^(1-alpha);
    Ypath = wagepath/alpha.*(1-etapath.*fpath-mupath.*kappapath);
    Cpath = Ypath;
    Apath = wagepath.*( 1 - gamma0.*mupath.*kappapath )/( gamma0 - 1 );
    GDPpath = wagepath+(1-alpha)*Ypath;
    DlogYtpath = log(Ypath(2:Npath)./Ypath(1:Npath-1));
    DlogYtpath = [DlogYtpath(1);DlogYtpath];
    DlogGDPpath = log(GDPpath(2:Npath)./GDPpath(1:Npath-1));
    DlogGDPpath = [DlogGDPpath(1);DlogGDPpath];
    
    % Bond price ( q(tt) = beta*C(tt)/C(tt+1) )
    qpath = [beta*Cpath(1:Npath-1)./Cpath(2:Npath); beta/g];
    qpath(t) = beta/g; % unanticipated reform in period t+1
    
    % Matrix of transition macro variables
    ymatnew = [xhatpath,wagepath,qpath,mupath,etapath,avgxpath];
    
    % FHK decompositions
    [ DlogZtFHK, netentryFHKpath, FHKentrypath, FHKexitpath, ...
        entrantsharepath, exitersharepath, Kpath, deltakpath, ...
        alphakpath, firmcapitalpath ] ...
        = decompositions_transition(ymatnew,xmat);
    
    % Report transition FHK results
    fprintf('\nFHK Productivity Growth Decomposition (5 year windows)')
    if reformswitch == 2
        reformpath = phipath;
        fprintf('\n Model      | Tech  | GDPWAP      | FHK agg prod | Growth accounted ' )
        fprintf('\n periods    | barr  | ann. growth | ann. growth  | for by net entry ' )
    elseif reformswitch == 3
        reformpath = fpath/period;
        fprintf('\n Model      | Cont. | GDPWAP      | FHK agg prod | Growth accounted ' )
        fprintf('\n periods    | cost  | ann. growth | ann. growth  | for by net entry ' )
    else
        reformpath = kappapath;
        fprintf('\n Model      | Entry | GDPWAP      | FHK agg prod | Growth accounted ' )
        fprintf('\n periods    | cost  | ann. growth | ann. growth  | for by net entry ' )
    end
    fprintf('\n            |       | (percent)   | (percent)    | (percent)' )
    fprintf('\n -----------------------------------------------------------' )
    fprintf('\n 1-%1i (BGP)  |  %2.2f  |  %3.1f      |   %4.1f     | %3.1f',t,...
        sum(reformpath(1:t,1))/t,...
        ((GDPpath(t)/GDPpath(1))^(1/(t-1)))^(1/period)*100-100,...
        ((exp(sum(DlogZtFHK(2:t))))^(1/(t-1)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(1:t))^(1/t)*100-100 )
    fprintf('\n %1i (reform) |  %2.2f  |  %3.1f      |   %4.1f     | %3.1f',t+1,...
        reformpath(t+1,1),...
        (GDPpath(t+1)/GDPpath(t))^(1/period)*100-100,...
        ((exp(DlogZtFHK(t+1))))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+1))*100-100 )
    fprintf('\n %1i          | % 2.2f  |  %3.1f      |   %4.1f     | %3.1f', t+2,...
        reformpath(t+2),...
        (GDPpath(t+2)/GDPpath(t+1))^(1/period)*100-100,...
        ((exp(DlogZtFHK(t+2))))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+2))*100-100 )
    fprintf('\n %1i          |  %2.2f  |  %3.1f      |   %4.1f     | %3.1f', t+3, ...
        reformpath(t+3),...
        (GDPpath(t+3)/GDPpath(t+2))^(1/period)*100-100,...
        ((exp(DlogZtFHK(t+3))))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+3))*100-100 )
    fprintf('\n %1i+         |  %2.2f  |  %3.1f      |   %4.1f     | %3.1f\n', t+4, ...
        sum(reformpath(t+4:Npath,1))/(Npath-t-3),...
        ((GDPpath(Npath)/GDPpath(t+3))^(1/(Npath-t-3)))^(1/period)*100-100,...
        ((exp(sum(DlogZtFHK(t+4:Npath))))^(1/(Npath-t-3)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+4:Npath))^(1/(Npath-t-3))*100-100 )
        
    filename = '../results/tableOA2.xls';
    header = {'Model periods' 'Entry cost' 'GDPWAP ann. growth' ...
        'FHK agg prod ann. growth' 'Growth accounted for by net entry'};
    
    xlswrite(filename, header);
    xlswrite(filename, {'0-3';'4 (reform)';'5';'6';'7+'},'A2:A6');
    
    xlswrite(filename, {sum(reformpath(1:t,1))/t,...
        ((GDPpath(t)/GDPpath(1))^(1/(t-1)))^(1/period)*100-100,...
        ((exp(sum(DlogZtFHK(2:t))))^(1/(t-1)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(1:t))^(1/t)*100-100},'B2:E2');
    
    xlswrite(filename, {reformpath(t+1),...
        (GDPpath(t+1)/GDPpath(t))^(1/period)*100-100,...
        (exp(DlogZtFHK(t+1)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+1))*100-100},'B3:E3');
    
    xlswrite(filename, {reformpath(t+2),...
        (GDPpath(t+2)/GDPpath(t+1))^(1/period)*100-100,...
        (exp(DlogZtFHK(t+2)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+2))*100-100},'B4:E4');
    
    xlswrite(filename, {reformpath(t+3),...
        (GDPpath(t+3)/GDPpath(t+2))^(1/period)*100-100,...
        (exp(DlogZtFHK(t+3)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+3))*100-100},'B5:E5');
    
    xlswrite(filename, {sum(reformpath(t+4:Npath,1))/(Npath-t-3),...
        ((GDPpath(Npath)/GDPpath(t+3))^(1/(Npath-t-3)))^(1/period)*100-100,...
        ((exp(sum(DlogZtFHK(t+4:Npath))))^(1/(Npath-t-3)))^(1/period)*100-100,...
        prod(1+netentryFHKpath(t+4:Npath))^(1/(Npath-t-3))*100-100},'B6:E6');
    
end






