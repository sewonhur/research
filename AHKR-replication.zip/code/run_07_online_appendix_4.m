%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code for calibrating model and solving for transition     %
% Title: Firm Entry and Exit and Aggregate Growth           %
% Last updated: February 22, 2020                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
addpath('./auxiliary/onlineappendix_4')
clear;

global alpha N T beta g period t kfratio p epsilonh epsilonl gbarh

%% Parameters %%
alpha = 0.67;               % Production function curvature (0.67)
N = 30;                     % Number of firm cohorts computed
period = 5;                 % Years in a period
t = 5;                      % Reform in t+1
beta = (0.98077)^period;    % Discount factor
g = (1.02)^period;          % Growth factor
epsilon = 0.64;             % Spillover term (0.64)
kfratio = 0.82/period;      % technological entry cost / technological fixed cost
gbarh = g;

%% iid growth parameters
pvals = [0,0.25,0.5,0.75,0.9,0.953];	% Incumbent high growth probability
epsilonh = epsilon;
epsilonl = epsilon;

%% Set routines to run %%
calibrateswitch = 1;        % Set = 1 to calibrate model
transitionswitch = 1;       % Set = 1 to run transitions
reformswitch = 1;           % Set reform type
% 0: no reform
% 1: kappa reform
% 2: phi reform

for ival=1:length(pvals)
    
    p=pvals(ival);
    %% Calibration routine %%
    % Initialize guess
    f = 2.324131434149078;
    gamma = 6.097910049485414;
    gbarl = 1.092579956745509;
    delta = 0.183917283058986;
    if p >= 0.5
        f = 2.324131434149078;      % Technological fixed continuation cost
        gamma = 6.097910049485414;	% Pareto tail parameter
        gbarl = 1.080908773369274;	% rate of low efficiency growth
        delta = 0.183852314264262;	% Exogenous death rate
    end
    xguess = [f; gamma; gbarl; delta];
    
    % Run calibration
    if calibrateswitch
        fprintf(' \n ************** \n')
        fprintf('\n Calibration ... \n')
        fpass = @(x) calibration(x);
        [x,fval,exitflag] = fsolve(fpass,xguess);
        fprintf(' ... Calibration completed \n')
    else
        x = xguess;
    end
    
    % Set up vector of parameters
    gamma0 = x(2);
    kappa0 = kfratio*x(1);	% set kappa = kappa_f_ratio*f
    f0 = x(1);
    phi0 = 1;               % set phi = 1 (frontier)
    lambda0 = 1;            % set Lambda0 = 1 (frontier)
    params0 = [kappa0; x; phi0; lambda0];    % include kappa, phi, and lambda
    [wage, mu, xhat, eta, entryrate, joblossexit, deltak, alphak] ...
        = macro_BGP(params0,t);
    params0 = [params0; alphak];    % include alphak
    
    yy = zeros(1000,4);
    for tt=1:1000
        [yy(tt,1),yy(tt,2),yy(tt,3),yy(tt,4)]  = macro_BGP(params0,tt);
        yy(tt,1) = yy(tt,1)/g^(tt);
        yy(tt,3) = yy(tt,3)/g^(tt);
    end
    
    % Calibration Parameters
    fprintf(' \n ************** \n')
    fprintf('\n -- Calibration Parameters -- \n')
    fprintf(' Entry cost (kappa): %f\n', kappa0);
    fprintf(' Continuing cost (f annualized): %f\n', f0/period);
    fprintf(' Pareto tail (gamma): %f\n', gamma0);
    fprintf(' Low firm growth (gcl annualized): %f\n',(params0(4)^(1-epsilonl)*g^epsilonl)^(1/period));
    fprintf(' High firm growth (gch annualized): %f\n',(gbarh^(1-epsilonh)*g^epsilonh)^(1/period));
    fprintf(' Exogenous death rate (annualized): %f\n', 1-(1-params0(5))^(1/period));
    fprintf(' High growth prob (p): %f\n', p);
    
    
    %% Report BGP results
    
    % Decompositions in BGP
    [netentryFHK, entrantshare, exitersharel] ...
        = decompositions_BGP(params0,t);
    
    % Calibration Targets
    fprintf('\n -- Calibration Targets -- \n')
    fprintf(' Entry cost / continuation cost (annualized): %f\n', kappa0/(params0(2)/period));   % 0.82
    
    gamma = params0(3);
    avgfirm_size = 1/eta;
    fprintf(' average firm size (employment): %f\n', avgfirm_size);  % 14
    if gamma*(1-alpha) > 2
        firmvar = (1/eta)^2*...
            ( (gamma*(1-alpha)-1)^2 ...
            / (gamma*(1-alpha)-2) ...
            / (gamma*(1-alpha) ) - 1 );
        fprintf(' standard deviation firm size (employment): %f\n',sqrt(firmvar)); % 89
    else
        
        fprintf(' standard deviation firm size (employment): NaN');
    end
    fprintf(' FHK effect of net entry on productivity growth (percent): %f\n', netentryFHK*100);   % 25
    fprintf(' Jobs destroyed via exit (percent of total jobs): %f\n', joblossexit*100); % 19.33
    
    % Other Statistics
    fprintf('\n -- FHK decompositions -- \n')
    fprintf(' effect of net entry on productivity growth (percent): %f\n', netentryFHK*100);
    
    [entryFHK, exitFHK, withinFHK, covFHK, betweenFHK, reallocationFHK, DlogZ] ...
        = FHK_BGP(params0,t);
    fprintf(' effect of entry on productivity growth (percent): %f\n', entryFHK*100);
    fprintf(' effect of exit on productivity growth (percent): %f\n', -exitFHK*100);
    fprintf(' effect of within-firm growth on productivity growth (percent): %f\n', withinFHK*100);
    fprintf(' effect of covariance on productivity growth (percent) %f\n', covFHK*100);
    fprintf(' effect of between-effect on productivity growth (percent) %f\n', betweenFHK*100);
    
    if p==0.5
        %% Solve for transition
        
        % Transition parameters
        params1 = params0;
        if reformswitch == 1 % reform kappa
            params1(1) = (1/0.85)^(alpha*gamma0)*params0(1); % increase kappa
        elseif reformswitch == 2 % reform phi
            params1(6) = (1/0.85)^alpha*params0(6); % increase phi
        end
        
        % Number of transition periods (set large enough)
        T = N+10;
        
        if transitionswitch
            
            % Set matrix of parameters
            xmat = repmat(params0',[T+2,1]);
            xmat(1,:) = params1;
            
            % Lambda is used as a parameter in BGP analysis, but is endogenous in transition
            % Compute time 0 Lambda using eq (30) in paper
            lambda1 = (params1(2)/params0(2)).^((gamma0*(1-alpha)-1)/gamma0/alpha) ...
                .*(params1(6)/params0(6)).^(1/alpha) ...
                .*(params1(1)/params0(1)).^(1/gamma0/alpha);
            params1(7) = lambda1;
            xmat(:,7) = 1;
            xmat(1,7) = params1(7);
            
            % Initialize vectors for xhat(t) and mu(t)
            xhatt = zeros(T+2,1);
            mut = zeros(T+2,1);
            
            % Initial conditions
            [~, mut(1), xhatt(1)] = macro_BGP(xmat(1,:),t);
            
            % Terminal conditions and set guesses for transition
            for tt=2:T+2
                [~, mut(tt), xhatt(tt)] = macro_BGP(xmat(tt,:),t+tt-1);
            end
            avgxt = gamma0/(gamma0-1)*xhatt; % Average efficiency
            ymat = [xhatt,mut];
            
            icmat = ymat(1,:); % intial conditions
            tcmat = ymat(T+2,:); % terminal conditions
            tmat = ymat(2:T+1,:); % guess for transition
            
            % Solve for transtion
            fprintf(' \n ************** \n')
            fprintf('\n Solving for transition ...\n')
            fpass = @(x)transfun(x,icmat,tcmat,xmat);
            [x,fval,exitflag] = fsolve(fpass,tmat);
            ymat(2:T+1,:) = x;
            xhatpath = ymat(:,1);
            mupath = ymat(:,2);
            fprintf(' ... Transition solved \n')
            
            % Extend series to include periods 1,2,..,t-1
            lintrend = g.^(linspace(1-t,-1,t-1)');
            xhatpath = [xhatpath(1)*lintrend; xhatpath];    % linear trend for xhat
            avgxpath = gamma0/(gamma0-1)*xhatpath;
            for tt=t-1:-1:1
                mupath = [mupath(1); mupath];               % constant trend for mu
                xmat = [xmat(1,:); xmat];                   % also extend parameters
            end
            kappapath = xmat(:,1);
            fpath = xmat(:,2);
            deltapath = xmat(:,5);
            phipath = xmat(:,6);
            
            % Construct macro variables
            Npath = length(mupath);
            delta1 = params1(5);
            % average efficiency growth
            gt = [g; avgxpath(2:Npath)./avgxpath(1:Npath-1,1)];
            
            etapath = mupath*0;     % Initialize mass of firms
            entrypath = mupath*0;   % Initialize entry rate
            
            % Initialize mass of firms and entry rate
            [ ~, ~, ~, etapath(1), entrypath(1) ] = macro_BGP(xmat(1,:),1);
            
            % Frontier GDP (no distortions)
            YtFpath = 0*xhatpath;
            YtFpath(Npath) = ((1-alpha)/fpath(Npath))^(1-alpha)*xhatpath(Npath);
            for tt=Npath-1:-1:1
                YtFpath(tt) = YtFpath(tt+1)/g;
            end
            
            % Domestic GDP
            Ypath = (...
                ((1-alpha)./(fpath.*YtFpath)).^(1-alpha).*xhatpath...
                ).^(1/alpha);
            wagepath = alpha*Ypath;
            DlogYtpath = log(Ypath(2:Npath)./Ypath(1:Npath-1));
            DlogYtpath = [DlogYtpath(1);DlogYtpath];
            
            % Update vector of lambdas
            lambdapath = YtFpath./Ypath;
            xmat(:,7) = lambdapath;
            
            % Mass of firms
            etapath = (gamma0*(1-alpha)-1)./(gamma0*lambdapath.*fpath);
            entrypath = mupath.*(xhatpath.*phipath).^(-gamma0).*g.^(gamma0*[1:1:Npath]')./etapath;
            
            % Exit rates
            exitpath = etapath(1:Npath-1) - etapath(2:Npath) + etapath(2:Npath).*entrypath(2:Npath);
            exitpath = exitpath./etapath(1:Npath-1);
            exitpath = [exitpath(1); exitpath];
            
            % Consumption and capital income
            Cpath = Ypath.*( 1 - lambdapath.*( etapath.*fpath  + mupath.*kappapath ) );
            Apath = Ypath.*( 1 - alpha  ...
                - lambdapath.*( etapath.*fpath  + mupath.*kappapath ) );
            
            % Bond price ( q(tt) = beta*C(tt)/C(tt+1) )
            qpath = [beta*Cpath(1:Npath-1)./Cpath(2:Npath); beta/g];
            qpath(t) = beta/g; % unanticipated reform in period t+1
            
            % Matrix of transition macro variables
            ymatnew = [xhatpath,wagepath,qpath,mupath,etapath,avgxpath];
            
            % FHK decompositions
            [ DlogZtFHK, netentryFHKpath, ...
                FHKentrypath, FHKexitpath, FHKwithinpath, FHKcovpath, FHKreallpath, ...
                entrantsharepath, exitersharepath, Kpath, deltakpath, ...
                alphakpath, firmcapitalpath ] ...
                = decompositions_transition(ymatnew,xmat);
            
            % Report transition FHK results
            fprintf('\nFHK Productivity Growth Decomposition (p=%2.2f)',p)
            if reformswitch == 2
                reformpath = phipath;
                fprintf('\n Model      | Tech  | GDPWAP      | FHK agg prod | Growth accounted ' )
                fprintf('\n periods    | barr  | ann. growth | ann. growth  | for by net entry ' )
            elseif reformswitch == 3
                reformpath = fpath/period;
                fprintf('\n Model      | Cont. | GDPWAP      | FHK agg prod | Growth accounted ' )
                fprintf('\n periods    | cost  | ann. growth | ann. growth  | for by net entry ' )
            else
                reformpath = kappapath;
                fprintf('\n Model      | Entry | GDPWAP      | FHK agg prod | Growth accounted ' )
                fprintf('\n periods    | cost  | ann. growth | ann. growth  | for by net entry ' )
            end
            fprintf('\n            |       | (percent)   | (percent)    | (percent)' )
            fprintf('\n -------------------------------------------------------' )
            fprintf('\n 1-%1i (BGP)  |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f',t,...
                sum(reformpath(1:t,1))/t,...
                ((Ypath(t)/Ypath(1))^(1/(t-1)))^(1/period)*100-100,...
                ((exp(sum(DlogZtFHK(2:t))))^(1/(t-1)))^(1/period)*100-100,...
                prod(1+netentryFHKpath(1:t))^(1/t)*100-100 )
            fprintf('\n %1i (reform) |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f',t+1,...
                reformpath(t+1,1),...
                (Ypath(t+1)/Ypath(t))^(1/period)*100-100,...
                ((exp(DlogZtFHK(t+1))))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+1))*100-100 )
            fprintf('\n %1i          | % 2.2f  |  %3.1f      |   %3.1f     | %3.1f',t+2,...
                reformpath(t+2),...
                (Ypath(t+2)/Ypath(t+1))^(1/period)*100-100,...
                ((exp(DlogZtFHK(t+2))))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+2))*100-100 )
            fprintf('\n %1i          |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f',t+3,...
                reformpath(t+3),...
                (Ypath(t+3)/Ypath(t+2))^(1/period)*100-100,...
                ((exp(DlogZtFHK(t+3))))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+3))*100-100 )
            fprintf('\n %1i+         |  %2.2f  |  %3.1f      |   %3.1f     | %3.1f\n',t+4, ...
                sum(reformpath(t+4:Npath,1))/(Npath-t-3),...
                ((Ypath(Npath)/Ypath(t+3))^(1/(Npath-t-3)))^(1/period)*100-100,...
                ((exp(sum(DlogZtFHK(t+4:Npath))))^(1/(Npath-t-3)))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+4:Npath))^(1/(Npath-t-3))*100-100 )
            
            filename = '../results/tableOA8.xls';
            header = {'Model periods' 'Entry cost' 'GDPWAP ann. growth' ...
                'FHK agg prod ann. growth' 'Growth accounted for by net entry'};
            
            xlswrite(filename, header);
            xlswrite(filename, {'0-3';'4 (reform)';'5';'6';'7+'},'A2:A6');
            
            xlswrite(filename, {sum(reformpath(1:t,1))/t,...
                ((Ypath(t)/Ypath(1))^(1/(t-1)))^(1/period)*100-100,...
                ((exp(sum(DlogZtFHK(2:t))))^(1/(t-1)))^(1/period)*100-100,...
                prod(1+netentryFHKpath(1:t))^(1/t)*100-100},'B2:E2');
            
            xlswrite(filename, {reformpath(t+1),...
                (Ypath(t+1)/Ypath(t))^(1/period)*100-100,...
                (exp(DlogZtFHK(t+1)))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+1))*100-100},'B3:E3');
            
            xlswrite(filename, {reformpath(t+2),...
                (Ypath(t+2)/Ypath(t+1))^(1/period)*100-100,...
                (exp(DlogZtFHK(t+2)))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+2))*100-100},'B4:E4');
            
            xlswrite(filename, {reformpath(t+3),...
                (Ypath(t+3)/Ypath(t+2))^(1/period)*100-100,...
                (exp(DlogZtFHK(t+3)))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+3))*100-100},'B5:E5');
            
            xlswrite(filename, {sum(reformpath(t+4:Npath,1))/(Npath-t-3),...
                ((Ypath(Npath)/Ypath(t+3))^(1/(Npath-t-3)))^(1/period)*100-100,...
                ((exp(sum(DlogZtFHK(t+4:Npath))))^(1/(Npath-t-3)))^(1/period)*100-100,...
                prod(1+netentryFHKpath(t+4:Npath))^(1/(Npath-t-3))*100-100},'B6:E6');
        end
        
    end
    
    filename = '../results/tableOA9.xls';
    if ival==1
        header = {'FHK decomposition' 'Prob. of high growth / low growth rate'};
        xlswrite(filename, header);
        xlswrite(filename, {'Net entry';'  entry';'  exit'; ...
            'Continuing';'  Within'; '  Covariance'; '  Between'},'A4:A10');
        xlswrite(filename, {p;(params0(4)^(1-epsilon)*g^epsilon)^(1/period)},'B2:B3');
        xlswrite(filename, {netentryFHK*100;entryFHK*100;exitFHK*100;...
            (1-netentryFHK)*100;withinFHK*100;covFHK*100;betweenFHK*100},'B4:B10');
    elseif ival==2
        xlswrite(filename, {p;(params0(4)^(1-epsilon)*g^epsilon)^(1/period)},'C2:C3');
        xlswrite(filename, {netentryFHK*100;entryFHK*100;exitFHK*100;...
            (1-netentryFHK)*100;withinFHK*100;covFHK*100;betweenFHK*100},'C4:C10');
    elseif ival==3
        xlswrite(filename, {p;(params0(4)^(1-epsilon)*g^epsilon)^(1/period)},'D2:D3');
        xlswrite(filename, {netentryFHK*100;entryFHK*100;exitFHK*100;...
            (1-netentryFHK)*100;withinFHK*100;covFHK*100;betweenFHK*100},'D4:D10');
    elseif ival==4
        xlswrite(filename, {p;(params0(4)^(1-epsilon)*g^epsilon)^(1/period)},'E2:E3');
        xlswrite(filename, {netentryFHK*100;entryFHK*100;exitFHK*100;...
            (1-netentryFHK)*100;withinFHK*100;covFHK*100;betweenFHK*100},'E4:E10');
    elseif ival==5
        xlswrite(filename, {p;(params0(4)^(1-epsilon)*g^epsilon)^(1/period)},'F2:F3');
        xlswrite(filename, {netentryFHK*100;entryFHK*100;exitFHK*100;...
            (1-netentryFHK)*100;withinFHK*100;covFHK*100;betweenFHK*100},'F4:F10');
    elseif ival==6
        xlswrite(filename, {p;(params0(4)^(1-epsilon)*g^epsilon)^(1/period)},'G2:G3');
        xlswrite(filename, {netentryFHK*100;entryFHK*100;exitFHK*100;...
            (1-netentryFHK)*100;withinFHK*100;covFHK*100;betweenFHK*100},'G4:G10');
    end
    
end














