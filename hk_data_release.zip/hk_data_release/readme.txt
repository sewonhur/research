Authors: Sewon Hur & Illenin Kondo
Date: December 15, 2015
Description: Data Appendix for "A Theory of Rollover Risk, Sudden Stops, and Foreign Reserves"

************************************************
*     PART A - FIGURES AND TABLES - RESERVES   *
************************************************
This part generates the data used in the paper.
The programs are in the sub-folder: /reserves/

All the data files all called through the .do files
>> /reserves/prep_hk_v20151215.do

All the data files are data inputs except for: 
>> /reserves/iip_hk_v20151215

Run the following .do files for additional graphs
>> /reserves/prep_jie_extra.do

The log files generated also store all the relevant output.

****************************************************
*     PART B - FIGURES AND TABLES - SUDDEN STOPS   *
****************************************************
This part generates the data used in the paper.
The programs are in the sub-folder: /sudden_stops/

All the data files all called through the .do files
>> /sudden_stops/bop_ss_v20151215.dta

All the data files are data inputs except for: 
>> /sudden_stops/bop_ss_v20151215.dta

The log files generated also store all the relevant output.

***************************************************************
*     PART C - FIGURES AND TABLES - GOURINCHAS AND OBSTFELD   *
***************************************************************
This part generates the data used in the paper.
The programs are in the sub-folder: /gourinchas_obstfeld/

All the data files all called through the .do files
>> /gourinchas_obstfeld/prep_obstfeld_v20151215.do
The code contains switches for the different tables.
The original log files contains these details if needed.

All the data files are data inputs except for: 
>> /gourinchas_obstfeld/obstfeld_v20151215.dta

The log files generated also store all the relevant output.


**************************************
*   PART D - CHINN and ITO MEASURES  *
**************************************

This part generates the figure on the Chinn-Ito measure of capital openness.
The programs are in the sub-folder: /chinn_ito/

All the data files all called through the .do files
>> /chinn_ito/prep_chinn_ito_v20151215.do

The data input files are : 
>> /chinn_ito/chinn_ito_v20151215.dta

The log files generated also store all the relevant output.


---------------------------------------
----------    OPTIONAL   --------------
---------------------------------------


*****************************************
*   PART E - SIMULATED DATA REGRESSION  *
*****************************************

This part reproduces the Gourinchas-Obstfeld exercise on the model simulated data.
The programs are in the sub-folder: /simul/

All the data files all called through the .do files
>> /simul/prep_obstfeld_simul_v20151215.do

The data input files are: 
>> /simul/SIMULATIONS_1region.dta
>> /simul/SIMULATIONS_3regions.dta

The log files generated also store all the relevant output.

Comments welcome. See online data appendix and paper for additional details.


---------------------------------------
----------    OPTIONAL   --------------
---------------------------------------


*********************************************
*   PART F - DATA PREPARATION - ANNUAL DATA *
*********************************************

This part shows how to generate the main source datasets.
The programs are in the sub-folder: /src/

To generate the main (updated) annual dataset, run
>> /src/update_ewn_20151215.do

This creates the dataset
>> /src/ewn2011.dta

The data input files are: 
>> /src/EWN19702011.xlsx (Lane and Milesi-Ferretti)
>> /src/country_financial_annual.dta (Haver)

The log files generated also store all the relevant output.

Comments welcome. See online data appendix and paper for additional details.

************************************************
*   PART G - DATA PREPARATION - QUARTERLY DATA *
************************************************

This part shows how to generate the main source datasets.
The programs are in the sub-folder: /src/

To generate the main (updated) quarterly dataset, run
>> /src/update_bop_20151215.do

This creates the dataset
>> /src/ifs_src_bop.dta

The data input files are: 
>> /src/country_financial_quarterly.dta (Haver)

The log files generated also store all the relevant output.

Comments welcome. See online data appendix and paper for additional details.






