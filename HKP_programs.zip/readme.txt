Authors: Sewon Hur & Illenin Kondo & Fabrizio Perri
Release date: November 06th, 2018
Description: Replication -- Computation -- "Real Interest Rates, Inflation, and Default"

***************
*** FOLDERS ***
***************

This folder contains the FORTRAN programs used to solve 
	and simulate the different versions of the model.

Each sub-folder [vNN] corresponds to a version reported 
	in the text and referenced in the [results] sub-folder.
	>> v1 corresponds to the baseline model in the paper.

The sub-folder [results] contains Excel worksheets 
	summarizing the key output of the programs.


*****************
*** F90 FILES ***
*****************

The parameter file is 
	parameters.f90
	>> this is the only file changed
	>> when we run new versions [vNN]
	>> we release this file for replication

The main control file is 
	main_hkp.f90

The core computation file is 
	auxiliary.f90

The code were compiled 
	using Intel IFORT 17.0.7 
	and executed on 64-core machines.
	typically required 12-18 hours to compute.
	
***************
*** SCRIPTS ***
***************
The .sh scripts were written to run on the UGE HPC environment at Notre Dame.


Comments are welcome. 
See online appendix and paper for additional details.
