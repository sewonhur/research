#!/bin/tcsh 

echo 'creating configuration files ... '
set JOBSTR   = `(qsub -V ./main_hkp_setup.sh)`
echo $JOBSTR
set SETUPJOB = ` echo $JOBSTR | awk -F'[^0-9]*' '$0=$2'`
echo '... setup job number is: ' $SETUPJOB

echo 'running each configuration ... '
set JOBSTR   = `(qsub -V -hold_jid $SETUPJOB -t 1-006 ./main_hkp_array.sh)`
echo $JOBSTR
set ARRAYJOB = ` echo $JOBSTR |  awk -F'[^0-9]*' '$0=$2' `
echo '... array job number is: ' $ARRAYJOB

echo 'gathering output across runs ... '
set JOBSTR   = `(qsub -V -hold_jid $ARRAYJOB ./main_hkp_gather.sh)`
echo $JOBSTR
set GATHERJOB = ` echo $JOBSTR |  awk -F'[^0-9]*' '$0=$2' `
echo '... gather job number is: ' $GATHERJOB

# echo 'running STATA job on output ... '
# STATAJOB=$(sbatch --export==ALL -dependency=afterany:$GATHERJOB./main_hkp_stats.sh)
# echo stata job submitted as $STATAJOB



