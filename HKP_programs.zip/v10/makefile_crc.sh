#!/bin/tcsh 

echo 'cleaning ... '

rm -f *.exe
rm -f *.mod

rm -f hkp_*.o*
#rm -f log_*.log

rm -rf ./out/*
rm -rf ./log/*
rm -rf ./cfg/pfx_*.in

echo ' ... done.'

module load intel

echo 'compiling ... '
ifort -o main_hkp.exe parameters.f90 global.f90 process.f90 auxiliary.f90 utilities.f90 launch.f90 main_hkp.f90 -qopenmp -mkl -lmkl_lapack95_lp64 -assume realloc_lhs

echo 'done'


