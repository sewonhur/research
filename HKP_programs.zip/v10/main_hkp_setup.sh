#!/bin/bash 
 
#$ -N hkp_setup 
#$ -q long
#$ -j y
#$ -l h_rt=1:00:00
#$ -pe smp 1


##########################################
##                                      ##
##########################################

echo ------------------------------------------------------
echo ' BEGIN - SETUP SCRIPT '
echo ' '
echo SGE: qsub  is running on 	$SGE_CLUSTER_NAME
echo SGE: job identifier is 	$JOB_ID 
echo SGE: array identifier is 	$SGE_TASK_ID
echo SGE: job name is 			$JOB_NAME
echo SGE: node list is 			$PE_HOSTFILE 
echo SGE: the invoking host is	$SGE_O_HOST
echo SGE: working directory is 	$SGE_O_WORKDIR
echo SGE: start time is `date`
echo ' '
echo ------------------------------------------------------

#####################################################
#                     SETUP                         #
#####################################################


stageset()
{
	
	SCP=/usr/bin/scp
	SSH=/usr/bin/ssh

	SERVER=$SGE_O_HOST
	PERMDIR=$SGE_O_WORKDIR
	SERVPERMDIR=${SGE_O_HOST}:${PERMDIR}

	CFGDIR=cfg
	OUTDIR=out
	PROGEXE=main_hkp.exe
	INPUTS=parameters.in
	PFXNAME=pfx

	echo ' '
	echo ' '
	echo server is $SERVER
	echo permdir is $PERMDIR
	echo servpermdir is $SERVPERMDIR
	echo ' '
	echo ' '

}

stagein()
{
 echo ' '
 echo Setup files are on the server
 cd ${PERMDIR}
 echo ' '
 
}

runprogram()
{
    # load environment-modules itself and compiler-specific modules
    #. /etc/profile.d/modules.sh
    module load intel
    
    # run HKP
    
	# for batch mode based on grid of parameters
	./main_hkp.exe runmode setup params ${INPUTS} prefix ${PFXNAME}	
	
	# for batch mode based on initial parameter guesses
	#./main_hkp.exe runmode create params ${INPUTS} prefix ${PFXNAME}	
}

##################################################
#                                                #
#   Staging in, running the job, and staging out #
#   call these functions to perform the actual   #
#   file transfers and program execution.        #
#                                                #
##################################################

stageset
stagein
runprogram

echo ' '
echo ' DONE  - SETUP SCRIPT '
echo SGE: end time is `date`
echo ------------------------------------------------------

exit


