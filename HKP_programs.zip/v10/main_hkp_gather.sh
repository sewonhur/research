#!/bin/bash 

#$ -N hkp_gather
#$ -q long
#$ -j y
#$ -l h_rt=1:00:00
#$ -pe smp 1


##########################################
##                                      ##
##########################################

echo ------------------------------------------------------
echo ' BEGIN - SETUP SCRIPT '
echo ' '
echo SGE: qsub  is running on 	$SGE_CLUSTER_NAME
echo SGE: job identifier is 	$JOB_ID 
echo SGE: array identifier is 	$SGE_TASK_ID
echo SGE: job name is 			$JOB_NAME
echo SGE: node list is 			$PE_HOSTFILE 
echo SGE: the invoking host is	$SGE_O_HOST
echo SGE: working directory is 	$SGE_O_WORKDIR
echo SGE: start time is `date`
echo ' '
echo ------------------------------------------------------

#####################################################
#                     SETUP                         #
#####################################################


stageset()
{
	
	SCP=/usr/bin/scp
	SSH=/usr/bin/ssh

	SERVER=$SGE_O_HOST
	PERMDIR=$SGE_O_WORKDIR
	SERVPERMDIR=${SGE_O_HOST}:${PERMDIR}

	CFGDIR=cfg
	OUTDIR=out
	LOGDIR=log
	PROGEXE=main_hkp.exe
	INPUTS=parameters.in
	RESFILE1=simuls_simple.out
	RESFILE2=params_matlab.out
	RESFILE3=simuls_gd_bd.out
	RESFILE4=simuls_regime.out
	RESFILE5=simuls_vfcns.out
	PFXNAME=pfx

	echo ' '
	echo ' '
	echo server is $SERVER
	echo permdir is $PERMDIR
	echo servpermdir is $SERVPERMDIR
	echo ' '
	echo ' '

}

stagein()
{
    cd ${PERMDIR}
}

runprogram()
{
    # load environment-modules itself and compiler-specific modules
    #. /etc/profile.d/modules.sh
    module load intel
    
    # run HKP
    echo ' '
    echo Simulation output files being gathered
    echo ' '        
    
    ./main_hkp.exe runmode gather params ${INPUTS} prefix ${PFXNAME} resfnm ${RESFILE1} addprm F
    ./main_hkp.exe runmode gather params ${INPUTS} prefix ${PFXNAME} resfnm ${RESFILE2} addprm F
    ./main_hkp.exe runmode gather params ${INPUTS} prefix ${PFXNAME} resfnm ${RESFILE3} addprm F
    ./main_hkp.exe runmode gather params ${INPUTS} prefix ${PFXNAME} resfnm ${RESFILE4} addprm F
    ./main_hkp.exe runmode gather params ${INPUTS} prefix ${PFXNAME} resfnm ${RESFILE5} addprm F
}


stageout()
{
    echo ' '
    echo Transferring log files 

    cd  ${PERMDIR}
    rm -rf ${LOGDIR}
    mkdir -p ${LOGDIR}
    mv -f ./hkp_*.o* ./${LOGDIR}
	mv -f ./*.out  ./${LOGDIR}
    mv -f ./*.log  ./${LOGDIR}
    
    echo Files in log directory:
    cd ${PERMDIR}/${LOGDIR}  ; ls -l

 }
 
##################################################
#                                                #
#   Staging in, running the job, and staging out #
#   call these functions to perform the actual   #
#   file transfers and program execution.        #
#                                                #
##################################################

stageset
stagein
runprogram
stageout

echo ' '
echo ' DONE  - GATHER SCRIPT '
echo SGE: end time is `date`
echo ------------------------------------------------------

exit
