#!/bin/bash 

#$ -N 	hkp_array 
#$ -l 	h_rt=096:00:00
#$ -q 	long
#$ -j 	y
#$ -pe 	smp 64


##########################################
##                                      ##
##########################################

echo ------------------------------------------------------
echo ' BEGIN - SETUP SCRIPT '
echo ' '
echo SGE: qsub  is running on 	$SGE_CLUSTER_NAME
echo SGE: job identifier is 	$JOB_ID 
echo SGE: array identifier is 	$SGE_TASK_ID
echo SGE: job name is 			$JOB_NAME
echo SGE: node list is 			$PE_HOSTFILE 
echo SGE: the invoking host is	$SGE_O_HOST
echo SGE: working directory is 	$SGE_O_WORKDIR
echo SGE: start time is `date`
echo ' '
echo ------------------------------------------------------

#####################################################
#                     SETUP                         #
#####################################################

sgeomp()
{
 export OMP_NUM_THREADS=$NSLOTS
  echo 'number of CPUS in use is ' $NSLOTS
}

stageset()
{
	
	SCP=/usr/bin/scp
	SSH=/usr/bin/ssh

	SERVER=$SGE_O_HOST
	PERMDIR=$SGE_O_WORKDIR

	SERVPERMDIR=${SGE_O_HOST}:${SGE_O_WORKDIR}
	WORKDIR=/afs/crc.nd.edu/user/i/ikondo/Private/hkp/scratch/SGE_${JOB_ID}_${SGE_TASK_ID}/


	#INPUTS=parameters.in
    INIDIR=ini
	PROGEXE=main_hkp.exe
	CFGDIR=cfg	
	OUTDIR=out
	LOGFILE=log_${JOB_ID}_${SGE_TASK_ID}.log

	echo ' '
	echo ' '
	echo server is      $SERVER
	echo permdir is     $PERMDIR
	echo servpermdir is $SERVPERMDIR
	echo workdir is     $WORKDIR
	echo ' '
	echo ' '

}

stagein()
{
 echo ' '
 echo Transferring files from server to compute node
 echo Writing files in node directory  ${WORKDIR}

 rm -rf ${WORKDIR}
 mkdir -p ${WORKDIR}
 cd ${WORKDIR} 
 ls -l
 
 echo ' '
 echo ' '
 echo 'copying ...'
 
 #cp ${PERMDIR}/${INPUTS} .
 cp ${PERMDIR}/${PROGEXE} .
 cp -rp ${PERMDIR}/${INIDIR} ./${INIDIR}
 cp -rp ${PERMDIR}/${CFGDIR} ./${CFGDIR}

 echo Files in node work directory are as follows:
 ls -l
}

runprogram()
{
    # load environment-modules itself and compiler-specific modules
    #. /etc/profile.d/modules.sh
    module load intel
    
    # run program -- compute
    ./main_hkp.exe runmode compute prefix pfx cfgnum $SGE_TASK_ID > ${PERMDIR}/${LOGFILE}
	
    # run program -- simulate
    #./main_hkp.exe runmode simuls prefix pfx cfgnum $SGE_TASK_ID > ${PERMDIR}/${LOGFILE}
	
	# run program -- calibrate using amoeba
	#./main_hkp.exe runmode amoeba prefix pfx cfgnum $SGE_TASK_ID > ${PERMDIR}/${LOGFILE}
}

stageout()
{
 echo ' '
 echo Transferring files from compute nodes to server
 echo Writing files in permanent directory  ${PERMDIR}

 cp -rp ./${OUTDIR}  ${PERMDIR}

 echo Final files in permanent data directory:
 cd ${PERMDIR}/${OUTDIR}  ; ls -l
 
 echo Cleaning scratch folders
 cd ${PERMDIR} 
 rm -rf ${WORKDIR} 
 echo Done deleting scratch folder ${WORKDIR} 
 }

 
##################################################
#                                                #
#   Staging in, running the job, and staging out #
#   call these functions to perform the actual   #
#   file transfers and program execution.        #
#                                                #
##################################################

sgeomp
stageset
stagein
runprogram
stageout 

###############################################################
#                                                             #
#   The epilogue script automatically deletes the directory   #
#   created on the local disk (including all files contained  #
#   therein.                                                  #
#                                                             #
###############################################################

echo ' '
echo '  DONE - ARRAY JOBS '
echo SGE: end time is `date`
echo ------------------------------------------------------

exit


