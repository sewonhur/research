function [X,G] = sortmat(T,f)

% sorts a matrix along the f column and preserves the rows

[aa,bb] = size(T);  % aa - no. of rows; bb - no. of columns

col = T(:,f);   % select the column to be sorted

[vv,G] = sort(col);  % returns the sorted column (vv) and (G) which tells you where each element vv came from

X = zeros(aa,bb); % predefine X to filled by the following loop

for i = 1:aa  % go over each row
        n = G(i); % identify where this household sit in the original matrix, T?
        X(i,:) = T(n,:); % copy that row in T over to X
end



