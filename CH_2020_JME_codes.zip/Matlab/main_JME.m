%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% On the Heterogeneous Welfare Gains and Losses from Trade  %
% Daniel Carroll and Sewon Hur                              %
% Last update: January 31, 2019                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
close all;

%% CONTROLS %%

nprint = 0;
% 0: do not save figures
% 1: save figures as .eps
% 2: save figures as .pdf

saveresults = 0;

projectdir = 'results\';
   
if(nprint == 0)
  set(0,'DefaultFigureWindowStyle','docked')
else
  set(0,'DefaultFigureWindowStyle','default')
end
        
        
        %% PARAMETERS %%
nk2pts  = 5000;
nkpts   = 50;
        
% --------------------- Get parameters  -----------------------------------
%  File with parameter values
    filename = strcat(projectdir,'parameters.in');
    endRow = 1;
    formatSpec = '%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%f%[^\n\r]';
    fileID = fopen(filename,'r');
    dataArray = textscan(fileID, formatSpec, endRow, 'Delimiter', '', 'WhiteSpace', '', 'ReturnOnError', false);
    fclose(fileID);
    parameters = [dataArray{1:end-1}];

    % tau_fin = parameters(1);
    beta = parameters(2);
    gamma = parameters(3);
    cbar = parameters(4);
    xkbor = parameters(5);
    sigma = parameters(6);
    kappa = parameters(7);
    theta = parameters(8);
    alpha_t = parameters(9);
    alpha_n = parameters(10);
    delta = parameters(11);
    eta = parameters(12);
%     lower_omega_fin = parameters(13);
%     upper_omega_fin = parameters(14);
    zx = parameters(15);
    zn = parameters(16);

    clear parameters
    
    
%% Initialize variables.
    filename = strcat(projectdir,'epts.out');
    endRow = 1;
    formatSpec = '%18f%18f%18f%18f%f%[^\n\r]';
    fileID = fopen(filename,'r');
    dataArray = textscan(fileID, formatSpec, endRow, 'Delimiter', '', 'WhiteSpace', '', 'TextType', 'string', 'ReturnOnError', false, 'EndOfLine', '\r\n');
    fclose(fileID);
    epts = [dataArray{1:end-1}];
    epts = epts';
    
    clearvars filename endRow formatSpec fileID dataArray ans;
   
    %% READ EQUILIBRIUM OUTPUT %%

    % ---------------- Get steady state distribution initial ss ---------------
    % dimension : nk2pts x nepts

    filename = strcat(projectdir,'saving_ss.fstart');
    fileID = fopen(filename,'r');
    formatSpec = '%18f%18f%18f%18f%18f%18f%f%[^\n\r]';
    dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '', 'EmptyValue' ,NaN, 'ReturnOnError', false);
    fclose(fileID);
    fss_init = [dataArray{1:end-1}];
    xk2pts = fss_init(:,1);
    fss_init = fss_init(:,2:6);

    % ------------------ Get steady state distribution final ss ---------------
    %  dimension : nk2pts x nepts

    filename = strcat(projectdir,'saving_ss_fin.f1');
    fileID = fopen(filename,'r');
    formatSpec = '%*18s%18f%18f%18f%18f%f%[^\n\r]';
    dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '', 'EmptyValue' ,NaN, 'ReturnOnError', false);
    fclose(fileID);
    fss_fin = [dataArray{1:end-1}];

    % ----------------- Get steady state value function initial ---------------
    % contains value functions and optimal decisions on coarse wealth grid
    % dimension : nkpts x nepts
    filename = strcat(projectdir,'saving_ss.out');
    fileID = fopen(filename,'r');
    formatSpec = '%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%f%[^\n\r]';
    dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '', 'EmptyValue' ,NaN, 'ReturnOnError', false);
    fclose(fileID);
    vals = [dataArray{1:end-1}];

    xkpts = vals(:,1);
    val_init = vals(:,2:6);
    saving_init = vals(:,7:11);
    x_init   = vals(:,12:16);
    ct_init = vals(:,17:21);
    cn_init  = vals(:,22:26);

    clear vals
        
        % ------------------- Get steady state value function final ---------------
        % contains value functions and optimal decisions on coarse wealth grid
        % dimension : nkpts x nepts
        filename = strcat(projectdir,'saving_ss_fin.out');
        fileID = fopen(filename,'r');
        formatSpec = '%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%f%[^\n\r]';
        dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '', 'EmptyValue' ,NaN, 'ReturnOnError', false);
        fclose(fileID);
        vals = [dataArray{1:end-1}];
        
        val_fin = vals(:,2:6);
        saving_fin = vals(:,7:11);
        x_fin   = vals(:,12:16);
        ct_fin = vals(:,17:21);
        cn_fin  = vals(:,22:26);
        
        clear vals
        
        % --------------------- Get aggregates for initial ss  --------------------
        %  File with steady state aggregate values
        filename = strcat(projectdir,'aggregates_init.out');
        endRow = 1;
        formatSpec = '%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, endRow, 'Delimiter', '', 'WhiteSpace', '', 'ReturnOnError', false);
        fclose(fileID);
        aggss_init = [dataArray{1:end-1}];
        
        tau_init = aggss_init(1);
        rss_init = aggss_init(2);
        pnss_init = aggss_init(3);
        bigxss_init = aggss_init(4);
        wss_init = aggss_init(5);
        pxss_init = aggss_init(6);
        ptss_init = aggss_init(7);
        bigKss_init = aggss_init(8);
        bigYtss_init = aggss_init(9);
        bigKtss_init = aggss_init(10);
        bigLtss_init = aggss_init(11);
        bigCtss_init = aggss_init(12);
        bigItss_init = aggss_init(13);
        bigYnss_init = aggss_init(14);
        bigKnss_init = aggss_init(15);
        bigLnss_init = aggss_init(16);
        bigCnss_init = aggss_init(17);
        bigInss_init = aggss_init(18);
        
        bigLss_init = bigLnss_init + bigLtss_init;
        bigCss_init = ptss_init*bigCtss_init+bigCnss_init;
        bigIss_init = ptss_init*bigItss_init+bigInss_init;
        GDP_init = bigYnss_init+ptss_init*bigYtss_init;
        
        upper_omega_init = min((log(tau_init)+eta)/(2*eta),1);
        lower_omega_init = 1-upper_omega_init;        
        
        wtildess_init = wss_init;
        rtildess_init = rss_init-pxss_init*delta;
        zhat_init =  (1/(eta*(theta-1)))^(1/(theta-1))*((tau_init^(-theta))*(exp(eta*(theta-1))-exp(eta*upper_omega_init*(theta-1))))^(1/(theta-1));
        ztilde_init = (1/(eta*(theta-1)))^(1/(theta-1))*((tau_init^(1-theta))*(exp(eta*(theta-1))-exp(eta*upper_omega_init*(theta-1)))+exp(eta*(theta-1))-exp(eta*(1-upper_omega_init)*(theta-1)))^(1/(theta-1));
        
        imports_init = ptss_init*bigYtss_init*(zhat_init/ztilde_init)^(theta-1);
        imp_share_init = imports_init/GDP_init;
        
        clear aggss_init
        
        % --------------------- Get aggregates for final ss ---------------
        %  File with steady state aggregate values
        filename = strcat(projectdir,'aggregates_fin.out');
        endRow = 1;
        formatSpec = '%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, endRow, 'Delimiter', '', 'WhiteSpace', '', 'ReturnOnError', false);
        fclose(fileID);
        aggss_fin = [dataArray{1:end-1}];
        
        tau_fin = aggss_fin(1);
        rss_fin = aggss_fin(2);
        pnss_fin = aggss_fin(3);
        bigxss_fin = aggss_fin(4);
        wss_fin = aggss_fin(5);
        pxss_fin = aggss_fin(6);
        ptss_fin = aggss_fin(7);
        bigKss_fin = aggss_fin(8);
        bigYtss_fin = aggss_fin(9);
        bigKtss_fin = aggss_fin(10);
        bigLtss_fin = aggss_fin(11);
        bigCtss_fin = aggss_fin(12);
        bigItss_fin = aggss_fin(13);
        bigYnss_fin = aggss_fin(14);
        bigKnss_fin = aggss_fin(15);
        bigLnss_fin = aggss_fin(16);
        bigCnss_fin = aggss_fin(17);
        bigInss_fin = aggss_fin(18);
        
        bigLss_fin = bigLnss_fin + bigLtss_fin;
        bigCss_fin = ptss_init*bigCtss_fin+bigCnss_fin; %  For real variables index to initial prices
        bigIss_fin = ptss_init*bigItss_fin+bigInss_fin;
        GDP_fin = bigYnss_fin+ptss_init*bigYtss_fin;  %  For real variables index to initial prices
        
        upper_omega_fin = min((log(tau_fin)+eta)/(2*eta),1);
        lower_omega_fin = 1-upper_omega_fin;   
        
        wtildess_fin = wss_fin;
        rtildess_fin = rss_fin-pxss_fin*delta;
    
        zhat_fin =  (1/(eta*(theta-1)))^(1/(theta-1))*((tau_fin^(-theta))*(exp(eta*(theta-1))-exp(eta*upper_omega_fin*(theta-1))))^(1/(theta-1));
        ztilde_fin = (1/(eta*(theta-1)))^(1/(theta-1))*((tau_fin^(1-theta))*(exp(eta*(theta-1))-exp(eta*upper_omega_fin*(theta-1)))+exp(eta*(theta-1))-exp(eta*(1-upper_omega_fin)*(theta-1)))^(1/(theta-1));
        
        imports_fin = ptss_fin*bigYtss_fin*(zhat_fin/ztilde_fin)^(theta-1);
        imp_share_fin = imports_fin/(bigYnss_fin+ptss_fin*bigYtss_fin);

        trade_elas = ((imports_fin-imports_init)/((imports_fin+imports_init)))/((tau_fin-tau_init)/(tau_fin+tau_init));
        ACR_welf = 100*(((1-imp_share_fin)/(1-imp_share_init))^(1/trade_elas)-1);
        
        clear aggss_fin
        
        % -------------------------------------------------------------------------
        % --------------------- Get transition    --------------
        % % -------------------------------------------------------------------------
        % transtion paths of aggregates
        % dimension : T x (number of aggregates)
        % Note that t = 1 corresponds to aggregate values at the end of period 1
        % (the first period of the policy change)
        
        filename = strcat(projectdir,'transition_full.out');
        formatSpec = '%5f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%18f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '',  'ReturnOnError', false);
        fclose(fileID);
        trans = [dataArray{1:end-1}];
        
        time = trans(:,1);
        rpath = trans(:,2);
        wpath = trans(:,3);
        ptpath = trans(:,4);
        pxpath = trans(:,5);
        bigxpath = trans(:,6);
        bigKpath = trans(:,7);
        bigYtpath = trans(:,8);
        bigYnpath = trans(:,9);
        bigKtpath = trans(:,10);
        bigKnpath = trans(:,11);
        bigLtpath = trans(:,12);
        bigLnpath = trans(:,13);
        bigCtpath = trans(:,14);
        bigCnpath = trans(:,15);
        bigItpath = trans(:,16);
        bigInpath = trans(:,17);
        
        bigLpath = bigLtpath+bigLnpath;
        GDPpath = ptss_init.*bigYtpath+bigYnpath;   %  For real variables index to initial prices
        wtildepath = wpath;
        rtildepath = rpath-pxpath*delta;
        bigCpath = ptss_init*bigCtpath+bigCnpath;   %  For real variables index to initial prices
        
        p_wgt_t = (ptss_init*ct_init)./(ptss_init*ct_init+cn_init);
        p_wgt_nt = 1-p_wgt_t;
        pindex_init = p_wgt_t*ptss_init+p_wgt_nt;
        pindex_fin = p_wgt_t*ptss_fin+p_wgt_nt;
        realwtilde_init = wtildess_init./pindex_init;
        realwtilde_fin = wtildess_fin./pindex_fin;
        
        imports_path = ptpath.*bigYtpath*(zhat_fin/ztilde_fin)^(theta-1);
        imp_share_path = imports_path./(bigYnpath+ptpath.*bigYtpath);
        
        % -------------------------------------------------------------------------
        % --------------------- Get welfare differences  --------------
        % % -------------------------------------------------------------------------
        %  File containing consumption equivalence over the coarse grid for each
        %  income type
        %  dimension : nkpts x nepts
        filename = strcat(projectdir,'trade.wel');
        formatSpec = '%18f%18f%18f%18f%18f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '',  'ReturnOnError', false);
        fclose(fileID);
        welf = [dataArray{1:end-1}];
        welf = welf(:,2:end);
        
        %  Interpolate onto fine grid to multiply against wealth distribution
        welf2 = interp1(xkpts,welf,xk2pts);
        avg_welf2 = 100*sum(sum(fss_init.*welf2));
        
        
        fprintf('\n -- Statistics -- \n')
        fprintf(' Trade elasticity: %2.2f\n',trade_elas);
        fprintf(' ACR welfare change: %2.2f\n',ACR_welf);
        fprintf(' CH welfare change: %2.2f\n',avg_welf2);
        
        %  If we want to look at the ghost household comparisons get the
        %  consumption equivalence for each case
        
        %  only face wtildepath and rtildepath
        filename = strcat(projectdir,'trade_ghost1.wel');
        formatSpec = '%18f%18f%18f%18f%18f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '',  'ReturnOnError', false);
        fclose(fileID);
        welfg1 = [dataArray{1:end-1}];
        welfg1 = welfg1(:,2:end);
        welf2g1 = interp1(xkpts,welfg1,xk2pts);
        
        %  only face pxpath
        filename = strcat(projectdir,'trade_ghost2.wel');
        formatSpec = '%18f%18f%18f%18f%18f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '',  'ReturnOnError', false);
        fclose(fileID);
        welfg2 = [dataArray{1:end-1}];
        welfg2 = welfg2(:,2:end);
        welf2g2 = interp1(xkpts,welfg2,xk2pts);
        
        %  only face ptpath
        filename = strcat(projectdir,'trade_ghost3.wel');
        formatSpec = '%18f%18f%18f%18f%18f%f%[^\n\r]';
        fileID = fopen(filename,'r');
        dataArray = textscan(fileID, formatSpec, 'Delimiter', '', 'WhiteSpace', '',  'ReturnOnError', false);
        fclose(fileID);
        welfg3 = [dataArray{1:end-1}];
        welfg3 = welfg3(:,2:end);
        welf2g3 = interp1(xkpts,welfg3,xk2pts);
        
        clearvars filename formatSpec fileID dataArray endRow trans i j ans;
        
        % Construct Table 1: Real_agg_changes
        table_agg_changes = zeros(5,1);
        table_agg_changes(1,1) = 100*(GDP_fin/GDP_init-1);
        table_agg_changes(2,1) = 100*(bigCss_fin/bigCss_init-1);
        table_agg_changes(3,1) = 100*(bigIss_fin/bigIss_init-1);
        table_agg_changes(4,1) = 100*(bigKss_fin/bigKss_init-1);
        table_agg_changes(5,1) = 100*(bigxss_fin/bigxss_init-1);
        
        % Construct Table 2: Real_agg_changes in tradables
        table_agg_changes_T = zeros(5,1);
        table_agg_changes_T(1,1) = 100*(bigYtss_fin/bigYtss_init-1);
        table_agg_changes_T(2,1) = 100*(bigCtss_fin/bigCtss_init-1);
        table_agg_changes_T(3,1) = 100*(bigItss_fin/bigItss_init-1);
        table_agg_changes_T(4,1) = 100*(bigKtss_fin/bigKtss_init-1);
        table_agg_changes_T(5,1) = 100*(bigLtss_fin/bigLtss_init-1);
        
        table_agg_changes_N = zeros(5,1);
        table_agg_changes_N(1,1) = 100*(bigYnss_fin/bigYnss_init-1);
        table_agg_changes_N(2,1) = 100*(bigCnss_fin/bigCnss_init-1);
        table_agg_changes_N(3,1) = 100*(bigInss_fin/bigInss_init-1);
        table_agg_changes_N(4,1) = 100*(bigKnss_fin/bigKnss_init-1);
        table_agg_changes_N(5,1) = 100*(bigLnss_fin/bigLnss_init-1);
        
        % Construct Table 2: Decompositions
        cdfk_init = [xk2pts cumsum(sum(fss_init,2))];
        cdfk_fin = [xk2pts cumsum(sum(fss_fin,2))];
        
        pct10 = find(cdfk_fin(:,2)<=0.10,1,'last');
        pct20 = find(cdfk_fin(:,2)<=0.20,1,'last');
        pct30 = find(cdfk_fin(:,2)<=0.30,1,'last');
        pct40 = find(cdfk_fin(:,2)<=0.40,1,'last');
        pct50 = find(cdfk_fin(:,2)<=0.50,1,'last');
        pct60 = find(cdfk_fin(:,2)<=0.60,1,'last');
        pct70 = find(cdfk_fin(:,2)<=0.70,1,'last');
        pct80 = find(cdfk_fin(:,2)<=0.80,1,'last');
        pct90 = find(cdfk_fin(:,2)>0.90,1,'first');
        pct25 = find(cdfk_fin(:,2)<=0.25,1,'last');
        pct75 = find(cdfk_fin(:,2)<=0.75,1,'last');
        
        exp_share_wealth = zeros(10,1);
        ct2_fin = interp1(xkpts,ct_fin,xk2pts);
        cn2_fin = interp1(xkpts,cn_fin,xk2pts);
        ct2_init = interp1(xkpts,ct_init,xk2pts);
        cn2_init = interp1(xkpts,cn_init,xk2pts);
        ptct = ptss_fin*ct2_fin;
        
        exp_share_wealth(1) = sum(sum(fss_fin(1:pct10,:).*ptct(1:pct10,:)))/sum(sum(fss_fin(1:pct10,:).*(ptct(1:pct10,:)+cn2_fin(1:pct10,:))));
        exp_share_wealth(2) = sum(sum(fss_fin(pct10:pct20,:).*ptct(pct10:pct20,:)))/sum(sum(fss_fin(2:pct20,:).*(ptct(2:pct20,:)+cn2_fin(2:pct20,:))));
        exp_share_wealth(3) = sum(sum(fss_fin(pct20:pct30,:).*ptct(pct20:pct30,:)))/sum(sum(fss_fin(pct20:pct30,:).*(ptct(pct20:pct30,:)+cn2_fin(pct20:pct30,:))));
        exp_share_wealth(4) = sum(sum(fss_fin(pct30:pct40,:).*ptct(pct30:pct40,:)))/sum(sum(fss_fin(pct30:pct40,:).*(ptct(pct30:pct40,:)+cn2_fin(pct30:pct40,:))));
        exp_share_wealth(5) = sum(sum(fss_fin(pct40:pct50,:).*ptct(pct40:pct50,:)))/sum(sum(fss_fin(pct40:pct50,:).*(ptct(pct40:pct50,:)+cn2_fin(pct40:pct50,:))));
        exp_share_wealth(6) = sum(sum(fss_fin(pct50:pct60,:).*ptct(pct50:pct60,:)))/sum(sum(fss_fin(pct50:pct60,:).*(ptct(pct50:pct60,:)+cn2_fin(pct50:pct60,:))));
        exp_share_wealth(7) = sum(sum(fss_fin(pct60:pct70,:).*ptct(pct60:pct70,:)))/sum(sum(fss_fin(pct60:pct70,:).*(ptct(pct60:pct70,:)+cn2_fin(pct60:pct70,:))));
        exp_share_wealth(8) = sum(sum(fss_fin(pct70:pct80,:).*ptct(pct70:pct80,:)))/sum(sum(fss_fin(pct70:pct80,:).*(ptct(pct70:pct80,:)+cn2_fin(pct70:pct80,:))));
        exp_share_wealth(9) = sum(sum(fss_fin(pct80:pct90,:).*ptct(pct80:pct90,:)))/sum(sum(fss_fin(pct80:pct90,:).*(ptct(pct80:pct90,:)+cn2_fin(pct80:pct90,:))));
        exp_share_wealth(10) = sum(sum(fss_fin(pct90:nk2pts,:).*ptct(pct90:nk2pts,:)))/sum(sum(fss_fin(pct90:nk2pts,:).*(ptct(pct90:nk2pts,:)+cn2_fin(pct90:nk2pts,:))));        
        
        exp_share_wealth_bot25 = sum(sum(fss_fin(1:pct25,:).*ptct(1:pct25,:)))/sum(sum(fss_fin(1:pct25,:).*(ptct(1:pct25,:)+cn2_fin(1:pct25,:))));
        exp_share_wealth_top25 = sum(sum(fss_fin(pct75:nk2pts,:).*ptct(pct75:nk2pts,:)))/sum(sum(fss_fin(pct75:nk2pts,:).*(ptct(pct75:nk2pts,:)+cn2_fin(pct75:nk2pts,:))));
        exp_share_wealth_med = sum(sum(fss_fin(pct50:pct50+1,:).*ptct(pct50:pct50+1,:)))/sum(sum(fss_fin(pct50:pct50+1,:).*(ptct(pct50:pct50+1,:)+cn2_fin(pct50:pct50+1,:))));
        iqr = xk2pts(pct75)/xk2pts(pct25);
        p9050 = xk2pts(pct90)/xk2pts(pct50);
        wealth_gdp = pxss_fin*bigKss_fin/(pnss_fin*bigYnss_fin+ptss_fin*bigYtss_fin);
        
        clear pct*
        
        pct10 = find(cdfk_init(:,2)<=0.10,1,'last');
        pct90 = find(cdfk_init(:,2)>0.90,1,'first');
        pct45 = find(cdfk_init(:,2)>=0.45,1,'first');
        pct55 = find(cdfk_init(:,2)<=0.55,1,'last');
        
        totwelf10_lo = (fss_init(1:pct10,1)'*welf2(1:pct10,1))/sum(fss_init(1:pct10,1));
        totwelf10_med = (fss_init(1:pct10,3)'*welf2(1:pct10,3))/sum(fss_init(1:pct10,3));
        totwelf10_hi = (fss_init(1:pct10,5)'*welf2(1:pct10,5))/sum(fss_init(1:pct10,5));
        totwelfmid_lo = (fss_init(pct45:pct55,1)'*welf2(pct45:pct55,1))/sum(fss_init(pct45:pct55,1));
        totwelfmid_med = (fss_init(pct45:pct55,3)'*welf2(pct45:pct55,3))/sum(fss_init(pct45:pct55,3));
        totwelfmid_hi = (fss_init(pct45:pct55,5)'*welf2(pct45:pct55,5))/sum(fss_init(pct45:pct55,5));
        totwelf90_lo = (fss_init(pct90:end,1)'*welf2(pct90:end,1))/sum(fss_init(pct90:end,1));
        totwelf90_med = (fss_init(pct90:end,3)'*welf2(pct90:end,3))/sum(fss_init(pct90:end,3));
        totwelf90_hi = (fss_init(pct90:end,5)'*welf2(pct90:end,5))/sum(fss_init(pct90:end,5));
        
        % effective factor price ghost
        g1welf10_lo = (fss_init(1:pct10,1)'*welf2g1(1:pct10,1))/sum(fss_init(1:pct10,1));
        g1welf10_med = (fss_init(1:pct10,3)'*welf2g1(1:pct10,3))/sum(fss_init(1:pct10,3));
        g1welf10_hi = (fss_init(1:pct10,5)'*welf2g1(1:pct10,5))/sum(fss_init(1:pct10,5));
        g1welfmid_lo = (fss_init(pct45:pct55,1)'*welf2g1(pct45:pct55,1))/sum(fss_init(pct45:pct55,1));
        g1welfmid_med = (fss_init(pct45:pct55,3)'*welf2g1(pct45:pct55,3))/sum(fss_init(pct45:pct55,3));
        g1welfmid_hi = (fss_init(pct45:pct55,5)'*welf2g1(pct45:pct55,5))/sum(fss_init(pct45:pct55,5));
        g1welf90_lo = (fss_init(pct90:end,1)'*welf2g1(pct90:end,1))/sum(fss_init(pct90:end,1));
        g1welf90_med = (fss_init(pct90:end,3)'*welf2g1(pct90:end,3))/sum(fss_init(pct90:end,3));
        g1welf90_hi = (fss_init(pct90:end,5)'*welf2g1(pct90:end,5))/sum(fss_init(pct90:end,5));
        
        % Px ghost
        g2welf10_lo = (fss_init(1:pct10,1)'*welf2g2(1:pct10,1))/sum(fss_init(1:pct10,1));
        g2welf10_med = (fss_init(1:pct10,3)'*welf2g2(1:pct10,3))/sum(fss_init(1:pct10,3));
        g2welf10_hi = (fss_init(1:pct10,5)'*welf2g2(1:pct10,5))/sum(fss_init(1:pct10,5));
        g2welfmid_lo = (fss_init(pct45:pct55,1)'*welf2g2(pct45:pct55,1))/sum(fss_init(pct45:pct55,1));
        g2welfmid_med = (fss_init(pct45:pct55,3)'*welf2g2(pct45:pct55,3))/sum(fss_init(pct45:pct55,3));
        g2welfmid_hi = (fss_init(pct45:pct55,5)'*welf2g2(pct45:pct55,5))/sum(fss_init(pct45:pct55,5));
        g2welf90_lo = (fss_init(pct90:end,1)'*welf2g2(pct90:end,1))/sum(fss_init(pct90:end,1));
        g2welf90_med = (fss_init(pct90:end,3)'*welf2g2(pct90:end,3))/sum(fss_init(pct90:end,3));
        g2welf90_hi = (fss_init(pct90:end,5)'*welf2g2(pct90:end,5))/sum(fss_init(pct90:end,5));
        
        % Pt ghost
        g3welf10_lo = (fss_init(1:pct10,1)'*welf2g3(1:pct10,1))/sum(fss_init(1:pct10,1));
        g3welf10_med = (fss_init(1:pct10,3)'*welf2g3(1:pct10,3))/sum(fss_init(1:pct10,3));
        g3welf10_hi = (fss_init(1:pct10,5)'*welf2g3(1:pct10,5))/sum(fss_init(1:pct10,5));
        g3welfmid_lo = (fss_init(pct45:pct55,1)'*welf2g3(pct45:pct55,1))/sum(fss_init(pct45:pct55,1));
        g3welfmid_med = (fss_init(pct45:pct55,3)'*welf2g3(pct45:pct55,3))/sum(fss_init(pct45:pct55,3));
        g3welfmid_hi = (fss_init(pct45:pct55,5)'*welf2g3(pct45:pct55,5))/sum(fss_init(pct45:pct55,5));
        g3welf90_lo = (fss_init(pct90:end,1)'*welf2g3(pct90:end,1))/sum(fss_init(pct90:end,1));
        g3welf90_med = (fss_init(pct90:end,3)'*welf2g3(pct90:end,3))/sum(fss_init(pct90:end,3));
        g3welf90_hi = (fss_init(pct90:end,5)'*welf2g3(pct90:end,5))/sum(fss_init(pct90:end,5));

        table_welf_cont = zeros(4,5);
        table_welf_cont(1,:) = [g3welf10_lo g3welf10_hi  g3welf90_lo g3welf90_hi sum(sum(fss_init.*welf2g3))];
        table_welf_cont(2,:) = [g2welf10_lo g2welf10_hi  g2welf90_lo g2welf90_hi sum(sum(fss_init.*welf2g2))];
        table_welf_cont(3,:) = [g1welf10_lo g1welf10_hi  g1welf90_lo g1welf90_hi sum(sum(fss_init.*welf2g1))];
        table_welf_cont(4,:) = [totwelf10_lo totwelf10_hi totwelf90_lo totwelf90_hi sum(sum(fss_init.*welf2))];
        
        table_welf_cont = 100*table_welf_cont;
        
        clear totwelf*
        clear g*welf*
        
        
%         Get some ginis 
        
        gini_k = gini(sum(fss_fin,2),xk2pts/bigKss_fin);
        
        consump = [cn2_fin(:,1)+ptss_fin*ct2_fin(:,1);cn2_fin(:,2)+ptss_fin*ct2_fin(:,2);cn2_fin(:,3)+ptss_fin*ct2_fin(:,3);cn2_fin(:,4)+ptss_fin*ct2_fin(:,4);cn2_fin(:,5)+ptss_fin*ct2_fin(:,5)];
        AA = [fss_fin(:,1);fss_fin(:,2);fss_fin(:,3);fss_fin(:,4);fss_fin(:,5)];
        AA = [AA  consump];
        AA = sortmat(AA,2);
        gini_c = gini(AA(:,1),AA(:,2)/bigCss_fin);
        
        earnings = [wss_fin*0.3*epts(1)*ones(5000,1);wss_fin*0.3*epts(2)*ones(5000,1);wss_fin*0.3*epts(3)*ones(5000,1);wss_fin*0.3*epts(4)*ones(5000,1);wss_fin*0.3*epts(5)*ones(5000,1)];
        BB = sum(fss_fin);
        BB = .3*wss_fin*(BB*epts);
        AA = [fss_fin(:,1);fss_fin(:,2);fss_fin(:,3);fss_fin(:,4);fss_fin(:,5)];
        AA = [AA  earnings];
        AA = sortmat(AA,2);
        gini_e = gini(AA(:,1),AA(:,2)/BB);
        
        clear consump earnings AA BB
        
        
        %  Plot of welfare
        xind = find(xk2pts*pxss_init/GDP_init>20, 1, 'first');
        figure; hold on;
        plot(xk2pts*pxss_init/GDP_init,100*welf2(:,1),'b','Linewidth',2)
        plot(xk2pts*pxss_init/GDP_init,100*welf2(:,5),'r--','Linewidth',2)
        legend('Low productivity','High productivity','Location','Best')
        xlabel('Wealth')
        xlim([xk2pts(1)*pxss_init/GDP_init 20])
        ylabel('Consumption equivalent (percent)')
        ymin = min(-0.5, ...
            min( min (welf2(1:xind,:)) )*100*1.05 );
        ymax = max(0.5, ...
            max( max (welf2(1:xind,:)) )*100*1.05 );
        ylim([ymin ymax])
        hold off;
        
        if (nprint == 1)
            set(gcf,'position',[100,420,320,250])
            print welfare.eps -depsc
        elseif (nprint == 2)
        ymin = 0;
        ymax = ymin + 2;
        yticks([0 1 2]);
        ylim([ymin ymax])
        box on
        set(gcf,'position',[100,420,320,250])
        set(gcf,'Units','inches');
        screenposition = get(gcf,'Position');
        set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
            'PaperSize',[screenposition(3:4)]);
        filename = sprintf('../figures/welf_base.pdf');
        print(filename,'-dpdf','-painters')
        end
        
        %  Plot of expenditure shares 
        figure; hold on;
        plot(xkpts*pxss_init/GDP_init,100*(ptss_fin*ct_fin(:,1)./(ptss_fin*ct_fin(:,1)+cn_fin(:,1))),'b','Linewidth',2)
        plot(xkpts*pxss_init/GDP_init,100*(ptss_fin*ct_fin(:,3)./(ptss_fin*ct_fin(:,3)+cn_fin(:,3))),'r--','Linewidth',2)
        plot(xkpts*pxss_init/GDP_init,100*(ptss_fin*ct_fin(:,5)./(ptss_fin*ct_fin(:,5)+cn_fin(:,5))),'g-.','Linewidth',2)
        xlabel('Wealth')
        ylabel('Percent')
        if (nprint == 0)
            title('Tradable expenditure shares by wealth and labor income group','FontSize',12)
        end
        legend('Low income','Middle income','High income','Location','Best')
        xlim([xkpts(1)*pxss_init/GDP_init 20])
        hold off;
        
        if (nprint == 1)
            print exp_share.eps -depsc
        elseif (nprint == 2)
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/exp_share.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        %  Plot of expenditure shares by wealth
        figure; hold on;
        plot(xk2pts*pxss_init/GDP_init,100*(ptss_init*sum(ct2_init.*fss_init,2))./(ptss_init*sum(ct2_init.*fss_init,2)+sum(cn2_init.*fss_init,2)),'b','Linewidth',2)
        plot(xk2pts*pxss_fin/GDP_fin,100*(ptss_fin*sum(ct2_fin.*fss_fin,2))./(ptss_fin*sum(ct2_fin.*fss_fin,2)+sum(cn2_fin.*fss_fin,2)),'r-','Linewidth',2)
        xlabel('Wealth')
        ylabel('Percent')
        if (nprint == 0)
            title('Tradable expenditure shares by wealth ','FontSize',12)
        end
        legend('Initital','Final','Location','Best')
        xlim([xkpts(1)*pxss_init/GDP_init 20])
        hold off;
        
%         pause
        if (nprint == 1)
            print exp_share_wealth.eps -depsc
        elseif (nprint == 2)
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/exp_share_wealth.pdf');
            print(filename,'-dpdf','-painters')
        end
       
        
        %  Plot of inflation
        figure; hold on;
        plot(xkpts*pxss_init/GDP_init,100*(pindex_fin(:,1)./pindex_init(:,1)-1),'b','Linewidth',2)
        plot(xkpts*pxss_init/GDP_init,100*(pindex_fin(:,3)./pindex_init(:,3)-1),'r--','Linewidth',2)
        plot(xkpts*pxss_init/GDP_init,100*(pindex_fin(:,5)./pindex_init(:,5)-1),'g-.','Linewidth',2)
        xlabel('Wealth')
        ylabel('Percent')
        if (nprint == 0)
            title('Inflation by wealth and labor income group','FontSize',12)
        end
        legend('Low income','Middle income','High income','Location','Best')
        xlim([xkpts(1)*pxss_init/GDP_init 20])
        hold off;
        
        if (nprint == 1)
            print inflation.eps -depsc
        elseif (nprint == 2)
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/inflation.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        agg_infl = (ptss_fin*bigCtss_init + bigCnss_init)/(bigCtss_init + bigCnss_init) ...
            /((ptss_init*bigCtss_init + bigCnss_init)/(bigCtss_init + bigCnss_init)) -1;
        
        %  Plot of real wage change
        figure; hold on;
        plot(xkpts*pxss_init/GDP_init,100*(realwtilde_fin(:,1)./realwtilde_init(:,1)-1),'b','Linewidth',2)
        plot(xkpts*pxss_init/GDP_init,100*(realwtilde_fin(:,3)./realwtilde_init(:,3)-1),'r--','Linewidth',2)
        plot(xkpts*pxss_init/GDP_init,100*(realwtilde_fin(:,5)./realwtilde_init(:,5)-1),'g-.','Linewidth',2)
        xlabel('Wealth')
        ylabel('Percent')
        if (nprint == 0)
            title('Real wage change by wealth and labor income group','FontSize',12)
        end
        % legend('Bottom 6.25%','6.25%-31.25%','31.25%-68.75%','68.75%-93.75%','Top 6.25%','Location','SouthEast')
        legend('Low income','Middle income','High income','Location','Best')
        xlim([xkpts(1)*pxss_init/GDP_init 20])
        hold off;
        
        if (nprint == 1)
            print realwage.eps -depsc
        elseif (nprint == 2)
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/realwage.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        %  Plot of price transitions
        Tplot = 60;
        Taxis = [linspace(-10,0.99,11)';0.999;(1:1:Tplot)'];
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;ptpath(1:Tplot)/ptss_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Tradables price','FontSize',12)
        end
        xlim([-10 Tplot])
        ymin = 95;
        ymax = 105;
        ylim([ymin ymax])
        hold off;
        if (nprint == 1)
            print trans_pt.eps -depsc
        elseif (nprint == 2)
        xticks([ 0 20 40 Tplot])
        ymax = 105;
        ymin = 95;
        yticks([95 100 105]);
        ylim([ymin ymax])
        box on
        set(gcf,'position',[700,360,320,250])
        set(gcf,'Units','inches');
        screenposition = get(gcf,'Position');
        set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
            'PaperSize',[screenposition(3:4)]);
        filename = sprintf('../figures/trans_pt.pdf');
        print(filename,'-dpdf','-painters')
        end
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;pxpath(1:Tplot)/pxss_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Investment price','FontSize',12)
        end
        xlim([-10 Tplot])
        ymin = 95;
        ymax = 105;
        ylim([ymin ymax])
        hold off;
        if (nprint == 1)
            print trans_px.eps -depsc
        elseif (nprint == 2)
            xticks([ 0 20 40 Tplot]);
            ymin = 95;
            ymax = 105;
            yticks([95 100 105]);
            ylim([ymin ymax])
            box on
            set(gcf,'position',[1020,360,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_px.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        figure; hold on;
        plot(Taxis,100*[rtildess_init*ones(11,1);NaN;rtildepath(1:Tplot)],'linewidth',2)
        xlabel('Time')
        ylabel('Percent')
        if (nprint == 0)
            title('Effective return on capital','FontSize',12)
        end
        xlim([-10 Tplot])
        ymin = max( ...
            100*min(rtildess_init,min(rtildepath))*.95, ...
            floor(100*min(rtildess_init,min(rtildepath))) ...
            );
        ymax = min( ...
            100*max(rtildess_init,max(rtildepath))*1.05, ...
            ceil(100*max(rtildess_init,max(rtildepath))) ...
            );
        hold off
        ylim([ymin ymax])
        if (nprint == 1)
            print trans_rtilde.eps -depsc
        elseif (nprint == 2)
            ymin = 2.0;
            ymax = 3.0;
            yticks([2.0 2.5 3.0]);
            xticks([ 0 20 40 Tplot]);
            ylim([ymin ymax])
            box on
            set(gcf,'position',[700,700,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_rtilde.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;wtildepath(1:Tplot)/wtildess_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Effective wage','FontSize',12)
        end
        xlim([-10 Tplot])
        ymin = 95;
        ymax = 105;
        ylim([ymin ymax])
        hold off
        if (nprint == 1)
            print trans_wtilde.eps -depsc
        elseif (nprint == 2)
            xticks([ 0 20 40 Tplot]);
            ymin = 95;
            ymax = 105;
            yticks([95 100 105]);
            ylim([ymin ymax])
            box on
            set(gcf,'position',[1020,700,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_wtilde.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        %  Plot of aggregate quantity transitions
        ymin = min(95, floor( ...
            min( [ ...
            100*min(bigCtpath/bigCtss_init)*.99,  ...
            100*min(bigCnpath/bigCnss_init)*.99,  ...
            100*min(bigxpath/bigxss_init)*.99,  ...
            100*min(GDPpath/GDP_init)*.99 ...
            ] ) ) );
        ymax = max(105, ceil( ...
            max( [ ...
            100*max(bigCtpath/bigCtss_init)*1.01, ...
            100*max(bigCnpath/bigCnss_init)*1.01, ...
            100*max(bigxpath/bigxss_init)*1.01, ...
            100*max(GDPpath/GDP_init)*1.01 ...
            ] ) ) );
        ymin = min(ymin,max(95,200-ymax));
        ymax = max(ymax,min(105,200-ymin));
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;bigCtpath(1:Tplot)/bigCtss_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Tradable consumption','FontSize',12)
        end
        xlim([-10 Tplot])
        ylim([ymin ymax])
        hold off;
        if (nprint == 1)
            print trans_ct.eps -depsc
        elseif (nprint == 2)
            ymax = 105;
            ymin = 95;
            yticks([95 100 105]);
            box on
            ylim([ymin ymax])
            xticks([0 20 40 Tplot])
            set(gcf,'position',[1100,420,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_ct.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;bigCnpath(1:Tplot)/bigCnss_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Nontradable consumption','FontSize',12)
        end
        xlim([-10 Tplot])
        ylim([ymin ymax])
        hold off;
        if (nprint == 1)
            print trans_cn.eps -depsc
        elseif (nprint == 2)
            ymin = 95;
            ymax = 105;
            yticks([95 100 105]);
            box on
            ylim([ymin ymax])
            xticks([0 20 40 Tplot])
            set(gcf,'position',[1420,420,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_cn.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;bigxpath(1:Tplot)/bigxss_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Investment','FontSize',12)
        end
        xlim([-10 Tplot])
        ylim([ymin ymax])
        hold off;
        if (nprint == 1)
            print trans_x.eps -depsc
        elseif (nprint == 2)
            ymax = 105;
            ymin = 95;
            yticks([95 100 105]);
            box on
            ylim([ymin ymax])
            xticks([0 20 40 Tplot])
            set(gcf,'position',[1100,100,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_x.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;GDPpath(1:Tplot)/GDP_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('GDP','FontSize',12)
        end
        xlim([-10 Tplot])
        ylim([ymin ymax])
        hold off;
        if (nprint == 1)
            print trans_gdp.eps -depsc
        elseif (nprint == 2)
            ymin = 95;
            ymax = 105;
            yticks([95 100 105]);
            box on
            ylim([ymin ymax])
            xticks([0 20 40 Tplot])
            set(gcf,'position',[1420,100,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_gdp.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;bigCpath(1:Tplot)/bigCss_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Aggregate consumption','FontSize',12)
        end
        xlim([-10 Tplot])
        ylim([ymin ymax])
        hold off;
        if (nprint == 1)
            print trans_c.eps -depsc
        elseif (nprint == 2)
            ymin = 95;
            ymax = 105;
            yticks([95 100 105]);
            box on
            ylim([ymin ymax])
            xticks([0 20 40 Tplot])
            set(gcf,'position',[1420,760,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_c.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        % Plot of K transition

        ymin = 95.0;
        ymax = 105.0;
        
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;bigKpath(1:Tplot)/bigKss_init],'linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Capital','FontSize',12)
        end
        xlim([-10 Tplot])
        ylim([ymin ymax])
        hold off
        if (nprint == 1)
            print trans_capital.eps -depsc
        elseif (nprint == 2)
            box on
            xticks([ 0 20 40 Tplot]);
            ymin = 95;
            ymax = 105;
            yticks([95 100 105]);
            ylim([ymin ymax])
            set(gcf,'position',[1100,100,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_capital.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        % Plot of sector aggregates over time
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;bigLtpath(1:Tplot)/bigLtss_init],'b','linewidth',2)
        plot(Taxis,100*[ones(11,1);NaN;bigLnpath(1:Tplot)/bigLnss_init],'r','linewidth',2)
        plot(Taxis,100*[ones(11,1);NaN;bigKtpath(1:Tplot)/bigKtss_init],'g--','linewidth',2)
        plot(Taxis,100*[ones(11,1);NaN;bigKnpath(1:Tplot)/bigKnss_init],'k--','linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Transition paths aggregates by sector','FontSize',12)
        end
        legend('L_{T}','L_{N}','K_{T}','K_{N}','Location','best','Orientation','horizontal')
        ymin = floor( ...
            100*min( [min(bigLtpath)/bigLtss_init, min(bigLnpath)/bigLnss_init, ...
            min(bigKtpath)/bigKtss_init, min(bigKnpath)/bigKnss_init] )*0.99 ...
            );
        ymax = ceil( ...
            100*max( [ max(bigLtpath)/bigLtss_init, max(bigLnpath)/bigLnss_init, ...
            max(bigKtpath)/bigKtss_init, max(bigKnpath)/bigKnss_init] )*1.01 ...
            );
        ymin = min(ymin,max(95,200-ymax));
        ymax = max(ymax,min(105,200-ymin));
        ylim([ymin ymax])
        xlim([0 Tplot])
        hold off;
        
        if (nprint == 1)
            print trans_sectors.eps -depsc
        elseif (nprint == 2)
            box on
            ymax = 105;
            ymin = 95;
            ylim([ymin ymax])
            yticks([95 100 105]);
            xticks([0 20 40 Tplot])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/trans_sectors.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        % Plot of K/L ratios in each sector
        figure; hold on;
        plot(Taxis,100*[ones(11,1);NaN;(bigKtpath(1:Tplot)./bigLtpath(1:Tplot))/(bigKtss_init/bigLtss_init)],'b','linewidth',2)
        plot(Taxis,100*[ones(11,1);NaN;(bigKnpath(1:Tplot)./bigLnpath(1:Tplot))/(bigKnss_init/bigLnss_init)],'r--','linewidth',2)
        xlabel('Time')
        ylabel('Index (period 0 = 100)')
        if (nprint == 0)
            title('Transition paths capital-to-labor ratios by sector','FontSize',12)
        end
        legend('k_{T}','k_{N}','Location','best','Orientation','horizontal')
        ymin = floor( ...
            100*min( [min(bigKtpath./bigLtpath)/(bigKtss_init/bigLtss_init), ...
            min(bigKnpath./bigLnpath)/(bigKnss_init/bigLnss_init) ] )*0.99 ...
            );
        ymax = ceil( ...
            100*max( [max(bigKtpath./bigLtpath)/(bigKtss_init/bigLtss_init), ...
            max(bigKnpath./bigLnpath)/(bigKnss_init/bigLnss_init) ] )*1.01 ...
            );
        ymin = min(ymin,max(95,200-ymax));
        ymax = max(ymax,min(105,200-ymin));
        ylim([ymin ymax])
        hold off;
        
        % Plots of ghost welfare comparisons
        
        %  rtilde and wtildepath only ghost
        figure; hold on;
        plot(xk2pts*pxss_init/GDP_init,100*welf2g1(:,1),'b','Linewidth',2)
        plot(xk2pts*pxss_init/GDP_init,100*welf2g1(:,5),'r--','Linewidth',2)
        legend('low productivity','high productivity','Location','best')
        xlabel('Wealth')
        xlim([xk2pts(1)*pxss_init/GDP_init 20])
        ylabel('Consumption equivalent (percent)')
        if (nprint == 0)
            title('Factor price channel','FontSize',12)
        end
        ymin = min(-0.5, ...
            min( min ( min( welf2(1:xind,:), welf2g1(1:xind,:) ) ) )*100*1.05 );
        ymax = max(0.5, ...
            max( max ( max( welf2(1:xind,:), welf2g1(1:xind,:) ) ) )*100*1.05 );
        ymin = min(ymin,max(0.5,-ymax));
        ymax = max(ymax,min(0.5,-ymin));
        ylim([ymin ymax])
        hold off;
        
        if (nprint == 1)
            print ghost_wrtilde.eps -depsc
        elseif (nprint == 2)
            ymin = 0;
            ymax = ymin + 2;
            yticks([0 1 2]);
            ylim([ymin ymax])
            box on
            legend off
            set(gcf,'position',[420,420,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/ghost_wrtilde.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        %  pxpath only ghost
        figure; hold on;
        plot(xk2pts*pxss_init/GDP_init,100*welf2g2(:,1),'b','Linewidth',2)
        plot(xk2pts*pxss_init/GDP_init,100*welf2g2(:,5),'r--','Linewidth',2)
        xlabel('Wealth')
        xlim([xk2pts(1)*pxss_init/GDP_init 20])
        ylabel('Consumption equivalent (percent)')
        if (nprint == 0)
            title('Investment channel','FontSize',12)
        end
        legend('low productivity','high productivity','Location','best')
        ymin = min(-0.5, ...
            min( min ( min( welf2(1:xind,:), welf2g2(1:xind,:) ) ) )*100*1.05 );
        ymax = max(0.5, ...
            max( max ( max( welf2(1:xind,:), welf2g2(1:xind,:) ) ) )*100*1.05 );
        ymin = min(ymin,max(0.5,-ymax));
        ymax = max(ymax,min(0.5,-ymin));
        ylim([ymin ymax])
        hold off;
        
        if (nprint == 1)
            print ghost_px.eps -depsc
        elseif (nprint == 2)
            ymin = -1;
            ymax = ymin + 2;
            yticks([-1 0 1]);
            ylim([ymin ymax])
            box on
            legend off
            set(gcf,'position',[100,100,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/ghost_px.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        %  ptpath only ghost
        figure; hold on;
        plot(xk2pts*pxss_init/GDP_init,100*welf2g3(:,1),'b','Linewidth',2)
        plot(xk2pts*pxss_init/GDP_init,100*welf2g3(:,5),'r--','Linewidth',2)
        xlabel('Wealth')
        xlim([xk2pts(1)*pxss_init/GDP_init 20])
        ylabel('Consumption equivalent (percent)')
        if (nprint == 0)
            title('Expenditure channel','FontSize',12)
        end
        legend('low productivity','high productivity','Location','best')
        ymin = min(-0.5, ...
            min( min ( min( welf2(1:xind,:), welf2g3(1:xind,:) ) ) )*100*1.05 );
        ymax = max(0.5, ...
            max( max ( max( welf2(1:xind,:), welf2g3(1:xind,:) ) ) )*100*1.05 );
        ymin = min(ymin,max(0.5,-ymax));
        ymax = max(ymax,min(0.5,-ymin));
        ylim([ymin ymax])
        hold off;
        
        if (nprint == 1)
            print ghost_pt.eps -depsc
        elseif (nprint == 2)
            ymin = 0;
            ymax = ymin + 2;
            yticks([0 1 2]);
            ylim([ymin ymax])

            box on
            legend off
            set(gcf,'position',[420,100,320,250])
            set(gcf,'Units','inches');
            screenposition = get(gcf,'Position');
            set(gcf,'PaperPosition',[0 0 screenposition(3:4)], ...
                'PaperSize',[screenposition(3:4)]);
            filename = sprintf('../figures/ghost_pt.pdf');
            print(filename,'-dpdf','-painters')
        end
        
        if (saveresults == 1)
            filename = sprintf('modeloutput.xlsx');
            header = {'P_T' 'P_X' 'w' 'r' 'wtilde' 'rtilde' ...
            'C_T' 'C_N' 'Real C' 'X' 'Real GDP' ...
            'L_T' 'L_N' '' 'K_T' 'K_N' 'K' 'Y_T' 'Y_N' ...
            'imports'};
            
            dist_type = sprintf('base');

            xlswrite(filename, header, dist_type);
            % Prices
            xlswrite(filename, ptss_init, dist_type, 'A2');
            xlswrite(filename, ptpath, dist_type, 'A3');
            xlswrite(filename, pxss_init, dist_type, 'B2');
            xlswrite(filename, pxpath, dist_type, 'B3');
            xlswrite(filename, wss_init, dist_type, 'C2');
            xlswrite(filename, wpath, dist_type, 'C3');
            xlswrite(filename, rss_init, dist_type, 'D2');
            xlswrite(filename, rpath, dist_type, 'D3');
            xlswrite(filename, wtildess_init, dist_type, 'E2');
            xlswrite(filename, wtildepath, dist_type, 'E3');
            xlswrite(filename, rtildess_init, dist_type, 'F2');
            xlswrite(filename, rtildepath, dist_type, 'F3');

            % Expenditures
            xlswrite(filename, bigCtss_init, dist_type, 'G2');
            xlswrite(filename, bigCtpath, dist_type, 'G3');
            xlswrite(filename, bigCnss_init, dist_type, 'H2');
            xlswrite(filename, bigCnpath, dist_type, 'H3');
            xlswrite(filename, bigCss_init, dist_type, 'I2');
            xlswrite(filename, bigCpath, dist_type, 'I3');
            xlswrite(filename, bigxss_init, dist_type, 'J2');
            xlswrite(filename, bigxpath, dist_type, 'J3');
            xlswrite(filename, GDP_init, dist_type, 'K2');
            xlswrite(filename, GDPpath, dist_type, 'K3');

            % Factors
            xlswrite(filename, bigLtss_init, dist_type, 'L2');
            xlswrite(filename, bigLtpath, dist_type, 'L3');
            xlswrite(filename, bigLnss_init, dist_type, 'M2');
            xlswrite(filename, bigLnpath, dist_type, 'M3');
    %             xlswrite(filename, bigLss_init, dist_type, 'N2');
    %             xlswrite(filename, bigLpath, dist_type, 'N3');
            xlswrite(filename, bigKtss_init, dist_type, 'O2');
            xlswrite(filename, bigKtpath, dist_type, 'O3');
            xlswrite(filename, bigKnss_init, dist_type, 'P2');
            xlswrite(filename, bigKnpath, dist_type, 'P3');
            xlswrite(filename, bigKss_init, dist_type, 'Q2');
            xlswrite(filename, bigKpath, dist_type, 'Q3');
            xlswrite(filename, bigYtss_init, dist_type, 'R2');
            xlswrite(filename, bigYtpath, dist_type, 'R3');
            xlswrite(filename, bigYnss_init, dist_type, 'S2');
            xlswrite(filename, bigYnpath, dist_type, 'S3');

            % Other statistics
            xlswrite(filename, imports_init, dist_type, 'T2');
            xlswrite(filename, imports_path, dist_type, 'T3');

            % Welfare
            header2 = {'Table: Decomposition of welfare changes' '' '' '' '' '' '';   ...
                '' 'Low wealth' '' 'High wealth' '' '' '';     ...
                'Channels' 'Low prod.' 'High prod.' 'Low prod.' 'High prod.' 'Average' 'ACR';     ...
                'Expenditure' '' '' '' '' '' '';
                'Investment' '' '' '' '' '' '';
                'Factor price' '' '' '' '' '' '';
                'All' '' '' '' '' '' ''};

            xlswrite(filename, header2, dist_type, 'V1');
            xlswrite(filename, table_welf_cont, dist_type, 'W4');
            xlswrite(filename, ACR_welf, dist_type, 'AB7');
        
        end







