
	This file provides an overview of how to how replicate the results for the baseline case of "On the Heterogeneous Welfare Gains and Losses from Trade." There are three types of codes.

1) Stata files for reproducing the findings in Section 2 of the paper.
2) Fortran files which solve the model in Section 3 following the experiment detailed in Section 4.
3) Matlab files for generating the plots and tables in the paper.



****************  REPRODUCING EMPIRICAL FINDINGS IN STATA **********************

Main code: CH_2020_JME_data.do
Data files: cex0414_build.dta, psid0414_build.dta

CH_2020_JME_data.do reads in cex0414_build.dta and psid0414_build.dta and generates Figures 1 and 2 and Table 1. See Appendix A for details on how we construct the CEX and PSID datasets.

Output files: cex_share_by_inc_rank.pdf, cex_share_by_wealth_rank.pdf, psid_share_by_inc_rank.pdf, psid_share_by_wealth_rank.pdf


****************  COMPUTING THE MODEL IN FORTRAN *******************************

Main code: trade_expshare.f90
Support codes: matrix4.f,pchip.f90
Solver codes: ffsqp.f,qld.f
Input files: xkpts50.in,calibration.out,trans_sol.out

trade_expshare.f90 calls the support and solver codes.  It also reads in values from xkpts50.in. The file, calibration.out, is provided if the user wishes to uses the calibration in the paper.  Otherwise, change the value of calibed from 'true' to 'false' in trade_expshare.f90.  
The initial and final steady states are solved for (the solutions for the baseline are coded into the trade_expshare.f90 as initial values of the variable z2). 
Next the code solves for the transition path of the interest rate. If the variable nread2 is set to the value '1' in parameters_mod, then the baseline solution will be read in from 'trans_sol.out'.  
Finally, if 'nghost' in parameters_mod is set to 1, then welfare for will be computed for the ghost households (see Section 4.2.2 in the paper).  This must be done to decompose the welfare channels.

Output files: trade.wel, trade_ghost1.wel, trade_ghost2.wel, trade_ghost3.wel, saving1.out, saving2.out, saving3.out, transition_full.out, trans_sol.out, aggregates_init.out, aggregates_fin.out, saving_ss.f1, saving_ss.fstart, saving_ss.out, saving_ss_fin.f1, saving_ss_fin.out, parameters.out, epts.out, pie.out


****************  GENERATING FIGURES IN MATLAB *****************************

main code: main.m
support codes: gini.m, sortmat.m

Place the input files and the output files from the Fortan section above into subfolder titled 'results'.

main.m will interpret these files and display the results in the matlab workspace.  It will also produce Table 4 in the paper. It will be called 'tab_welf_cont' in the workspace.  

