close all;
clear all;


hist1=dlmread('hist_1.txt','');
hist3=dlmread('hist_3.txt','');
% hist4=dlmread('hist_4.txt','');

maxSS=length(hist1)-1;

figure; % Histogram of Sudden Stops by Era
subplot(3,1,1);
bar(0:1:maxSS,hist1(1:maxSS+1,1),1);
axis([-0.5,maxSS 0 1]);
title('1992-1996')

subplot(3,1,2);
bar(0:1:maxSS,hist1(1:maxSS+1,2),1);
axis([-0.5,maxSS 0 1]);
title('1997-2001')

subplot(3,1,3);
bar(0:1:maxSS,hist1(1:maxSS+1,3),1);
axis([-0.5,maxSS 0 1]);
title('2002-2006')
xlabel('Number of Sudden Stops')

maxSS=length(hist3)-1;

figure; % Histogram of Sudden Stops by Era
subplot(3,1,1);
bar(0:1:maxSS,hist3(:,1),1);
axis([-0.5,maxSS 0 1]);
title('1992-1996')

subplot(3,1,2);
bar(0:1:maxSS,hist3(:,2),1);
axis([-0.5,maxSS 0 1]);
title('1997-2001')

subplot(3,1,3);
bar(0:1:maxSS,hist3(:,3),1);
axis([-0.5,maxSS 0 1]);
title('2002-2006')
xlabel('Number of Sudden Stops')

% maxSS=18;
% 
% figure; % Histogram of Sudden Stops by Era
% subplot(3,1,1);
% bar(0:1:maxSS,hist4(:,1),1);
% axis([-0.5,maxSS 0 1]);
% title('1990-1996')
% 
% subplot(3,1,2);
% bar(0:1:maxSS,hist4(:,2),1);
% axis([-0.5,maxSS 0 1]);
% title('1997-2001')
% 
% subplot(3,1,3);
% bar(0:1:maxSS,hist4(:,3),1);
% axis([-0.5,maxSS 0 1]);
% title('2002-2007')
% xlabel('Number of Sudden Stops')