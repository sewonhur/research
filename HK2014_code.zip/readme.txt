Authors: Sewon Hur & Illenin Kondo

Date: April 4, 2014

Description: Code for "A Theory of Rollover Risk, Sudden Stops, and Foreign Reserves"

The code is mainly written in FORTRAN. 
A Matlab file is provided to produce histograms

See computational appendix and paper for additional details.

Comments welcome.