%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Paper: The Lost Generation of the Great Recession
%
% Plot results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
close all;

%% READ DATA %%
params = importdata('params_matlab.out',' ',1);
period = params.data(1);
N_a = params.data(2);
N_z = params.data(3);
N_xi = params.data(4);
N_bprime = params.data(5);
N_xprime = params.data(6);
N_y = params.data(7);
N_y_mu = params.data(8);
N_alpha = params.data(9);
N_s = params.data(10);
jmax = params.data(11);
jret = params.data(12);
cashbar = params.data(13);
beta = params.data(14);
fc = params.data(15);
fcy = params.data(16);
e_return = params.data(17);
sigma_xi = params.data(18);
Rs_annual   = params.data(19);
beta_adj = beta^period;
siz = jmax*N_a*N_z*N_y;
psi_j = dlmread('survival.out','');
ae_j = dlmread('adultequiv.out','');
clear params

ageprofile = importdata('AGE_PROFILES.out',' ',1);
avg_risky = ageprofile.data(:,1);
avg_bonds = ageprofile.data(:,2);
avg_leverage = ageprofile.data(:,3);
avg_riskpart = ageprofile.data(:,4);
rpj_ss = avg_riskpart;
mu_j = ageprofile.data(:,5);
clear ageprofile

% optimal bond positions bprime(a,z,y,j)
bss=dlmread('bprime_ss.out','');
[i,j]=size(bss);
bss=reshape(bss',i*j,1);            % transpose array into column vector
bss=bss(1:siz);                     % store only data (drop empty terms)
bss=reshape(bss, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% optimal risky asset positions xprime(a,z,y,j)
xss=dlmread('xprime_ss.out','');
[i,j]=size(xss);
xss=reshape(xss',i*j,1);            % transpose array into column vector
xss=xss(1:siz);                     % store only data (drop empty terms)
xss=reshape(xss, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% optimal risky share alpha(a,z,y,j)
alphass=dlmread('alpha_ss.out','');
[i,j]=size(alphass);
alphass=reshape(alphass',i*j,1);            % transpose array into column vector
alphass=alphass(1:siz);                     % store only data (drop empty terms)
alphass=reshape(alphass, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% optimal savigns rate saving(a,z,y,j)
sss=dlmread('saving_ss.out','');
[i,j]=size(sss);
sss=reshape(sss',i*j,1);            % transpose array into column vector
sss=sss(1:siz);                     % store only data (drop empty terms)
sss=reshape(sss, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% consumption(a,z,y,j)
css=dlmread('consumption_ss.out','');
[i,j]=size(css);
css=reshape(css',i*j,1);            % transpose array into column vector
css=css(1:siz);                     % store only data (drop empty terms)
css=reshape(css, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% Value function vf(a,z,y,j)
vss=dlmread('vf_ss.out','');
[i,j]=size(vss);
vss=reshape(vss',i*j,1);            % transpose array into column vector
vss=vss(1:siz);                     % store only data (drop empty terms)
vss=reshape(vss,N_a,N_z,N_y,jmax);	% reshape vector into matrix

% wealth distribution(a,z,y,j)
muss=dlmread('distribution_ss.out','');
[i,j]=size(muss);
muss=reshape(muss',i*j,1);          % transpose array into column vector
muss=muss(1:siz);                   % store only data (drop empty terms)
muss=reshape(muss, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% distribution(z,y,j)
muzyj=dlmread('muzyj.out','');
[i,j]=size(muzyj);
muzyj=reshape(muzyj',i*j,1);    	% transpose array into column vector
muzyj=muzyj(1:N_z*N_y_mu*jmax);     % store only data (drop empty terms)
muzyj=reshape(muzyj, N_z,N_y_mu,jmax);	% reshape vector into matrix

% retiremnt income(y)
ss=dlmread('income_mat.out','');
[i,j]=size(ss);
ss=reshape(ss',i*j,1);              % transpose array into column vector
ss=ss(1:N_y);                       % store only data (drop empty terms)

% a_grid
a_grid=dlmread('a_grid.out','');
[i,j]=size(a_grid);
a_grid=reshape(a_grid',i*j,1);      % transpose array into column vector
a_grid=a_grid(1:N_a);               % store only data (drop empty terms)
[~,ia_zero] = min(abs(a_grid));

% b_grid
b_grid=dlmread('b_grid.out','');
[i,j]=size(b_grid);
b_grid=reshape(b_grid',i*j,1);      % transpose array into column vector
b_grid=b_grid(1:N_bprime);          % store only data (drop empty terms)
[~,ib_zero] = min(abs(b_grid));

% x_grid
x_grid=dlmread('x_grid.out','');
[i,j]=size(x_grid);
x_grid=reshape(x_grid',i*j,1);      % transpose array into column vector
x_grid=x_grid(1:N_xprime);          % store only data (drop empty terms)

% alpha_grid
alpha_grid=dlmread('alpha_grid.out','');
[i,j]=size(alpha_grid);
alpha_grid=reshape(alpha_grid',i*j,1);	% transpose array into column vector
alpha_grid=alpha_grid(1:N_alpha);	% store only data (drop empty terms)

% s_grid
s_grid=dlmread('s_grid.out','');
[i,j]=size(s_grid);
s_grid=reshape(s_grid',i*j,1);      % transpose array into column vector
s_grid=s_grid(1:N_s);               % store only data (drop empty terms)

% age-income profile eta_j
eta_j=dlmread('eta_j.out','');
[i,j]=size(eta_j);
eta_j=reshape(eta_j',i*j,1);        % transpose array into column vector
eta_j=eta_j(1:jmax);                % store only data (drop empty terms)

% z_grid
z_grid=dlmread('z_grid.out','');
[i,j]=size(z_grid);
z_grid=reshape(z_grid',i*j,1);      % transpose array into column vector
z_grid=z_grid(1:N_z);               % store only data (drop empty terms)

z_grid = exp(z_grid);

% y_grid
y_grid=dlmread('y_grid.out','');
[i,j]=size(y_grid);
y_grid=reshape(y_grid',i*j,1);      % transpose array into column vector
y_grid=y_grid(1:N_y);

% y_grid_mu
y_grid_mu=dlmread('y_grid_mu.out','');
[i,j]=size(y_grid_mu);
y_grid_mu=reshape(y_grid_mu',i*j,1);	% transpose array into column vector
y_grid_mu=y_grid_mu(1:N_y_mu);

% xi_grid
xi_grid=dlmread('xi_grid.out','');
[i,j]=size(xi_grid);
xi_grid=reshape(xi_grid',i*j,1); 	% transpose array into column vector
xi_grid=xi_grid(1:N_xi);            % store only data (drop empty terms)

% pr_xi
pr_xi=dlmread('pr_xi.out','');
[i,j]=size(pr_xi);
pr_xi=reshape(pr_xi',i*j,1);        % transpose array into column vector
pr_xi=pr_xi(1:N_xi);                % store only data (drop empty terms)

% ptran(z,z)
ptran=dlmread('ptran.out','');
[i,j]=size(ptran);
ptran=reshape(ptran',i*j,1);        % transpose array into column vector
ptran=ptran(1:N_z*N_z);             % store only data (drop empty terms)
ptran=reshape(ptran,N_z,N_z);       % reshape vector into matrix

% SCF 2007
dl_inc_2165_SCF2007 = dlmread('dl_inc_2165_SCF.out','');
avg_dl_inc_SCF2007 = dlmread('income_SCF.out','');
avg_riskpart_SCF2007 = dlmread('have_risky_SCF.out','');
avg_wealth_SCF2007 = dlmread('networth_SCF.out','');
avg_risky_SCF2007 = dlmread('risky_SCF.out','');
avg_lev_SCF2007 = dlmread('leverage_SCF.out','');
avg_cond_lev_SCF2007 = dlmread('cond_lev_SCF.out','');

dl_inc_2165_SCF2007 = dl_inc_2165_SCF2007/1000;
avg_dl_inc_SCF2007 = avg_dl_inc_SCF2007/1000;
avg_wealth_SCF2007 = avg_wealth_SCF2007/1000;
avg_risky_SCF2007 = avg_risky_SCF2007/1000;
avg_safe_SCF2007 = avg_wealth_SCF2007 - avg_risky_SCF2007;

%% Compute averages
avg_income = zeros(jmax,1);
avg_wealth_in = zeros(jmax,1);
avg_bonds_rp = zeros(jmax,1);
avg_bonds_nrp = zeros(jmax,1);

N_lbin = 50;
lbin = linspace(0,1.0,N_lbin)'; % grid points for leverage distribution
mu_lev = zeros(jmax,N_lbin);    % distribution of leverage by age

lev_wealth = zeros(N_a,1);  	% average leverage by wealth (21-38)
mu_wealth = zeros(N_a,1);       % distribution by wealth (21-38)

for idx_j=1:jmax
    for idx_a=1:N_a
        for idx_z=1:N_z
            for idx_y=1:N_y
                if muss(idx_a,idx_z,idx_y,idx_j)>0
                    safe = bss(idx_a,idx_z,idx_y,idx_j);
                    risky = xss(idx_a,idx_z,idx_y,idx_j);
                    if idx_j>jret-1
                        avg_income(idx_j) = avg_income(idx_j) + ss(idx_y)*muss(idx_a,idx_z,idx_y,idx_j);
                    else
                        avg_income(idx_j) = avg_income(idx_j) + eta_j(idx_j)*z_grid(idx_z)*muss(idx_a,idx_z,idx_y,idx_j);
                    end
                    if risky>0
                        if safe<0
                            leverage = min(1,max(0,-safe/risky));
                            [~,i_lbin] = min(abs(lbin-leverage));
                            mu_lev(idx_j,i_lbin) = mu_lev(idx_j,i_lbin) + muss(idx_a,idx_z,idx_y,idx_j);
                            if idx_j<=6
                                lev_wealth(idx_a) = lev_wealth(idx_a) + leverage*muss(idx_a,idx_z,idx_y,idx_j);
                            end
                        else % if safe>=0, leverage=0
                            mu_lev(idx_j,1) = mu_lev(idx_j,1) + muss(idx_a,idx_z,idx_y,idx_j);
                        end
                        avg_bonds_rp(idx_j) = avg_bonds_rp(idx_j) + safe*muss(idx_a,idx_z,idx_y,idx_j);
                    else % if risky<=0
                        if safe<0
                            leverage = 1;
                            [~,i_lbin] = min(abs(lbin-leverage));
                            mu_lev(idx_j,i_lbin) = mu_lev(idx_j,i_lbin) + muss(idx_a,idx_z,idx_y,idx_j);
                            if idx_j<=6
                                lev_wealth(idx_a) = lev_wealth(idx_a) + leverage*muss(idx_a,idx_z,idx_y,idx_j);
                            end
                        else %if safe>=0, leverage=0
                            mu_lev(idx_j,1) = mu_lev(idx_j,1) + muss(idx_a,idx_z,idx_y,idx_j);
                        end
                        avg_bonds_nrp(idx_j) = avg_bonds_nrp(idx_j) + safe*muss(idx_a,idx_z,idx_y,idx_j);
                    end
                end
            end
        end
    end
end

avg_income = avg_income./mu_j;
avg_bonds_rp(1:jmax-1) = avg_bonds_rp(1:jmax-1)./(mu_j(1:jmax-1).*avg_riskpart(1:jmax-1));
avg_bonds_nrp(1:jmax-1) = avg_bonds_nrp(1:jmax-1)./(mu_j(1:jmax-1).*(1-avg_riskpart(1:jmax-1)));
lev_wealth = lev_wealth./sum(sum(sum(muss(:,:,:,1:6),4),3),2);

% Distribution of income shocks
dec_cutoff = -0.25;
inc_cutoff = 0.25;
share_large_inc = zeros(jret-2,1);
share_large_dec = zeros(jret-2,1);
for idx_j=1:jret-2
    for idx_z=1:N_z
        for idx_zprime=1:N_z
            % control for age effects
            inc_change = log(z_grid(idx_zprime))-log(z_grid(idx_z));
            if inc_change>=inc_cutoff
                share_large_inc(idx_j) = share_large_inc(idx_j) ...
                    + sum(sum(muss(:,idx_z,:,idx_j)))*ptran(idx_z,idx_zprime);
            elseif inc_change<=dec_cutoff
                share_large_dec(idx_j) = share_large_dec(idx_j) ...
                    + sum(sum(muss(:,idx_z,:,idx_j)))*ptran(idx_z,idx_zprime);
            end
        end
    end
end

share_large_dec = share_large_dec./mu_j(1:jret-2);
share_large_inc = share_large_inc./mu_j(1:jret-2);

mu_lev = mu_lev./repmat(mu_j,[1,N_lbin]);

mu_lev_1 = mu_j(1:3)'*mu_lev(1:3,:)/sum(mu_j(1:3));
cumsum_lev = zeros(N_lbin,6);
cumsum_lev(:,1) = cumsum(mu_lev_1');

mu_lev_2 = mu_j(4:6)'*mu_lev(4:6,:)/sum(mu_j(4:6));
cumsum_lev(:,2) = cumsum(mu_lev_2');

mu_lev_3 = mu_j(7:9)'*mu_lev(7:9,:)/sum(mu_j(7:9));
cumsum_lev(:,3) = cumsum(mu_lev_3');

mu_lev_4 = mu_j(10:12)'*mu_lev(10:12,:)/sum(mu_j(10:12));
cumsum_lev(:,4) = cumsum(mu_lev_4');

mu_lev_5 = mu_j(13:15)'*mu_lev(13:15,:)/sum(mu_j(13:15));
cumsum_lev(:,5) = cumsum(mu_lev_5');

mu_lev_6 = mu_j(16:jmax)'*mu_lev(16:jmax,:)/sum(mu_j(16:jmax));
cumsum_lev(:,6) = cumsum(mu_lev_6');

for j=1:6
    for i=2:N_lbin
        while cumsum_lev(i,j) <= cumsum_lev(i-1,j)
            cumsum_lev(i,j) = cumsum_lev(i,j) + eps;
        end
    end
end

% Household leverage across age cohorts
fprintf('\npercent of households with leverage <25 percent')
fprintf('\n21-29: %1.2f', (interp1(lbin,cumsum_lev(:,1),0.25))*100);
fprintf('\n30-38: %1.2f', (interp1(lbin,cumsum_lev(:,2),0.25))*100);
fprintf('\n39-47: %1.2f', (interp1(lbin,cumsum_lev(:,3),0.25))*100);
fprintf('\n48-56: %1.2f', (interp1(lbin,cumsum_lev(:,4),0.25))*100);
fprintf('\n57-65: %1.2f', (interp1(lbin,cumsum_lev(:,5),0.25))*100);
fprintf('\n66-95: %1.2f\n', (interp1(lbin,cumsum_lev(:,6),0.25))*100);

fprintf('\npercent of households with leverage bewteen 25 and 50 percent')
fprintf('\n21-29: %1.2f', (interp1(lbin,cumsum_lev(:,1),0.50)-interp1(lbin,cumsum_lev(:,1),0.25))*100);
fprintf('\n30-38: %1.2f', (interp1(lbin,cumsum_lev(:,2),0.50)-interp1(lbin,cumsum_lev(:,2),0.25))*100);
fprintf('\n39-47: %1.2f', (interp1(lbin,cumsum_lev(:,3),0.50)-interp1(lbin,cumsum_lev(:,3),0.25))*100);
fprintf('\n48-56: %1.2f', (interp1(lbin,cumsum_lev(:,4),0.50)-interp1(lbin,cumsum_lev(:,4),0.25))*100);
fprintf('\n57-65: %1.2f', (interp1(lbin,cumsum_lev(:,5),0.50)-interp1(lbin,cumsum_lev(:,5),0.25))*100);
fprintf('\n66-95: %1.2f\n', (interp1(lbin,cumsum_lev(:,6),0.50)-interp1(lbin,cumsum_lev(:,6),0.25))*100);

fprintf('\npercent of households with leverage bewteen 50 and 75 percent')
fprintf('\n21-29: %1.2f', (interp1(lbin,cumsum_lev(:,1),0.75)-interp1(lbin,cumsum_lev(:,1),0.50))*100);
fprintf('\n30-38: %1.2f', (interp1(lbin,cumsum_lev(:,2),0.75)-interp1(lbin,cumsum_lev(:,2),0.50))*100);
fprintf('\n39-47: %1.2f', (interp1(lbin,cumsum_lev(:,3),0.75)-interp1(lbin,cumsum_lev(:,3),0.50))*100);
fprintf('\n48-56: %1.2f', (interp1(lbin,cumsum_lev(:,4),0.75)-interp1(lbin,cumsum_lev(:,4),0.50))*100);
fprintf('\n57-65: %1.2f', (interp1(lbin,cumsum_lev(:,5),0.75)-interp1(lbin,cumsum_lev(:,5),0.50))*100);
fprintf('\n66-95: %1.2f\n', (interp1(lbin,cumsum_lev(:,6),0.75)-interp1(lbin,cumsum_lev(:,6),0.50))*100);

fprintf('\npercent of households with leverage > 75 percent')
fprintf('\n21-29: %1.2f', (1-interp1(lbin,cumsum_lev(:,1),0.75))*100);
fprintf('\n30-38: %1.2f', (1-interp1(lbin,cumsum_lev(:,2),0.75))*100);
fprintf('\n39-47: %1.2f', (1-interp1(lbin,cumsum_lev(:,3),0.75))*100);
fprintf('\n48-56: %1.2f', (1-interp1(lbin,cumsum_lev(:,4),0.75))*100);
fprintf('\n57-65: %1.2f', (1-interp1(lbin,cumsum_lev(:,5),0.75))*100);
fprintf('\n66-95: %1.2f\n', (1-interp1(lbin,cumsum_lev(:,6),0.75))*100);

% labor income per WAP
lincomewap_model = sum(avg_income(1:jret-1).*mu_j(1:jret-1))/sum(mu_j(1:jret-1));
lincomewap_model = lincomewap_model/period;
scale = dl_inc_2165_SCF2007/lincomewap_model;

avg_bonds = avg_bonds*scale;
avg_bonds_rp = avg_bonds_rp*scale;
avg_bonds_nrp = avg_bonds_nrp*scale;
avg_risky = avg_risky*scale;
avg_wealth_in = avg_wealth_in*scale;
avg_income = avg_income*scale/period;           % annualize
avg_wealth = avg_bonds + avg_risky;
tot_wealth = mu_j'*avg_wealth;
tot_2165_inc = mu_j(1:jret-1)'*avg_income(1:jret-1)/sum(mu_j(1:jret-1));

%% Compute distributions
amuss = zeros(N_a,1);

for idx_j=1:jmax
    for idx_a=1:N_a
        for idx_z=1:N_z
            for idx_y=1:N_y
                if muss(idx_a,idx_z,idx_y,idx_j)>0
                    safe = bss(idx_a,idx_z,idx_y,idx_j);
                    risky = xss(idx_a,idx_z,idx_y,idx_j);
                    alpha = alphass(idx_a,idx_z,idx_y,idx_j);
                    saving = sss(idx_a,idx_z,idx_y,idx_j);
                    wealth =  safe + risky;
                    [~,ind] = min(abs(wealth - a_grid));
                    amuss(ind) = amuss(ind) + muss(idx_a,idx_z,idx_y,idx_j);
                end
            end
        end
    end
end

prdist = squeeze(sum(sum(sum(muss,4),3),2));
cudist = cumsum(prdist);
for idx_a = 2:N_a
    while cudist(idx_a)<=cudist(idx_a-1)
        cudist(idx_a)=cudist(idx_a)+eps*idx_a;
    end
end
cudist=cudist/cudist(N_a);

p90 = interp1(cudist,a_grid,0.90,'linear');
p50 = interp1(cudist,a_grid,0.50,'linear');

sumwealth = sum(prdist.*a_grid);
cumwealth = cumsum(prdist.*a_grid)/sumwealth;
cumwealth = max(cumwealth,0);

sumwealth_trunc = sum(prdist.*min(a_grid,3e3/scale));
cumwealth_trunc = cumsum(prdist.*min(a_grid,3e3/scale))/sumwealth_trunc;
cumwealth_trunc = max(cumwealth_trunc,0);

fprintf('\n Safe assets\n');
for i=1:8
    j=3*(i-1)+1;
    fprintf('ages: %2i-%2i | participant: %2.2f | non-part: %2.2f \n', ...
        (j-1)*3+21,(j+1)*3+23, ...
        sum(avg_bonds_rp(j:j+2).*mu_j(j:j+2).*avg_riskpart(j:j+2))/sum(mu_j(j:j+2).*avg_riskpart(j:j+2)), ...
        sum(avg_bonds_nrp(j:j+2).*mu_j(j:j+2).*(1-avg_riskpart(j:j+2)))/sum(mu_j(j:j+2).*(1-avg_riskpart(j:j+2))))
end

demandsafe = sum( avg_bonds.*mu_j ) ;
demandrisky = sum( avg_risky.*mu_j );

fprintf('\npercent with assets <=0: %1.5f\n', 100*sum(amuss(1:ia_zero)))


%% Calibration statistics
young_lev = avg_leverage(1:6)'*mu_j(1:6)/sum(mu_j(1:6));
risk_part = avg_riskpart'*mu_j;
young_part = avg_riskpart(1:6)'*mu_j(1:6)/sum(mu_j(1:6));
fprintf('\nCalibration statistics')
fprintf('\n90/50 wealth ratio: %2.3f', p90/p50);
fprintf('\nRisky assets / 21-65 labor income: %2.3f', demandrisky/tot_2165_inc)
fprintf('\nSafe assets / 21-65 labor income: %2.3f', demandsafe/tot_2165_inc)
fprintf('\nLeverage: %2.3f', avg_leverage'*mu_j );
fprintf('\nRisky asset participation: %2.3f', risk_part )

MSE = ( ((avg_leverage'*mu_j-0.2265)/0.2265)^2          ...
    + ((risk_part-0.8123)/0.8123)^2                 ...
    + ((demandrisky/tot_2165_inc-8.78)/8.78)^2      ...
    + ((demandsafe/tot_2165_inc-0.3986)/0.3986)^2	...
    + ((p90/p50-7.43)/7.43)^2                        )/5;

%% Plot figures

figure;
subplot(2,2,1);
hold on
plot(linspace(21,21+(jmax-1)*period,jmax),avg_wealth,'-r','LineWidth',2);
plot(linspace(21,21+(jmax-1)*period,jmax),avg_wealth_SCF2007,'-b','LineWidth',2);
axis([20 80 0 1500]);
hold off
title('Net wealth')
subplot(2,2,2);
hold on
plot(linspace(21,21+(jmax-1)*period,jmax),avg_risky,'-r','LineWidth',2);
plot(linspace(21,21+(jmax-1)*period,jmax),avg_risky_SCF2007,'-b','LineWidth',2);
axis([20 80 0 1500]);
hold off
title('Risky Assets')
subplot(2,2,3);
hold on
plot(linspace(21,21+(jmax-1)*period,jmax),avg_leverage,'-r','LineWidth',2);
plot(linspace(21,21+(jmax-1)*period,jmax),avg_lev_SCF2007,'-b','LineWidth',2);
axis([20 80 0 1]);
hold off
title('Leverage')
subplot(2,2,4);
hold on
plot(linspace(21,21+(jmax-1)*period,jmax),avg_riskpart,'-r','LineWidth',2);
plot(linspace(21,21+(jmax-1)*period,jmax),avg_riskpart_SCF2007,'-b','LineWidth',2);
axis([20 80 0 1]);
hold off
title('Risky asset participation')

figure;
subplot(2,2,[1,2]);
plot(linspace(21,21+(jmax-1)*period,jmax),avg_income,'-k','LineWidth',2);
axis([21 63 0 130]);
ylabel('thousands of dollars')
title('Age income profile')
subplot(2,2,3);
plot(linspace(21,21+(jmax-1)*period,jmax),psi_j*100,'-k','LineWidth',2);
axis([21 85 0 100]);
xlabel('age')
ylabel('percent')
title('Survival rates')
subplot(2,2,4);
plot(linspace(21,21+(jmax-1)*period,jmax),ae_j,'-k','LineWidth',2);
axis([21 85 1 2]);
xlabel('age')
title('Adult equivalent')

figure;
subplot(121);
plot(cudist,cumwealth);
axis([0 1 0 1]);
title('Wealth Lorenz Curve')

subplot(122);
plot(cudist,cumwealth_trunc);
axis([0 1 0 1]);
title('Wealth Lorenz Curve (truncated)')


%% TRANSITION %%

Tend = 28;
transT = 1;
T = transT + 2;
sizt = siz*T;

% optimal bond positions bprime(a,z,y,j,t)
bt=dlmread('bprimet.out','');
[i,j]=size(bt);
bt=reshape(bt',i*j,1);          % transpose array into column vector
bt=bt(1:sizt);               	% store only data (drop empty terms)
bt=reshape(bt, N_a,N_z,N_y,jmax,T);	% reshape vector into matrix

% optimal risky asset positions xprime(a,z,y,j,t)
xt=dlmread('xprimet.out','');
[i,j]=size(xt);
xt=reshape(xt',i*j,1);      	% transpose array into column vector
xt=xt(1:sizt);                  % store only data (drop empty terms)
xt=reshape(xt, N_a,N_z,N_y,jmax,T);	% reshape vector into matrix

% optimal risky share alpha(a,z,y,j,t)
alphat=dlmread('alphat.out','');
[i,j]=size(alphat);
alphat=reshape(alphat',i*j,1);	% transpose array into column vector
alphat=alphat(1:sizt);       	% store only data (drop empty terms)
alphat=reshape(alphat, N_a,N_z,N_y,jmax,T);	% reshape vector into matrix

% optimal savings rate savingt(a,z,y,j,t)
st=dlmread('savingt.out','');
[i,j]=size(st);
st=reshape(st',i*j,1);      	% transpose array into column vector
st=st(1:sizt);                  % store only data (drop empty terms)
st=reshape(st, N_a,N_z,N_y,jmax,T);	% reshape vector into matrix

% consumption(a,z,y,j,t)
ct=dlmread('consumptiont.out','');
[i,j]=size(ct);
ct=reshape(ct',i*j,1);        	% transpose array into column vector
ct=ct(1:sizt);               	% store only data (drop empty terms)
ct=reshape(ct, N_a,N_z,N_y,jmax,T);	% reshape vector into matrix

% Value function vft(a,z,y,j)
vt=dlmread('vft.out','');
[i,j]=size(vt);
vt=reshape(vt',i*j,1);      	% transpose array into column vector
vt=vt(1:siz);                 	% store only data (drop empty terms)
vt=reshape(vt, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% Value function vss_aut(a,z,y,j)
vss_aut=dlmread('vss_aut.out','');
[i,j]=size(vss_aut);
vss_aut=reshape(vss_aut',i*j,1);	% transpose array into column vector
vss_aut=vss_aut(1:siz);     	% store only data (drop empty terms)
vss_aut=reshape(vss_aut, N_a,N_z,N_y,jmax);	% reshape vector into matrix

% ex post consumption equivalent ceq_post(a,z,y,j)
ceq=dlmread('ceq_post.out','');
[i,j]=size(ceq);
ceq=reshape(ceq',i*j,1);        % transpose array into column vector
ceq=ceq(1:(jmax-1)*N_a*N_z*N_y);	% store only data (drop empty terms)
ceq=reshape(ceq, N_a,N_z,N_y,jmax-1);	% reshape vector into matrix

% one-period consumption equivalent pceq(a,z,y,j)
pceq=dlmread('pceq.out','');
[i,j]=size(pceq);
pceq=reshape(pceq',i*j,1);   	% transpose array into column vector
pceq=pceq(1:(jmax-1)*N_a*N_z*N_y);	% store only data (drop empty terms)
pceq=reshape(pceq, N_a,N_z,N_y,jmax-1);	% reshape vector into matrix

% wealth distribution(a,z,y,j,t)
mut=dlmread('distributiont.out','');
[i,j]=size(mut);
mut=reshape(mut',i*j,1);      	% transpose array into column vector
mut=mut(1:jmax*N_a*N_z*N_y*Tend);	% store only data (drop empty terms)
mut=reshape(mut, N_a,N_z,N_y,jmax,Tend);    % reshape vector into matrix

% income shocks (recession)
eta_jt=dlmread('eta_jt.out','');
[i,j]=size(eta_jt);
eta_jt=reshape(eta_jt',i*j,1);	% transpose array into column vector
eta_jt=eta_jt(1:jmax);        	% store only data (drop empty terms)

% risky asset price
pxt=dlmread('pxt.out','');
[i,j]=size(pxt);
pxt=reshape(pxt',i*j,1);        % transpose array into column vector
pxt=pxt(1:T);               	% store only data (drop empty terms)
pxt=[pxt;ones(Tend-T,1)];

% xip_grid
xip_grid=dlmread('xip_grid.out','');
[i,j]=size(xip_grid);
xip_grid=reshape(xip_grid',i*j,1);	% transpose array into column vector
xip_grid=xip_grid(1:N_xi);        	% store only data (drop empty terms)

% pr_xip
pr_xip=dlmread('pr_xip.out','');
[i,j]=size(pr_xip);
pr_xip=reshape(pr_xip',i*j,1);	% transpose array into column vector
pr_xip=pr_xip(1:N_xi);       	% store only data (drop empty terms)

% xit_grid
xit_grid=dlmread('xit_grid.out','');
[i,j]=size(xit_grid);
xit_grid=reshape(xit_grid',i*j,1);	% transpose array into column vector
xit_grid=xit_grid(1:N_xi);        	% store only data (drop empty terms)

% pr_xit
pr_xit=dlmread('pr_xit.out','');
[i,j]=size(pr_xit);
pr_xit=reshape(pr_xit',i*j,1);	% transpose array into column vector
pr_xit=pr_xit(1:N_xi);       	% store only data (drop empty terms)

% ptrant (recession)
ptrant=dlmread('ptrant.out','');
[i,j]=size(ptrant);
ptrant=reshape(ptrant',i*j,1);	% transpose array into column vector
ptrant=ptrant(1:N_z*N_z);     	% store only data (drop empty terms)
ptrant=reshape(ptrant,N_z,N_z);	% transpose array into column vector

% welfare results
welfare_in = importdata('WELFARE_RESULTS.out',' ',1);
ceqj = welfare_in.data(2:jmax,2);
ceqjrp = welfare_in.data(2:jmax,3);
ceqjnrp = welfare_in.data(2:jmax,4);
pceqj = welfare_in.data(2:jmax,5);
pceqjrp = welfare_in.data(2:jmax,6);
pceqjnrp = welfare_in.data(2:jmax,7);

clear welfare_in


%% Compute averages
avg_bonds = zeros(jmax,Tend);
avg_risky = zeros(jmax,Tend);
avg_consumption = zeros(jmax,Tend);
avg_income = zeros(jmax,Tend);
avg_riskpart = zeros(jmax,Tend);
avg_leverage = zeros(jmax,Tend);

for t=1:Tend
    for idx_j=1:jmax
        for idx_a=1:N_a
            for idx_z=1:N_z
                for idx_y=1:N_y
                    if mut(idx_a,idx_z,idx_y,idx_j,t)>0
                        
                        if idx_j>jret-1
                            income = ss(idx_y);
                        else
                            if t==2
                                income = eta_jt(idx_j)*z_grid(idx_z);
                            else
                                income = eta_j(idx_j)*z_grid(idx_z);
                            end
                        end
                        
                        safe = bt(idx_a,idx_z,idx_y,idx_j,min(t,transT+2));
                        risky = xt(idx_a,idx_z,idx_y,idx_j,min(t,transT+2));
                        
                        if risky>0
                            if safe<0
                                leverage = min(1,max(0,-safe/pxt(min(t,transT+2))*risky));
                                avg_leverage(idx_j,t) = avg_leverage(idx_j,t) + leverage*mut(idx_a,idx_z,idx_y,idx_j,t);
                            end
                            avg_riskpart(idx_j,t) = avg_riskpart(idx_j,t) + mut(idx_a,idx_z,idx_y,idx_j,t);
                        else % if risky<=0
                            if safe<0 % leverage = 1;
                                avg_leverage(idx_j,t) = avg_leverage(idx_j,t) + mut(idx_a,idx_z,idx_y,idx_j,t);
                            end
                        end
                        
                        avg_bonds(idx_j,t) = avg_bonds(idx_j,t) + safe*mut(idx_a,idx_z,idx_y,idx_j,t);
                        avg_risky(idx_j,t) = avg_risky(idx_j,t) + risky*mut(idx_a,idx_z,idx_y,idx_j,t);
                        avg_income(idx_j,t) = avg_income(idx_j,t) + income*mut(idx_a,idx_z,idx_y,idx_j,t);
                        
                    end
                end
            end
        end
    end
    avg_bonds(:,t) = avg_bonds(:,t)./mu_j;
    avg_risky(:,t) = avg_risky(:,t)./mu_j;
    avg_income(:,t) = avg_income(:,t)./mu_j/period;	% annualize
    avg_riskpart(:,t) = avg_riskpart(:,t)./mu_j;
    avg_leverage(:,t) = avg_leverage(:,t)./mu_j;
end

% Distribution of income shocks
share_large_inct = zeros(jret-2,1);
share_large_dect = zeros(jret-2,1);
share_large_dect_rec = zeros(jret-2,1);

for idx_j=1:jret-2
    for idx_z=1:N_z
        for idx_zprime=1:N_z
            % with age controls
            inc_t = z_grid(idx_z);
            inc_tp = eta_jt(idx_j+1)/eta_j(idx_j+1)*z_grid(idx_zprime);
            inc_change = log(inc_tp)-log(inc_t);
            
            if inc_change>=inc_cutoff
                share_large_inct(idx_j) = ...
                    share_large_inct(idx_j) ...
                    + sum(sum(muss(:,idx_z,:,idx_j)))*ptrant(idx_z,idx_zprime);
            elseif inc_change<=dec_cutoff
                share_large_dect(idx_j) = ...
                    share_large_dect(idx_j) ...
                    + sum(sum(muss(:,idx_z,:,idx_j)))*ptrant(idx_z,idx_zprime);
                if idx_j+2<jret
                    for idx_zpp=1:N_z
                        inc_tpp = z_grid(idx_zpp);
                        inc_change_prime = log(inc_tpp)-log(inc_tp);
                        if inc_tpp>=inc_t
                            share_large_dect_rec(idx_j) = ...
                                share_large_dect_rec(idx_j) ...
                                + sum(sum(muss(:,idx_z,:,idx_j))) ...
                                *ptrant(idx_z,idx_zprime) ...
                                *ptran(idx_zprime,idx_zpp);
                        end
                    end
                end
            end
        end
    end
end
share_large_dect_rec = share_large_dect_rec./share_large_dect;
share_large_inct = share_large_inct./mu_j(1:jret-2);
share_large_dect = share_large_dect./mu_j(1:jret-2);

fprintf('\n       downward earnings risk (percent, with quadratic age effects)')
fprintf('\n       pre-recession | recession | difference	')
fprintf('\nall  : %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_dec(1:14).*mu_j(1:14))/sum(mu_j(1:14)), ...
    sum(100*share_large_dect(1:14,1).*mu_j(1:14))/sum(mu_j(1:14)), ...
    sum(100*share_large_dect(1:14,1).*mu_j(1:14))/sum(mu_j(1:14)) ...
    - sum(100*share_large_dec(1:14).*mu_j(1:14))/sum(mu_j(1:14)) )
fprintf('\n21-29: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_dec(1:3).*mu_j(1:3))/sum(mu_j(1:3)), ...
    sum(100*share_large_dect(1:3,1).*mu_j(1:3))/sum(mu_j(1:3)), ...
    sum(100*share_large_dect(1:3,1).*mu_j(1:3))/sum(mu_j(1:3)) ...
    - sum(100*share_large_dec(1:3).*mu_j(1:3))/sum(mu_j(1:3)) )
fprintf('\n30-38: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_dec(4:6).*mu_j(4:6))/sum(mu_j(4:6)), ...
    sum(100*share_large_dect(4:6,1).*mu_j(4:6))/sum(mu_j(4:6)), ...
    sum(100*share_large_dect(4:6,1).*mu_j(4:6))/sum(mu_j(4:6)) ...
    - sum(100*share_large_dec(4:6).*mu_j(4:6))/sum(mu_j(4:6)) )
fprintf('\n39-47: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_dec(7:9).*mu_j(7:9))/sum(mu_j(7:9)), ...
    sum(100*share_large_dect(7:9,1).*mu_j(7:9))/sum(mu_j(7:9)), ...
    sum(100*share_large_dect(7:9,1).*mu_j(7:9))/sum(mu_j(7:9)) ...
    - sum(100*share_large_dec(7:9).*mu_j(7:9))/sum(mu_j(7:9)) )
fprintf('\n48-56: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_dec(10:12).*mu_j(10:12))/sum(mu_j(10:12)), ...
    sum(100*share_large_dect(10:12,1).*mu_j(10:12))/sum(mu_j(10:12)), ...
    sum(100*share_large_dect(10:12,1).*mu_j(10:12))/sum(mu_j(10:12)) ...
    - sum(100*share_large_dec(10:12).*mu_j(10:12))/sum(mu_j(10:12)) )
fprintf('\n57-61: %4.1f          | %4.1f      | %4.1f  \n', ...
    sum(100*share_large_dec(13:14).*mu_j(13:14))/sum(mu_j(13:14)), ...
    sum(100*share_large_dect(13:14,1).*mu_j(13:14))/sum(mu_j(13:14)), ...
    sum(100*share_large_dect(13:14,1).*mu_j(13:14))/sum(mu_j(13:14)) ...
    - sum(100*share_large_dec(13:14).*mu_j(13:14))/sum(mu_j(13:14)) )

fprintf('\n       upward earnings risk (percent, with quadratic age effects)')
fprintf('\n       pre-recession | recession | difference	')
fprintf('\nall  : %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_inc(1:14).*mu_j(1:14))/sum(mu_j(1:14)), ...
    sum(100*share_large_inct(1:14,1).*mu_j(1:14))/sum(mu_j(1:14)), ...
    sum(100*share_large_inct(1:14,1).*mu_j(1:14))/sum(mu_j(1:14)) ...
    - sum(100*share_large_inc(1:14).*mu_j(1:14))/sum(mu_j(1:14)) )
fprintf('\n21-29: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_inc(1:3).*mu_j(1:3))/sum(mu_j(1:3)), ...
    sum(100*share_large_inct(1:3,1).*mu_j(1:3))/sum(mu_j(1:3)), ...
    sum(100*share_large_inct(1:3,1).*mu_j(1:3))/sum(mu_j(1:3)) ...
    - sum(100*share_large_inc(1:3).*mu_j(1:3))/sum(mu_j(1:3)) )
fprintf('\n30-38: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_inc(4:6).*mu_j(4:6))/sum(mu_j(4:6)), ...
    sum(100*share_large_inct(4:6,1).*mu_j(4:6))/sum(mu_j(4:6)), ...
    sum(100*share_large_inct(4:6,1).*mu_j(4:6))/sum(mu_j(4:6)) ...
    - sum(100*share_large_inc(4:6).*mu_j(4:6))/sum(mu_j(4:6)) )
fprintf('\n39-47: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_inc(7:9).*mu_j(7:9))/sum(mu_j(7:9)), ...
    sum(100*share_large_inct(7:9,1).*mu_j(7:9))/sum(mu_j(7:9)), ...
    sum(100*share_large_inct(7:9,1).*mu_j(7:9))/sum(mu_j(7:9)) ...
    - sum(100*share_large_inc(7:9).*mu_j(7:9))/sum(mu_j(7:9)) )
fprintf('\n48-56: %4.1f          | %4.1f      | %4.1f  ', ...
    sum(100*share_large_inc(10:12).*mu_j(10:12))/sum(mu_j(10:12)), ...
    sum(100*share_large_inct(10:12,1).*mu_j(10:12))/sum(mu_j(10:12)), ...
    sum(100*share_large_inct(10:12,1).*mu_j(10:12))/sum(mu_j(10:12)) ...
    - sum(100*share_large_inc(10:12).*mu_j(10:12))/sum(mu_j(10:12)) )
fprintf('\n57-61: %4.1f          | %4.1f      | %4.1f  \n', ...
    sum(100*share_large_inc(13:14).*mu_j(13:14))/sum(mu_j(13:14)), ...
    sum(100*share_large_inct(13:14,1).*mu_j(13:14))/sum(mu_j(13:14)), ...
    sum(100*share_large_inct(13:14,1).*mu_j(13:14))/sum(mu_j(13:14)) ...
    - sum(100*share_large_inc(13:14).*mu_j(13:14))/sum(mu_j(13:14)) )

fprintf('\n       percent of households with large income drop in t=1')
fprintf('\n       that recovered their t=0 income in t=2')
fprintf('\nall  : %4.1f', sum(100*share_large_dect_rec(1:13).*mu_j(1:13))/sum(mu_j(1:13)) )
fprintf('\n21-29: %4.1f', sum(100*share_large_dect_rec(1:13).*mu_j(1:13))/sum(mu_j(1:13)) )
fprintf('\n30-38: %4.1f', sum(100*share_large_dect_rec(1:13).*mu_j(1:13))/sum(mu_j(1:13)) )
fprintf('\n39-47: %4.1f', sum(100*share_large_dect_rec(1:13).*mu_j(1:13))/sum(mu_j(1:13)) )
fprintf('\n48-56: %4.1f', sum(100*share_large_dect_rec(1:13).*mu_j(1:13))/sum(mu_j(1:13)) )
fprintf('\n57-61: %4.1f  \n', sum(100*share_large_dect_rec(1:13).*mu_j(1:13))/sum(mu_j(1:13)) )

ageprofile = importdata('AGE_PROFILES.out',' ',1);
avg_risky(:,1) = ageprofile.data(:,1);
avg_bonds(:,1) = ageprofile.data(:,2);
avg_leverage(:,1) = ageprofile.data(:,3);
avg_riskpart(:,1) = ageprofile.data(:,4);
clear ageprofile

ageprofile_rec = importdata('AGE_PROFILES_REC.out',' ',1);
avg_risky(:,2) = ageprofile_rec.data(:,1);
avg_bonds(:,2) = ageprofile_rec.data(:,2);
avg_leverage(:,2) = ageprofile_rec.data(:,3);
avg_riskpart(:,2) = ageprofile_rec.data(:,4);
clear ageprofile_rec

% scale = lincomewap_data/lincomewap_model;
avg_bonds = avg_bonds*scale;
avg_risky = avg_risky*scale;
avg_income = avg_income*scale;
avg_wealth = avg_bonds + repmat(pxt',jmax,1).*avg_risky;

tplot = 16;

figure; % Aggregate Labor Income
hold on;
plot(-1:1:Tend-2,(mu_j(1:jret-1)'*avg_income(1:jret-1,1:Tend))./(mu_j(1:jret-1)'*avg_income(1:jret-1,1))*100,'-k','LineWidth',2);
xlim([-1,tplot-1]);
ylim([85,100]);
xlabel('periods after shock')
ylabel('index (steady state = 100)')
% title('Aggregate Labor Income')
ax = gca;
ax.TickDir = 'out';
% set box property to off and remove background color
set(ax,'box','off','color','none')
% create new, empty axes with box but without ticks
b = axes('Position',get(ax,'Position'),'box','on','xtick',[],'ytick',[]);
% set original axes as active
axes(ax)
% link axes in case of zooming
%linkaxes([ax b])
hold off;

avg_inc_cohort = NaN(jret,jmax);
for j=1:jret
    for t=1:jmax-j+1
        avg_inc_cohort(j,t) = avg_income(j+t-1,t);
    end
end

figure; % Labor Income by cohort
hold on;
plot(-1:1:jmax-2,avg_inc_cohort(1,1:jmax)./avg_income(1:jmax,1)'*100,'-k','LineWidth',2);
plot(-1:1:jmax-9,avg_inc_cohort(8,1:jmax-7)./avg_income(8:jmax,1)'*100,'-.m','LineWidth',2);
plot(-1:1:jmax-14,avg_inc_cohort(13,1:jmax-12)./avg_income(13:jmax,1)'*100,'--b','LineWidth',2);
legend('21-23','42-44','57-59','Location','SouthEast')
xlim([-1,tplot-1]);
ylim([85,100]);
xlabel('periods after shock')
ylabel('index (steady state = 100)')
%title('Aggregate Labor Income')
ax = gca;
ax.TickDir = 'out';
% set box property to off and remove background color
set(ax,'box','off','color','none')
% create new, empty axes with box but without ticks
b = axes('Position',get(ax,'Position'),'box','on','xtick',[],'ytick',[]);
% set original axes as active
axes(ax)
% link axes in case of zooming
%linkaxes([ax b])
hold off;


%% Welfare Changes

% Construct bins for safe and risky assets
bbin = [-2,-1,-.5,-.25,-.1,0.01,.05,.1,.25,.5,1,2,5,10,16,24,36,50,100];
xbin = [0.,0.01,.2,.25,.33,.45,.7,1.5,3,5,10,16,24,36,50,100];
N_bbin = length(bbin);
N_xbin = length(xbin);
pceqbx = zeros(N_bbin,N_xbin);	% Consumption equivalent (by portfolio)
mubx = pceqbx;	% distribution of portfolio holdings
avgjbx = mubx;  % average age by portfolio

for j=1:jmax-1
    for ia = 1:N_a
        for iz = 1:N_z
            for iy = 1:N_y
                if muss(ia,iz,iy,j)>0
                    wealth_in = a_grid(ia);
                    xprime = xss(ia,iz,iy,j);
                    bprime = bss(ia,iz,iy,j);
                    wealth = pxt(1)*xprime + bprime;
                    
                    [~,ibb] = min(abs(bbin-bprime));
                    if xprime>0
                        [~,ixb] = min(abs(xbin-xprime));
                    else
                        if rand<.5
                            ixb = 1;
                        else
                            ixb = 2;
                        end
                    end
                    
                    pceqbx(ibb,ixb) = pceqbx(ibb,ixb) + muss(ia,iz,iy,j)*pceq(ia,iz,iy,j);
                    mubx(ibb,ixb) = mubx(ibb,ixb) + muss(ia,iz,iy,j);
                    avgjbx(ibb,ixb) = avgjbx(ibb,ixb) + muss(ia,iz,iy,j)*(period*(j-1)+21);
                    
                end
            end
        end
    end
end

ceq = ceq*100;
pceq = pceq*100;
ceqj = ceqj*100;
pceqj = pceqj*100;
pceqbx = pceqbx./mubx*100;
avgjbx = avgjbx./mubx;
ceqjnrp = ceqjnrp*100;
ceqjrp = ceqjrp*100;
pceqjnrp = pceqjnrp*100;
pceqjrp = pceqjrp*100;

fprintf('\nChanges in risky participation (percent)')
fprintf('\n21-29: %1.5f', (mu_j(1:3)'*avg_riskpart(1:3,2)/sum(mu_j(1:3))-(mu_j(1:3)'*avg_riskpart(1:3,1)/sum(mu_j(1:3))))*100 )
fprintf('\n30-38: %1.5f', (mu_j(4:6)'*avg_riskpart(4:6,2)/sum(mu_j(4:6))-(mu_j(4:6)'*avg_riskpart(4:6,1)/sum(mu_j(4:6))))*100 )
fprintf('\n39-47: %1.5f', (mu_j(7:9)'*avg_riskpart(7:9,2)/sum(mu_j(7:9))-(mu_j(7:9)'*avg_riskpart(7:9,1)/sum(mu_j(7:9))))*100 )
fprintf('\n48-56: %1.5f', (mu_j(10:12)'*avg_riskpart(10:12,2)/sum(mu_j(10:12))-(mu_j(10:12)'*avg_riskpart(10:12,1)/sum(mu_j(10:12))))*100 )
fprintf('\n57-65: %1.5f', (mu_j(13:15)'*avg_riskpart(13:15,2)/sum(mu_j(13:15))-(mu_j(13:15)'*avg_riskpart(13:15,1)/sum(mu_j(13:15))))*100 )
fprintf('\n66-74: %1.5f', (mu_j(16:18)'*avg_riskpart(16:18,2)/sum(mu_j(16:18))-(mu_j(16:18)'*avg_riskpart(16:18,1)/sum(mu_j(16:18))))*100 )
fprintf('\n75-83: %1.5f', (mu_j(19:21)'*avg_riskpart(19:21,2)/sum(mu_j(19:21))-(mu_j(19:21)'*avg_riskpart(19:21,1)/sum(mu_j(19:21))))*100 )
fprintf('\n84-92: %1.5f\n', (mu_j(22:24)'*avg_riskpart(22:24,2)/sum(mu_j(22:24))-(mu_j(22:24)'*avg_riskpart(22:24,1)/sum(mu_j(22:24))))*100 )

fprintf('\nChanges in net wealth')
for ja = 1:8
    j = 3*(ja-1)+1;
    fprintf('\n%2i-%2i: %2.4f ', ...
        21+3*(j-1),20+3*(j+2), ...
        100*(sum(avg_wealth(j:j+2,2).*mu_j(j:j+2))/sum(mu_j(j:j+2)) ...
        /(sum(avg_wealth(j:j+2,1).*mu_j(j:j+2))/sum(mu_j(j:j+2)))-1) )
end
fprintf('\n')

fprintf('\nRemaining lifetime consumption (percent)')
fprintf('\n     age   |   all   | risky>0 | risky=0 ' )
[(21:3:90)',ceqj,ceqjrp,ceqjnrp]
fprintf('\n       all     | risky>0  | risky=0 ' )
for ja = 1:8
    j = 3*(ja-1)+1;
    fprintf('\n%2i-%2i: %2.4f | %2.4f | %2.4f  ', ...
        21+3*(j-1),20+3*(j+2), ...
        sum(ceqj(j:j+2).*mu_j(j:j+2))/sum(mu_j(j:j+2)), ...
        sum(ceqjrp(j:j+2).*mu_j(j:j+2).*rpj_ss(j:j+2))/sum(mu_j(j:j+2).*rpj_ss(j:j+2)), ...
        sum(ceqjnrp(j:j+2).*mu_j(j:j+2).*(1-rpj_ss(j:j+2)))/sum(mu_j(j:j+2).*(1-rpj_ss(j:j+2))) )
end
fprintf('\n')

fprintf('\nOne-period consumption equivalent (percent)')
[(21:3:90)',pceqj,pceqjrp,pceqjnrp]
fprintf('\n       all     | risky>0  | risky=0' )
for ja = 1:8
    j = 3*(ja-1)+1;
    fprintf('\n%2i-%2i: %2.4f | %2.4f | %2.4f  ', ...
        21+3*(j-1),20+3*(j+2), ...
        sum(pceqj(j:j+2).*mu_j(j:j+2))/sum(mu_j(j:j+2)), ...
        sum(pceqjrp(j:j+2).*mu_j(j:j+2).*rpj_ss(j:j+2))/sum(mu_j(j:j+2).*rpj_ss(j:j+2)), ...
        sum(pceqjnrp(j:j+2).*mu_j(j:j+2).*(1-rpj_ss(j:j+2)))/sum(mu_j(j:j+2).*(1-rpj_ss(j:j+2))) )
end
fprintf('\n')

[~,medbbin] = min(abs(bbin-0.01));
[~,medxbin] = min(abs(xbin-0.5));

figure; %% Welfare gains %%
axNW = subplot(121);
hold on;
contourf(bbin(1:medbbin)*scale,xbin(medxbin:N_xbin)*scale,pceqbx(1:medbbin,medxbin:N_xbin)');
axis([bbin(1)*scale bbin(medbbin)*scale xbin(medxbin)*scale xbin(N_xbin)*scale]);
colormap(hot);
caxis([-35,-5]);
ylabel('risky assets (thousands of 2013 dollars)');
%         plot(linspace(-scale*xbin(medxbin),-scale*max(-bbin(1),xbin(N_xbin)),1000), ...
%             linspace(scale*xbin(medxbin),scale*max(-bbin(1),xbin(N_xbin)),1000),'--', ...
%             'Color',[0.3 0.3 0.3],'Linewidth',2);
hold off;

axNE = subplot(122);
hold on;
contourf(bbin(medbbin:N_bbin)*scale,xbin(medxbin:N_xbin)*scale,pceqbx(medbbin:N_bbin,medxbin:N_xbin)',6);
axis([bbin(medbbin)*scale bbin(N_bbin)*scale xbin(medxbin)*scale xbin(N_xbin)*scale]);
colormap(hot);
caxis([-35,-5]);
xlabel('safe assets (thousands of 2013 dollars)');
%         plot(1:10:scale*max(bbin(N_bbin),xbin(N_xbin)),1:10:scale*max(bbin(N_bbin),xbin(N_xbin)),'--k', ...
%             'Color',[0.3 0.3 0.3],'Linewidth',2);
hold off;

set(axNW,'units','normalized','position',[0.1 0.1 0.35 0.8]);
set(axNE,'units','normalized','position',[0.45 0.1 0.45 0.8]);
set(axNW,'yscale','log','ylim',[xbin(medxbin)*scale xbin(N_xbin)*scale]);
axNW.TickDir = 'out';
% set box property to off and remove background color
set(axNW,'box','off','color','none')
% create new, empty axes with box but without ticks
bxNW = axes('Position',get(axNW,'Position'),'box','off','xtick',[],'ytick',[]);
% set original axes as active
axes(axNW)
% link axes in case of zooming
linkaxes([axNW bxNW])
set(axNE,'xscale','log');
set(axNE,'yscale','log','ytick',[]);

set(axNW,'XTick',[-400 -300 -200 -100 0]);
set(axNE,'XTick',[10 100 1000 10000]);
%suptitle('Welfare gains');
colorbar('Position', [0.91  0.1  0.025  0.80])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure; %% Average age by portfolio
axNW = subplot(121);
hold on;
contourf(bbin(1:medbbin)*scale,xbin(medxbin:N_xbin)*scale,avgjbx(1:medbbin,medxbin:N_xbin)');
axis([bbin(1)*scale bbin(medbbin)*scale xbin(medxbin)*scale xbin(N_xbin)*scale]);
colormap(hot);
caxis([20,90]);
ylabel('risky assets (thousands of 2013 dollars)');
%         plot(linspace(-scale*xbin(medxbin),-scale*max(-bbin(1),xbin(N_xbin)),1000), ...
%             linspace(scale*xbin(medxbin),scale*max(-bbin(1),xbin(N_xbin)),1000),'--', ...
%             'Color',[0.3 0.3 0.3],'Linewidth',2);
hold off;

axNE = subplot(122);
hold on;
contourf(bbin(medbbin:N_bbin)*scale,xbin(medxbin:N_xbin)*scale,avgjbx(medbbin:N_bbin,medxbin:N_xbin)',6);
axis([bbin(medbbin)*scale bbin(N_bbin)*scale xbin(medxbin)*scale xbin(N_xbin)*scale]);
colormap(hot);
caxis([20,90]);
xlabel('safe assets (thousands of 2013 dollars)');
%         plot(1:10:scale*max(bbin(N_bbin),xbin(N_xbin)),1:10:scale*max(bbin(N_bbin),xbin(N_xbin)),'--k', ...
%             'Color',[0.3 0.3 0.3],'Linewidth',2);
hold off;

set(axNW,'units','normalized','position',[0.1 0.1 0.35 0.8]);
set(axNE,'units','normalized','position',[0.45 0.1 0.45 0.8]);
set(axNW,'yscale','log','ylim',[xbin(medxbin)*scale xbin(N_xbin)*scale]);
axNW.TickDir = 'out';
% set box property to off and remove background color
set(axNW,'box','off','color','none')
% create new, empty axes with box but without ticks
bxNW = axes('Position',get(axNW,'Position'),'box','off','xtick',[],'ytick',[]);
% set original axes as active
axes(axNW)
% link axes in case of zooming
linkaxes([axNW bxNW])
set(axNE,'xscale','log');
set(axNE,'yscale','log','ytick',[]);

set(axNW,'XTick',[-400 -300 -200 -100 0]);
set(axNE,'XTick',[10 100 1000 10000]);
%suptitle('Average age by portfolio');
colorbar('Position', [0.91  0.1  0.025  0.80])
%ylabel('percent','Position',[116000 700])
















