Additional Materials for: "The Lost Generation of the Great Recession" by Sewon Hur

This folder contains the codes used in the paper.


CODE:


1. The main code is written in Fortran 90. It is compiled with Intel Fortran, and uses OpenMP.

The Fortran code computes optimal policy functions. The following files are included and are required for the program:

mainmenu.f90
auxiliary.f90
global.f90
parameters.f90
toolkit.f90


The mainmenu.f90 is the main program.

The main menu has the following options:

(1) compute steady state and transition (baseline)
(2) baseline + default
(3) baseline + no risky asset market changes
(4) baseline + no interest rate changes
(5) baseline + no labor market shocks
(6) baseline + labor shocks only transitory
(7) baseline + no sigma_xi increase
(8) robustness: sigma=2.5
(9) robustness: sigma=3.5
(10) robustness: lambdax

They can be run in any order. Calibrated parameters and transition priors are embedded in the code.


2. Main model statistics and figures are generated in Matlab.


The Matlab code reads the optimal policy functions, value functions, and distributions. 
It computes the main model statistics and generates tables and graphs.  

The following files are included and required for the program:


plot_results.m



3. Additional files included:  


survival.out: conditional survival probabilities (US Life Tables 2007)
income_SCF.out: age profile of disposable labor income (SCF 2007)
ageincome.out: normalized version of income_SCF.out
networth_SCF.out: age profile of wealth (SCF 2007)
risky_SCF.out: age profile of risky assets (SCF 2007)
have_risky_SCF.out: age profile of risky asset participation (SCF 2007)
leverage_SCF.out: age profile of household leverage (SCF 2007)
dl_inc_2165_SCF.out: disposable labor income per working age household (SCF 2007)
adultequiv.out: number of adult equivalents in household by age (SCF 2007)
initialwealth.out: top 15 percentiles of wealth for households of age 16-24 (SCF 2007)

