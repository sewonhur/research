Authors: Sewon Hur & Illenin Kondo
Date: April 2nd, 2014
Description: Data Appendix for "A Theory of Rollover Risk, Sudden Stops, and Foreign Reserves"

**************************************
*     PART A - FIGURES AND TABLES    *
**************************************
This part generates the data used in the paper.


All the data files all called through the .do files

All the data files are data inputs except for: 
>> obstfeld_v20121227.dta
>> bop_ss_v20121227.dta
>> iip_hk_v20121227

Execute in the following order:

>> prep_hk_v20121227.do
>> prep_ss_v20121227.do
>> prep_obstfeld_v20121227.do

The log files generated also store all the relevant ouput.

**************************************
*   PART B - US TREASURIES HOLDINGS  *
**************************************

This part generates the data for the figure on Foreign Holdings of US Treasuries.

All the data files all called through the .do files

All the data files are data inputs except for: 
>> tics_emes_v20121014.dta
>> tics_emes_agg_v20121014.dta

Execute in the following order:

>> tics_v20121014.do
>> tics_emes_v20121014.do

The log files generated also store all the relevant ouput.

**************************************
*   PART C - CHINN and ITO MEASURES  *
**************************************

This part generates the figure on the Chinn-Ito measure of capital openness.

The data input files are : 
>> chinn_ito.dta
>> list_emerging.dta

Execute in the following order:
>> prep_chinn_ito_v20140314.do

The log files generated also store all the relevant ouput.


---------------------------------------
----------    OPTIONAL   --------------
---------------------------------------


**************************************
*   PART D - CHINN and ITO MEASURES  *
**************************************

This part reproduces the Gourinchas-Obstfeld exercise on the model simulated data.

The data input files are: 
>> SIMULATIONS_3regions.dta

Execute in the following order:
>> prep_obstfeld_simul.do

The log files generated also store all the relevant ouput.

Comments welcome. See online data appendix and paper for additional details.

